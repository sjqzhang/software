// Copyright (c) 1999-2001  David Muse
// See the file COPYING for more information

#include <sqlrconnection.h>

bool sqlrcursor_svr::prepareQuery(const char *query, uint32_t querylength) {
	// by default, do nothing...
	return true;
}
