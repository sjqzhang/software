// Copyright (c) 1999-2011  David Muse
// See the file COPYING for more information

#include <sqlrconnection.h>

void sqlrconnection_svr::setFakeTransactionBlocksBehavior(bool ftb) {
	faketransactionblocks=ftb;
}

bool sqlrconnection_svr::supportsTransactionBlocks() {
	return true;
}

bool sqlrconnection_svr::handleFakeTransactionQueries(sqlrcursor_svr *cursor,
						bool *wasfaketransactionquery,
						const char **error,
						int64_t *errno) {

	*wasfaketransactionquery=false;

	// Intercept begins and handle them.  If we're faking begins, commit
	// and rollback queries also need to be intercepted as well, otherwise
	// the query will be sent directly to the db and endFakeBeginTransaction
	// won't get called.
	if (isBeginTransactionQuery(cursor)) {
		*wasfaketransactionquery=true;
		cursor->inbindcount=0;
		cursor->outbindcount=0;
		sendcolumninfo=DONT_SEND_COLUMN_INFO;
		if (intransactionblock) {
			*error="begin while already in transaction block";
			*errno=999999;
			return false;
		}
		return beginFakeTransactionBlock();
	} else if (isCommitQuery(cursor)) {
		*wasfaketransactionquery=true;
		cursor->inbindcount=0;
		cursor->outbindcount=0;
		sendcolumninfo=DONT_SEND_COLUMN_INFO;
		// FIXME: move this into commitInternal
		if (!intransactionblock) {
			*error="commit while not in transaction block";
			*errno=999998;
			return false;
		}
		return commitInternal();
	} else if (isRollbackQuery(cursor)) {
		*wasfaketransactionquery=true;
		cursor->inbindcount=0;
		cursor->outbindcount=0;
		sendcolumninfo=DONT_SEND_COLUMN_INFO;
		// FIXME: move this into rollbackInternal
		if (!intransactionblock) {
			*error="rollback while not in transaction block";
			*errno=999997;
			return false;
		}
		return rollbackInternal();
	}
	return false;
}

bool sqlrconnection_svr::isBeginTransactionQuery(sqlrcursor_svr *cursor) {

	// find the start of the actual query
	const char	*ptr=cursor->skipWhitespaceAndComments(
						cursor->querybuffer);

	// See if it was any of the different queries used to start a
	// transaction.  IMPORTANT: don't just look for the first 5 characters
	// to be "BEGIN", make sure it's the entire query.  Many db's use
	// "BEGIN" to start a stored procedure block, but in those cases,
	// something will follow it.
	if (!charstring::compareIgnoringCase(ptr,"BEGIN",5)) {

		// make sure there are only spaces, comments or the word "work"
		// after the begin
		const char	*spaceptr=
				cursor->skipWhitespaceAndComments(ptr+5);
		
		if (!charstring::compareIgnoringCase(spaceptr,"WORK",4) ||
			*spaceptr=='\0') {
			return true;
		}
		return false;

	} else if (!charstring::compareIgnoringCase(ptr,"START ",6)) {
		return true;
	}
	return false;
}

bool sqlrconnection_svr::beginFakeTransactionBlock() {

	// save the current autocommit state
	faketransactionblocksautocommiton=autocommitforthissession;

	// if autocommit is on, turn it off
	if (autocommitforthissession) {
		if (!autoCommitOffInternal()) {
			return false;
		}
	}
	intransactionblock=true;
	return true;
}

bool sqlrconnection_svr::endFakeTransactionBlock() {

	// if we're faking begins and autocommit is on,
	// reset autocommit behavior
	if (faketransactionblocks && faketransactionblocksautocommiton) {
		if (!autoCommitOnInternal()) {
			return false;
		}
	}
	intransactionblock=false;
	return true;
}

bool sqlrconnection_svr::isCommitQuery(sqlrcursor_svr *cursor) {
	return !charstring::compareIgnoringCase(
			cursor->skipWhitespaceAndComments(
						cursor->querybuffer),
			"commit",6);
}

bool sqlrconnection_svr::isRollbackQuery(sqlrcursor_svr *cursor) {
	return !charstring::compareIgnoringCase(
			cursor->skipWhitespaceAndComments(
						cursor->querybuffer),
			"rollback",8);
}
