# Copyright (c) 2000 Roman Milner
# See the file COPYING for more information

import PySQLRDB
