char ** XS_unpack_charPtrPtr _(( SV *rv ));
void XS_pack_charPtrPtr _(( SV *st, char **s ));
void XS_release_charPtrPtr _(( char **s ));

