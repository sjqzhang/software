#include "../../c++/include/sqlrelay/sqlrclient.h"
#include <EXTERN.h>
extern "C" {
	#include <perl.h>
}
#include <XSUB.h>
#undef CLASS
