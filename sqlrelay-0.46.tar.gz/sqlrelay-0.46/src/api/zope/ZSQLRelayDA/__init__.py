__doc__='''Generic Database Adapter Package Registration

$Id: __init__.py,v 1.1.1.1 2002/11/16 06:49:52 mused Exp $'''
__version__='$Revision: 1.1.1.1 $'[11:-2]

import sys, string
import DA
import SQLRelay
classes=DA.classes
meta_types=DA.meta_types
methods=DA.folder_methods
misc_=DA.misc_
__ac_permissions__=DA.__ac_permissions__
