extern "C" {
	#undef __cplusplus
	#include "php.h"
	#define __cplusplus
}
