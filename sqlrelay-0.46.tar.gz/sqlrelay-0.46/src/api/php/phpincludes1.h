extern "C" {
	#include "php.h"
}
