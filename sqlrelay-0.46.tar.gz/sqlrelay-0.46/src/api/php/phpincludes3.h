using namespace std;
#include <iostream>
#include <setjmp.h>
#define HAVE_SOCKLEN_T
#include "php.h"
