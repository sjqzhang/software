#define CAST VALUE(*)()
