#define CAST VALUE(*)(...)
