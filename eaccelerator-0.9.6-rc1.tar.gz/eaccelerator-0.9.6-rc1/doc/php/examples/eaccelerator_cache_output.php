<?php
/**
 * eaccelerator_cache_output example.
 *
 * @package eAccelerator
 */
	eaccelerator_cache_output('test', 'echo time(); phpinfo();', 30);
?>
