<?php
/**
 * eaccelerator_cache_result example.
 *
 * @package eAccelerator
 */
	eaccelerator_cache_result('test', 'time()." Hello";', 30);
?>
