struct snippet1 {
  int i;
};
