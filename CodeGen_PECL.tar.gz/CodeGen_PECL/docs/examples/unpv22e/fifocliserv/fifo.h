#include	"unpipc.h"

#define	SERV_FIFO	"/tmp/fifo.serv"
