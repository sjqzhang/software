struct snippet {
  int i;
};
