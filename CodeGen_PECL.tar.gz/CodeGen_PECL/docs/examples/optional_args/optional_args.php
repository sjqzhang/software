<?php
//if(!extension_loaded('optional_args')) die('skip ');


//print_r(get_loaded_extensions());



dl('optional_args.so');


?>
