/*
   +----------------------------------------------------------------------+
   | unknown license:                                                      |
   +----------------------------------------------------------------------+
   | Authors: Unknown User <unknown@example.com>                          |
   +----------------------------------------------------------------------+
*/

/* $ Id: $ */ 

#include "php_optional_args.h"

#if HAVE_OPTIONAL_ARGS

/* {{{ optional_args_functions[] */
function_entry optional_args_functions[] = {
	PHP_FE(f1                  , f1_arg_info)
	PHP_FE(f2                  , f2_arg_info)
	PHP_FE(f3                  , f3_arg_info)
	{ NULL, NULL, NULL }
};
/* }}} */


/* {{{ optional_args_module_entry
 */
zend_module_entry optional_args_module_entry = {
	STANDARD_MODULE_HEADER,
	"optional_args",
	optional_args_functions,
	PHP_MINIT(optional_args),     /* Replace with NULL if there is nothing to do at php startup   */ 
	PHP_MSHUTDOWN(optional_args), /* Replace with NULL if there is nothing to do at php shutdown  */
	PHP_RINIT(optional_args),     /* Replace with NULL if there is nothing to do at request start */
	PHP_RSHUTDOWN(optional_args), /* Replace with NULL if there is nothing to do at request end   */
	PHP_MINFO(optional_args),
	PHP_OPTIONAL_ARGS_VERSION, 
	STANDARD_MODULE_PROPERTIES
};
/* }}} */

#ifdef COMPILE_DL_OPTIONAL_ARGS
ZEND_GET_MODULE(optional_args)
#endif


/* {{{ PHP_MINIT_FUNCTION */
PHP_MINIT_FUNCTION(optional_args)
{

	/* add your stuff here */

	return SUCCESS;
}
/* }}} */


/* {{{ PHP_MSHUTDOWN_FUNCTION */
PHP_MSHUTDOWN_FUNCTION(optional_args)
{

	/* add your stuff here */

	return SUCCESS;
}
/* }}} */


/* {{{ PHP_RINIT_FUNCTION */
PHP_RINIT_FUNCTION(optional_args)
{
	/* add your stuff here */

	return SUCCESS;
}
/* }}} */


/* {{{ PHP_RSHUTDOWN_FUNCTION */
PHP_RSHUTDOWN_FUNCTION(optional_args)
{
	/* add your stuff here */

	return SUCCESS;
}
/* }}} */


/* {{{ PHP_MINFO_FUNCTION */
PHP_MINFO_FUNCTION(optional_args)
{
	php_printf("The unknown extension\n");
	php_info_print_table_start();
	php_info_print_table_row(2, "Version",PHP_OPTIONAL_ARGS_VERSION " (devel)");
	php_info_print_table_row(2, "Released", "2014-12-22");
	php_info_print_table_row(2, "CVS Revision", "$Id: $");
	php_info_print_table_row(2, "Authors", "Unknown User 'unknown@example.com' (lead)\n");
	php_info_print_table_end();
	/* add your stuff here */

}
/* }}} */


/* {{{ proto int f1([int p1])
   */
PHP_FUNCTION(f1)
{

	long p1 = 0;



	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "|l", &p1) == FAILURE) {
		return;
	}

	do {
		RETURN_LONG(p1);
	} while (0);
}
/* }}} f1 */


/* {{{ proto int f2([int p1 = 23])
   */
PHP_FUNCTION(f2)
{

	long p1 = 23;



	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "|l", &p1) == FAILURE) {
		return;
	}

	do {
		RETURN_LONG(p1);
	} while (0);
}
/* }}} f2 */


/* {{{ proto int f3(int p1 [, int p2 [, int p3]])
   */
PHP_FUNCTION(f3)
{

	long p1 = 0;
	long p2 = 0;
	long p3 = 0;



	if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "l|ll", &p1, &p2, &p3) == FAILURE) {
		return;
	}

	do {
		RETURN_LONG(p1 + p2 + p3);
	} while (0);
}
/* }}} f3 */

#endif /* HAVE_OPTIONAL_ARGS */


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
