struct snippet2 {
  int i;
};
