#!/bin/sh
"@php_bin@" "@php_dir@/CodeGen/PECL/Cli.php" "$@"
