import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.util.ArrayList;
import java.util.Random;

import com.alibaba.fastjson.JSONObject;

public class Test {

	public static long HASH_TAB_MASK = 7L;

	public static int[] task = new int[8];

	public static int[] task2 = new int[8];

	public static int hashKey(long m) {
		return (int) ((m * 157) & HASH_TAB_MASK);
	}

	public static int hashKey2(long m) {
		return (int) (m % (HASH_TAB_MASK + 1));
	}

	public static long[] genData() {
		long[] data = new long[1000000];
		for (int i = 0; i < 1000000; i++) {
			Random random = new Random();
			data[i] = 13000000000L + random.nextInt(48395 - 12483 + 1) + 12483;
		}
		return data;
	}

	public static void setData() {

		ArrayList<String> list = new ArrayList<String>();
		list.add("dfdf");
		list.add("dddddddd");
		JSONObject.toJSONString(list);

	}

	public static void main(String args[]) throws Exception {
		// char[] c = Character.toChars(Integer.parseInt("1f61f", 16));
		// String s1 = new String(c);
		// System.out.println(s1);
		// String s2 = new String(bwritedata(Integer.parseInt("1f61f", 16)));
		// System.out.println(s2);

		// System.out.println(1 / (2 * 3.14 * 1400 * 0.0000001));

		// System.setProperty("java.io.tmpdir", "d:/");

		System.out.println(System.getProperty("java.io.tmpdir"));

		// System.out.println(System.getProperties());

	}

	private final static char[] HEX = "0123456789abcdef".toCharArray();

	public static String bytes2HexString(byte[] bys) {
		char[] chs = new char[bys.length * 2 + bys.length - 1];
		for (int i = 0, offset = 0; i < bys.length; i++) {
			if (i > 0) {
				chs[offset++] = ' ';
			}
			chs[offset++] = HEX[bys[i] >> 4 & 0xf];
			chs[offset++] = HEX[bys[i] & 0xf];
		}
		return new String(chs);
	}

	public static byte[] bwritedata(int data) {
		byte[] bx = new byte[4];
		try {
			DataOutputStream fin;
			ByteArrayOutputStream b = new ByteArrayOutputStream(4);
			fin = new DataOutputStream(b);
			fin.writeInt(data);
			fin.flush();
			fin.close();
			fin = null;
			bx = b.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bx;
	}

	private static String StrToBinstr(String str) {
		char[] strChar = str.toCharArray();
		String result = "";
		for (int i = 0; i < strChar.length; i++) {
			result += Integer.toBinaryString(strChar[i]) + " ";
		}
		return result;
	}
}
/*
 * 124883 124697 125506 124904 125107 124861 124864 125178
 */

/*
 * 124605 125055 125191 125048 125073 125331 125070 124627
 */

/*
 * 285214 286593 285050 286241 285750 286361 284791
 */

/*
 * 143153 142847 142554 142463 142790 142819 143374 0 143153 142463 143374
 * 142554 142819 142847 142790 0
 */

/*
 * 125656 125418 124432 124497 124892 124985 125010 125110 125656 124985 124432
 * 125110 124892 125418 125010 124497
 */