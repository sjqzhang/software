import java.awt.Color;
import java.awt.Font;

import com.meizu.mshow.common.util.ImageUtil;



public class ImageTest {
	
	public static void main( String[] args ) {
		ImageUtil image=ImageUtil.getInstance( "C:/Users/user/Desktop/photo/a.jpg" ) ;
		//ImageUtil image2=ImageUtil.getInstance( "C:/Users/user/Desktop/photo/b.jpg" ) ;
		//image.flipHorizontally();
		//image.flipVertically();
		//image.addPixelColor( 50 );
		//image.addColorToImage( Color.blue, 20 );
		//image.crop( 0, 1000, 2000, 2000 );
		//image.convertToBlackAndWhite();
		//image.multiply( 5, 5 );
		//image.resize( 500, 500 );
		//image.combineWithPicture( image2,8 );
		//image.resize( 50 );
		//image.zip(4);
		Font font=new Font( "Microsoft YaHei",Font.BOLD,360 );
		image.setWaterText( "测试一下", Color.BLACK, font, 30,ImageUtil.TOP_RIGHT );
	
		try {
			image.saveAs(  "C:/Users/user/Desktop/photo/b.jpg" );
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}

}
