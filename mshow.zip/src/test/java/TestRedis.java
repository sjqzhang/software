import redis.clients.jedis.Jedis;

/**
 * 
 * 
 * TestRedis
 * 
 * kin kin 2012-12-3 上午11:15:37
 * 
 * @version 1.0.0
 * 
 */

class Student {

	private String name;
	private int age;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
}

public class TestRedis {

	/**
	 * main(这里用一句话描述这个方法的作用) (这里描述这个方法适用条件 – 可选)
	 * 
	 * @param args
	 *            void
	 * @exception
	 * @since 1.0.0
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Jedis jedis = new Jedis("172.16.10.130");
		// System.out.println(System.currentTimeMillis());
		// jedis.mset("sdfa", "你好吗 sdf asd f");
		// System.out.println(jedis.mget("sdfa"));
		//
		// System.out.println();
		//
		// new Thread(new Runnable() {
		// Jedis jedis = new Jedis("172.16.10.130");
		// JedisPubSub jedisPubSub = new JedisPubSub() {
		//
		// @Override
		// public void onUnsubscribe(String channel, int subscribedChannels) {
		// // TODO Auto-generated method stub
		//
		// }
		//
		// @Override
		// public void onSubscribe(String channel, int subscribedChannels) {
		// // TODO Auto-generated method stub
		//
		// }
		//
		// @Override
		// public void onPUnsubscribe(String pattern, int subscribedChannels) {
		// // TODO Auto-generated method stub
		//
		// }
		//
		// @Override
		// public void onPSubscribe(String pattern, int subscribedChannels) {
		// // TODO Auto-generated method stub
		//
		// }
		//
		// @Override
		// public void onPMessage(String pattern, String channel, String
		// message) {
		// // TODO Auto-generated method stub
		// System.out.println(message);
		// }
		//
		// @Override
		// public void onMessage(String channel, String message) {
		// // TODO Auto-generated method stub
		//
		// System.out.println(message);
		//
		// }
		// };
		//
		// @Override
		// public void run() {
		// // TODO Auto-generated method stub
		// jedis.subscribe(jedisPubSub, "aa");
		// }
		// }).start();

		// jedis.publish("aa", "AAAAAAAAAAAAA");

		// jedisPubSub.proceed(jedis.getClient(), "aa");

		// HashMap<String, Object> map = new HashMap<String, Object>();
		// map.put("abc", "hello");
		// map.put("bb", 35);
		//
		// jedis.hset("map", "abc", map.get("abc").toString());
		// jedis.hset("map", "bb", map.get("bb").toString());
		//
		// System.out.println(jedis.hget("map", "abc"));

		// jedis.hmget("qqqq", "aa=>av", "bb=>bv");
		//
		// System.out.println(jedis.hget("qqqq", "bb"));

		// jedis.mset("redis_mset", "redis", "xxxxxxxxxxxx", "ddd");
		// jedis.hset("weibo", "nickname", "admin"); // 设置昵称
		// jedis.hset("weibo", "password", "admin"); // 设置密码
		// jedis.hset("weibo", "fans", "200"); // 设置粉丝数
		// jedis.hset("weibo", "sweets", "555"); // 设置微博数

		// jedis.lpush("abc", "adf", "abc", "dfasdfasd");
		// String[] s = { "abc", "cd3", "cfg" };
		// jedis.lpush("abc", s);
		// HashMap<String, String> map = new HashMap<String, String>();
		// map.put("abc", "hello");
		// map.put("bb", "aaa");
		// jedis.hmset("aaxx", map);
		//
		// jedis.lpush("abcdef", "sdfasdfasdfasdfasdfasd");
		// jedis.lpush("abcdef", "xxxxxxxxxxxxxxxxxxxxxxxx");
		//
		// while (true) {
		// }

		char[] cc = Character.toChars(57344);

		String t = new String(cc);

		System.out.println(t.getBytes());

	}
}
