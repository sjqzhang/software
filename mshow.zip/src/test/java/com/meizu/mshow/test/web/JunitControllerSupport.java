/**
 * 
 */
package com.meizu.mshow.test.web;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.servlet.mvc.annotation.AnnotationMethodHandlerAdapter;
import org.unitils.UnitilsJUnit4;
import org.unitils.spring.annotation.SpringApplicationContext;
import org.unitils.spring.annotation.SpringBeanByType;

import com.alibaba.fastjson.serializer.SerializerFeature;
import com.meizu.mshow.common.util.MappingFastJsonHttpMessageConverter;
import com.meizu.mshow.common.util.ServiceLocator;

/**
 * Controller层单元测试基类
 * 
 * @author anyuan
 * @version 1.0
 * @date 2013-5-30 下午2:42:15
 */
@SpringApplicationContext({ "classpath*:*.xml" })
public class JunitControllerSupport extends UnitilsJUnit4 {

	// 从Spring容器中加载AnnotationMethodHandlerAdapter
	@SpringBeanByType
	protected AnnotationMethodHandlerAdapter handlerAdapter;
	@SpringApplicationContext
	protected ApplicationContext applicationContext;

	// 声明Request与Response模拟对象
	protected MockHttpServletRequest request;
	protected MockHttpServletResponse response;

	@SuppressWarnings("rawtypes")
	@Before
	public void before() {
		ServiceLocator.getInstance().setContext(applicationContext);

		// 加载converter
		SerializerFeature[] serializerFeature = {
				SerializerFeature.WriteMapNullValue,
				SerializerFeature.QuoteFieldNames };

		MappingFastJsonHttpMessageConverter converter = new MappingFastJsonHttpMessageConverter();
		converter.setSerializerFeature(serializerFeature);
		HttpMessageConverter[] messageConverters = { converter };
		handlerAdapter.setMessageConverters(messageConverters);

		// 执行测试前先初始模拟对象
		request = new MockHttpServletRequest();
		request.setCharacterEncoding("UTF-8");
		response = new MockHttpServletResponse();		
	}
	
	@Test
	public void testA(){}
}
