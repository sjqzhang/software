/**
 * 
 */
package com.meizu.mshow.test.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;
import com.meizu.mshow.domain.pojo.TImgActivity;
import com.meizu.mshow.picture.business.ActivityService;

/**
 * @author anyuan
 * @version 1.0
 * @date 2013-5-24 上午11:21:18
 */
public class ActivityServiceTest extends JunitServiceSupport {

	ActivityService activityService;

	@Before
	public void init() {
		super.init();
		activityService = applicationContext.getBean(ActivityService.class);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.ActivityServiceImpl#loadActivityViaActivityId(java.lang.Long)}
	 * .
	 */
	@Test
	public void testLoadActivityViaActivityId() {
		TImgActivity activity = activityService.loadActivityViaActivityId(2L);

		Assert.assertNotNull(activity);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.ActivityServiceImpl#loadActivityList(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testLoadActivityList() {
		QueryModel model = new QueryModel();
		Map map = new HashMap<String, Integer>();
		map.put("posId", 3);
		model.setCondition(map);
		List<TImgActivity> list = activityService.loadActivityList(model);

		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.ActivityServiceImpl#loadPictureViaAcitivity(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testLoadPictureViaAcitivity() {
		QueryModel model = new QueryModel();
		Map map = new HashMap<String, Integer>();
		map.put("activityId", 2);
		model.setCondition(map);
		List<PicturePlazaModel> list = activityService
				.loadPictureViaAcitivity(model);

		Assert.assertNotNull(list);
	}

}
