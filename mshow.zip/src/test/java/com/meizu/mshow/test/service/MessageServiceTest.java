/**
 * 
 */
package com.meizu.mshow.test.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.MessageModel;
import com.meizu.mshow.test.service.JunitServiceSupport;
import com.meizu.mshow.user.business.MessageService;

/**
 * @author anyuan
 * @version 1.0
 * @date 2013-5-24 上午11:09:37
 */
public class MessageServiceTest extends JunitServiceSupport {

	MessageService messageService;

	@Before
	public void init() {
		super.init();
		messageService = applicationContext.getBean(MessageService.class);
		/**
		 * set mc_5 1 1
		 */
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.user.business.MessageServiceImpl#createMessage(com.meizu.mshow.domain.model.MessageModel)}
	 * .
	 */
	@Test
	public void testCreateMessage() {
		MessageModel model = new MessageModel();
		model.setDestUserId(5L);
		model.setUserId(1001L);
		model.setAliasName("anyuan");
		messageService.createMessage(model);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.user.business.MessageServiceImpl#loadMessageList(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testLoadMessageList() {
		QueryModel model = new QueryModel();
		Map map = new HashMap<String, Integer>();
		map.put("userId", 5);
		model.setCondition(map);
		List<MessageModel> list = messageService.loadMessageList(model);

		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.user.business.MessageServiceImpl#deleteMessage(java.lang.Long, java.lang.Long)}
	 * .
	 */
	@Test
	public void testDeleteMessage() {
		messageService.deleteMessage(1462350L, 5L);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.user.business.MessageServiceImpl#loadNewMessageCount(java.lang.Long)}
	 * .
	 */
	@Test
	public void testLoadNewMessageCount() {
		int result = messageService.loadNewMessageCount(5L);

		Assert.assertTrue(result >= 0);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.user.business.MessageServiceImpl#loadUserMessageTotalCount(long)}
	 * .
	 */
	@Test
	public void testLoadUserMessageTotalCount() {
		int result = messageService.loadUserMessageTotalCount(5L);

		Assert.assertTrue(result >= 0);
	}

}
