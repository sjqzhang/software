/**
 * 
 */
package com.meizu.mshow.test.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;
import com.meizu.mshow.picture.business.PicturePlazaService;
import com.meizu.mshow.test.service.JunitServiceSupport;

/**
 * @author anyuan
 * @version 1.0
 * @date 2013-5-24 上午11:22:04
 */
public class PicturePlazaServiceTest extends JunitServiceSupport {

	PicturePlazaService picturePlazaService;

	@Before
	public void init() {
		super.init();
		picturePlazaService = applicationContext
				.getBean(PicturePlazaService.class);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PicturePlazaServiceImpl#loadHot(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "rawtypes" })
	@Test
	public void testLoadHot() {
		QueryModel model = new QueryModel();
		Map map = new HashMap<String,Object>();		
		model.setCondition(map);
		List<PicturePlazaModel> list = picturePlazaService.loadHot(model);
		
		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PicturePlazaServiceImpl#loadNew(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings("rawtypes")
	@Test
	public void testLoadNew() {
		QueryModel queryModel=new QueryModel();
		Map map=new HashMap<String,Object>();
		queryModel.setCondition(map);
		List<PicturePlazaModel> list = picturePlazaService.loadNew(queryModel);
		
		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PicturePlazaServiceImpl#loadTagImage(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testLoadTagImage() {
		QueryModel queryModel=new QueryModel();
		Map map=new HashMap<String,Object>();
		map.put("tagId", 232L);
		map.put("posId", 317L);
		queryModel.setCondition(map);
		List<PicturePlazaModel> list = picturePlazaService.loadTagImage(queryModel);
		
		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PicturePlazaServiceImpl#loadImgViaCity(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "rawtypes" })
	@Test
	public void testLoadImgViaCity() {
		
		QueryModel queryModel=new QueryModel();
		Map map=new HashMap<String,Object>();
		queryModel.setCondition(map);
		List<PicturePlazaModel> list = picturePlazaService.loadImgViaCity(queryModel);
		
		Assert.assertNotNull(list);
	}

}
