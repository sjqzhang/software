/**
 * 
 */
package com.meizu.mshow.test.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.meizu.mshow.common.util.DateUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.SearchModel;
import com.meizu.mshow.domain.model.UserModel;
import com.meizu.mshow.domain.pojo.TImgTag;
import com.meizu.mshow.domain.pojo.TSysUnituser;
import com.meizu.mshow.domain.pojo.TSysUser;
import com.meizu.mshow.test.service.JunitServiceSupport;
import com.meizu.mshow.user.business.UserService;

/**
 * @author anyuan
 * @version 1.0
 * @date 2013-5-24 上午11:10:12
 */
public class UserServiceTest extends JunitServiceSupport {

	UserService userService;

	@Before
	public void init() {
		super.init();
		userService = applicationContext.getBean(UserService.class);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.user.business.UserServiceImpl#createUser(com.meizu.mshow.domain.model.UserModel)}
	 * .
	 */
	@Test
	public void testCreateUser() {
		UserModel userModel=new UserModel();
		TSysUser user=new TSysUser();
		user.setUserId(DateUtil.getNow().getTime());
		user.setUserName("anyuan");
		user.setEmail("anyuan@meizu.com");
		userModel.setUser(user);
		
		List<TSysUnituser> unitUserList=new ArrayList<TSysUnituser>();
		TSysUnituser unitUser=new TSysUnituser();
		unitUser.setUnituserId(DateUtil.getNow().getTime());
		
		unitUserList.add(unitUser);
		userModel.setUnitUser(unitUserList);
		
		userService.createUser(userModel);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.user.business.UserServiceImpl#loadUserViaUserId(java.lang.Long)}
	 * .
	 */
	@Test
	public void testLoadUserViaUserId() {
		UserModel userModel = userService.loadUserViaUserId(1001L);
		
		Assert.assertNotNull(userModel);		
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.user.business.UserServiceImpl#updateUser(com.meizu.mshow.domain.model.UserModel)}
	 * .
	 */
	@Test
	public void testUpdateUser() {
		UserModel userModel=new UserModel();
		TSysUser user=new TSysUser();
		user.setUserId(1001L);
		user.setAliasName("anyuan");
		user.setComment("test");
		userModel.setUser(user);
		
		userService.updateUser(userModel);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.user.business.UserServiceImpl#searchUser(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@Test
	public void testSearchUser() {
		QueryModel keyword=new QueryModel();
		HashMap<String,Object> condition=new HashMap<String,Object>();
		condition.put("keyWord", "test");
		keyword.setCondition(condition);
		SearchModel model = userService.searchUser(keyword);
		
		Assert.assertNotNull(model);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.user.business.UserServiceImpl#updateUserHeadIcon(org.springframework.web.multipart.MultipartFile, com.meizu.mshow.domain.model.UserModel)}
	 * .
	 */
	@Test
	public void testUpdateUserHeadIcon() {
		
		UserModel userModel=new UserModel();
		TSysUser user=new TSysUser();
		user.setUserId(1001L);
		userModel.setUser(user);
		userService.updateUserHeadIcon(null, userModel);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.user.business.UserServiceImpl#updateUserLocation(com.meizu.mshow.domain.pojo.TSysUser)}
	 * .
	 */
	@Test
	public void testUpdateUserLocation() {
		TSysUser user=new TSysUser();
		user.setUserId(1001L);
		user.setIp("127.0.0.1");
		user.setContinent("continent");
		user.setCountry("china");
		user.setProvince("guangdong");
		user.setCity("zhuhai");
		user.setDistrict("test");
		user.setStreet("test");
		user.setStreetNumber("0756");
		user.setLng(136.489786);
		user.setLat(253.123435);
		
		userService.updateUserLocation(user);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.user.business.UserServiceImpl#loadUserPinedTags(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@Test
	public void testLoadUserPinedTags() {
		QueryModel queryModel=new QueryModel();
		HashMap<String,Object> condition=new HashMap<String,Object>();
		condition.put("userId", "1462350");		
		queryModel.setCondition(condition);		
		List<TImgTag> list = userService.loadUserPinedTags(queryModel);
		
		Assert.assertNotNull(list);
	}

}
