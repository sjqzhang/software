/**
 * 
 */
package com.meizu.mshow.test.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.TimerModel;
import com.meizu.mshow.picture.business.TimerService;
import com.meizu.mshow.test.service.JunitServiceSupport;

/**
 * @author anyuan
 * @version 1.0
 * @date 2013-5-24 上午11:23:39
 */
public class TimerServiceTest extends JunitServiceSupport {

	TimerService timerService;

	@Before
	public void init() {
		super.init();
		timerService = applicationContext.getBean(TimerService.class);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.TimerServiceImpl#loadPrt(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testLoadPrt() {
		QueryModel queryModel = new QueryModel();
		Map map = new HashMap<String, Integer>();
		map.put("commentWeight", 1);
		map.put("likeWeight", 1);
		map.put("vewWeight", 1);
		queryModel.setCondition(map);
		List list = timerService.loadPrt(queryModel);

		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.TimerServiceImpl#loadHotWithTime(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testLoadHotWithTime() {
		QueryModel queryModel = new QueryModel();
		Map map = new HashMap<String, Integer>();
		map.put("commentWeight", 1);
		map.put("likeWeight", 1);
		map.put("vewWeight", 1);
		map.put("cdate", 1365985458);
		queryModel.setCondition(map);
		List list = timerService.loadHotWithTime(queryModel);

		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.TimerServiceImpl#loadTagHotImage(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testLoadTagHotImage() {
		QueryModel queryModel = new QueryModel();
		Map map = new HashMap<String, Integer>();
		map.put("commentWeight", 1);
		map.put("likeWeight", 1);
		map.put("vewWeight", 1);
		map.put("cdate", 1365985458);
		map.put("tagId", 9728);
		queryModel.setCondition(map);
		List<TimerModel> list = timerService.loadTagHotImage(queryModel);

		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.TimerServiceImpl#loadTagNewImage(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testLoadTagNewImage() {
		QueryModel queryModel = new QueryModel();
		Map map = new HashMap<String, Integer>();
		map.put("commentWeight", 1);
		map.put("likeWeight", 1);
		map.put("vewWeight", 1);
		map.put("cdate", 1365985458);
		map.put("tagId", 9728);
		queryModel.setCondition(map);
		List<TimerModel> list = timerService.loadTagNewImage(queryModel);

		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.TimerServiceImpl#createHot(java.util.List)}
	 * .
	 */
	@Test
	public void testCreateHot() {
		List<TimerModel> list = new ArrayList<TimerModel>();
		TimerModel model = new TimerModel();
		model.setImgId(19399L);
		list.add(model);
		timerService.createHot(list);
	}

}
