/**
 * 
 */
package com.meizu.mshow.test.service;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.meizu.mshow.domain.pojo.UploadSetting;
import com.meizu.mshow.system.business.UploadSettingService;

/**
 * @author anyuan
 * @version 1.0
 * @date 2013-5-24 上午11:31:19
 */
public class UploadSettingServiceTest extends JunitServiceSupport {

	UploadSettingService uploadSettingService;

	@Before
	public void init() {
		super.init();
		uploadSettingService = applicationContext
				.getBean(UploadSettingService.class);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.system.business.UploadSettingServiceImpl#getSettingByFileClass(java.lang.String)}
	 * .
	 */
	@Test
	public void testGetSettingByFileClass() {
		UploadSetting setting = uploadSettingService.getSettingByFileClass("img");
		
		Assert.assertNotNull(setting);
	}	

	/**
	 * Test method for
	 * {@link com.meizu.mshow.system.business.UploadSettingServiceImpl#createSetting(com.meizu.mshow.domain.pojo.UploadSetting)}
	 * .
	 */
	@Test
	public void testCreateSetting() {
		UploadSetting setting = new UploadSetting();
		setting.setFileClass("jpg");
		setting.setFilePath("/mnt/jpg/");
		setting.setFileCount(0);
		setting.setFileMax(1000);
		setting.setFileDir("00000003");
		setting.setIsActive(1);
		uploadSettingService.createSetting(setting);
	
	}

}
