package com.meizu.mshow.test.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.UserMarkModel;
import com.meizu.mshow.domain.pojo.TSysUser;
import com.meizu.mshow.test.service.JunitServiceSupport;
import com.meizu.mshow.user.business.UserMarkService;

/**
 * @author	anyuan 
 * @version	1.0
 * @date	2013-5-21
 */
public class UserMarkServiceTest extends JunitServiceSupport {

	UserMarkService userMarkService;

	@Before
	public void init() {
		super.init();
		userMarkService = applicationContext.getBean(UserMarkService.class);
		/**
		 * 向redis中写入数据：
		 * zadd ums_5 1 1000
		 * zadd ums_5 2 2000
		 * zadd ums_5 3 3000
		 * zadd ufs_5 1 100
		 * zadd ufs_5 2 200
		 */
	}

	@Test
	public void testCreateUserMark() {		

		TSysUser user = new TSysUser();
		user.setUserId(1001L);
		user.setUserName("anyuan");
		user.setCdate(1355207973);

		UserMarkModel markModel = new UserMarkModel();
		markModel.setUserId(1001L);
		markModel.setDestUserId(1001L);
		userMarkService.createUserMark(user, markModel);		
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testLoadUserMarkList() {
		QueryModel queryModel = new QueryModel();
		queryModel.setStart(0);
		queryModel.setLimit(10);
		queryModel.setSortColName("");
		queryModel.setSortType("asc");
		queryModel.setPageForward("asc");
		Map condition = new HashMap();
		condition.put("userId", 5);
		condition.put("posId", 100);
		queryModel.setCondition(condition);
		List<UserMarkModel> list = userMarkService.loadUserMarkList(queryModel);

		Assert.assertNotNull(list);
	}

	@Test
	public void testLoadUserHotCount() {			
		int result = userMarkService.loadUserHotCount(5);
		
		Assert.assertTrue(result > 0);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testLoadFollowedUser() {

		QueryModel queryModel = new QueryModel();
		queryModel.setStart(0);
		queryModel.setLimit(10);
		queryModel.setSortColName("");
		queryModel.setSortType("asc");
		queryModel.setPageForward("asc");
		Map condition = new HashMap();
		condition.put("userId", 5);				
		queryModel.setCondition(condition);
		List<TSysUser> list = userMarkService.loadFollowedUser(queryModel);
		
		Assert.assertNotNull(list);
	}

}
