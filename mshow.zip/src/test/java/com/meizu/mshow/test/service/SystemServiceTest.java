/**
 * 
 */
package com.meizu.mshow.test.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.pojo.TBsArea;
import com.meizu.mshow.domain.pojo.TSysUpdate;
import com.meizu.mshow.system.business.SystemService;
import com.meizu.mshow.test.service.JunitServiceSupport;

/**
 * @author anyuan
 * @version 1.0
 * @date 2013-5-24 上午11:30:40
 */
public class SystemServiceTest extends JunitServiceSupport {

	SystemService systemService;

	@Before
	public void init() {
		super.init();
		systemService = applicationContext.getBean(SystemService.class);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.system.business.SystemServiceImpl#checkUpdate(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testCheckUpdate() {
		QueryModel query=new QueryModel();
		Map map=new HashMap<String,Integer>();
		map.put("version", 0);
		query.setCondition(map);
		TSysUpdate result = systemService.checkUpdate(query);
		
		Assert.assertNotNull(result);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.system.business.SystemServiceImpl#loadByFingerprint(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testLoadByFingerprint() {
		QueryModel query=new QueryModel();
		Map map=new HashMap<String,Integer>();
		map.put("fingerprint", 1);
		query.setCondition(map);
		Map<String,Object> result = systemService.loadByFingerprint(query);
		
		Assert.assertNotNull(result);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.system.business.SystemServiceImpl#getProvice()}.
	 */
	@SuppressWarnings("rawtypes")
	@Test
	public void testGetProvice() {
		List<Map> list = systemService.getProvice();
		
		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.system.business.SystemServiceImpl#getCityById(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetCityById() {
		QueryModel query=new QueryModel();
		Map map=new HashMap<String,Integer>();
		map.put("pid", 0);
		query.setCondition(map);
		List<Map> list = systemService.getCityById(query);
		
		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.system.business.SystemServiceImpl#loadTBsAreaViaCityName(java.lang.String)}
	 * .
	 */
	@Test
	public void testLoadTBsAreaViaCityName() {
		TBsArea area = systemService.loadTBsAreaViaCityName("北京");
		
		Assert.assertNotNull(area);
	}

}
