/**
 * 
 */
package com.meizu.mshow.test.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import com.meizu.mshow.common.util.DateUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.form.TImgBreakpoint;
import com.meizu.mshow.domain.model.PictureModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;
import com.meizu.mshow.domain.model.SearchModel;
import com.meizu.mshow.domain.pojo.TImgComment;
import com.meizu.mshow.domain.pojo.TImgComplain;
import com.meizu.mshow.domain.pojo.TImgLike;
import com.meizu.mshow.domain.pojo.TImgPicture;
import com.meizu.mshow.domain.pojo.TImgTag;
import com.meizu.mshow.domain.pojo.TImgViewlog;
import com.meizu.mshow.picture.business.PictureService;

/**
 * @author anyuan
 * @version 1.0
 * @date 2013-5-24 上午11:22:52
 */
public class PictureServiceTest extends JunitServiceSupport {

	PictureService pictureService;

	@Before
	public void init() {
		super.init();
		pictureService = applicationContext.getBean(PictureService.class);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#loadPictureViaImgId(java.lang.Long)}
	 * .
	 */
	@Test
	public void testLoadPictureViaImgId() {
		TImgPicture img = pictureService.loadPictureViaImgId(2L);

		Assert.assertNotNull(img);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#upload(org.springframework.web.multipart.MultipartFile, com.meizu.mshow.domain.model.PictureModel, int)}
	 * .
	 */
	@Test
	public void testUpload() {
		PictureModel model = new PictureModel();
		TImgPicture picture = new TImgPicture();
		picture.setUserId(1462350L);
		model.setPicture(picture);
		// pictureService.upload(null, model, 1);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#createLike(com.meizu.mshow.domain.pojo.TImgLike)}
	 * .
	 */
	@Test
	public void testCreateLike() {
		TImgLike like = new TImgLike();
		like.setUserId(4245124L);
		like.setImgId(2L);
		pictureService.createLike(like);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#createComment(com.meizu.mshow.domain.pojo.TImgComment)}
	 * .
	 */
	@Test
	public void testCreateComment() {
		TImgComment comment = new TImgComment();
		comment.setUserId(1462350L);
		comment.setImgId(1L);
		pictureService.createComment(comment);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#loadCommentList(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testLoadCommentList() {
		QueryModel model = new QueryModel();
		Map map = new HashMap<String, Long>();
		map.put("imgid", 1L);
		model.setCondition(map);
		List<TImgComment> list = pictureService.loadCommentList(model);

		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#searchPicture(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testSearchPicture() {
		QueryModel keyword = new QueryModel();
		Map map = new HashMap<String, String>();
		map.put("keyWord", "test");
		keyword.setCondition(map);
		SearchModel result = pictureService.searchPicture(keyword);

		Assert.assertNotNull(result);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#searchPic(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testSearchPic() {
		QueryModel keyword = new QueryModel();
		Map map = new HashMap<String, String>();
		map.put("keyWord", "test");
		keyword.setCondition(map);
		List<TImgPicture> list = pictureService.searchPic(keyword);

		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#searchTag(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testSearchTag() {
		QueryModel keyword = new QueryModel();
		Map map = new HashMap<String, String>();
		map.put("keyWord", "test");
		keyword.setCondition(map);
		SearchModel result = pictureService.searchTag(keyword);

		Assert.assertNotNull(result);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#loadPictureByUserId(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testLoadPictureByUserId() {
		QueryModel model = new QueryModel();
		Map map = new HashMap<String, Long>();
		map.put("userId", 1462350L);
		model.setCondition(map);
		List<PicturePlazaModel> list = pictureService.loadPictureByUserId(model);

		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#loadTagList(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@Test
	public void testLoadTagList() {
		QueryModel model = new QueryModel();
		model.setCondition(1);
		List<TImgTag> list = pictureService.loadTagList(model);

		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#deletePictureViaImgId(java.lang.Long)}
	 * .
	 */
	@Test
	public void testDeletePictureViaImgId() {
		pictureService.deletePictureViaImgId(3L);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#loadComplainViaImgIdAndUserId(java.lang.Long, java.lang.Long)}
	 * .
	 */
	@Test
	public void testLoadComplainViaImgIdAndUserId() {
		TImgComplain result = pictureService.loadComplainViaImgIdAndUserId(19290L, 4245137L);

		Assert.assertNotNull(result);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#createComplain(com.meizu.mshow.domain.pojo.TImgComplain)}
	 * .
	 */
	@Test
	public void testCreateComplain() {
		TImgComplain complain = new TImgComplain();
		complain.setUserId(1001L);
		complain.setImgId(5L);
		complain.setCdate(1432564321);
		complain.setStatus(1);
		pictureService.createComplain(complain);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#loadLikeListViaImgId(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testLoadLikeListViaImgId() {
		QueryModel queryModel = new QueryModel();
		Map map = new HashMap<String, Integer>();
		map.put("imgId", 19399);
		queryModel.setCondition(map);
		List<TImgLike> list = pictureService.loadLikeListViaImgId(queryModel);

		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#loadTagsViaImgId(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testLoadTagsViaImgId() {
		QueryModel queryModel = new QueryModel();
		Map map = new HashMap<String, Integer>();
		map.put("imgId", 19399);
		queryModel.setCondition(map);
		List<TImgTag> list = pictureService.loadTagsViaImgId(queryModel);

		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#createViewLog(com.meizu.mshow.domain.pojo.TImgViewlog)}
	 * .
	 */
	@Test
	public void testCreateViewLog() {
		TImgViewlog log = new TImgViewlog();
		log.setUserId(1001L);
		log.setCookieId("test1001");
		log.setImgId(2L);
		log.setCdate(1635265362);
		pictureService.createViewLog(log);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#createTagForImage(com.meizu.mshow.domain.pojo.TImgTag)}
	 * .
	 */
	@Test
	public void testCreateTagForImage() {
		TImgTag tag = new TImgTag();
		tag.setUserId(1462350L);
		tag.setImgId(-1L);
		tag.setTagName("tag232");
		pictureService.createTagForImage(tag);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#createBreakpoint(com.meizu.mshow.domain.form.TImgBreakpoint)}
	 * .
	 */
	@Test
	public void testCreateBreakpoint() {
		TImgBreakpoint breakpoint = new TImgBreakpoint();
		breakpoint.setUserId(1L);
		breakpoint.setCdate(DateUtil.getNow().getTime() / 1000);
		breakpoint.setFileName("aa");
		breakpoint.setFileSize(128L);
		breakpoint.setFingerprint("bb");
		breakpoint.setStatus(0);
		breakpoint.setTmpPath("/mnt/bp/");
		pictureService.createBreakpoint(breakpoint);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#loadPhotoForMap(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings("rawtypes")
	@Test
	public void testLoadPhotoForMap() {
		QueryModel query = new QueryModel();
		List<HashMap> list = pictureService.loadPhotoForMap(query);

		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#loadPhotoForMapHot(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings("rawtypes")
	@Test
	public void testLoadPhotoForMapHot() {
		QueryModel query = new QueryModel();
		List<HashMap> list = pictureService.loadPhotoForMapHot(query);

		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#loadLikePictureByUserId(com.meizu.mshow.common.util.QueryModel)}
	 * .
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testLoadLikePictureByUserId() {
		QueryModel model = new QueryModel();
		Map map = new HashMap<String, Integer>();
		map.put("userId", 4790312);
		model.setCondition(map);
		List<PicturePlazaModel> list = pictureService.loadLikePictureByUserId(model);

		Assert.assertNotNull(list);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#validateTagName(java.lang.String)}
	 * .
	 */
	@Test
	public void testValidateTagName() {
		Boolean result = pictureService.validateTagName("a");

		Assert.assertTrue(result);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#loadLikeViaImgIdAndUserId(long, long)}
	 * .
	 */
	@Test
	public void testLoadLikeViaImgIdAndUserId() {

		TImgLike result = pictureService.loadLikeViaImgIdAndUserId(2L, 4245124L);

		Assert.assertNotNull(result);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#deleteLikeViaImgIdAndUserId(java.lang.Long, long)}
	 * .
	 */
	@Test
	public void testDeleteLikeViaImgIdAndUserId() {
		pictureService.deleteLikeViaImgIdAndUserId(0L, 1001L);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#loadCommentViaCommentId(java.lang.Long)}
	 * .
	 */
	@Test
	public void testLoadCommentViaCommentId() {
		TImgComment result = pictureService.loadCommentViaCommentId(3L);

		Assert.assertNotNull(result);
	}

	/**
	 * Test method for
	 * {@link com.meizu.mshow.picture.business.PictureServiceImpl#deleteComment(com.meizu.mshow.domain.pojo.TImgComment)}
	 * .
	 */
	@Test
	public void testDeleteComment() {
		TImgComment comment = new TImgComment();
		comment.setImgId(5L);
		comment.setUserId(1283335L);
		comment.setCommentId(22L);
		pictureService.deleteComment(comment);
	}

}
