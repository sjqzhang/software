package com.meizu.mshow.test.web;

import java.io.RandomAccessFile;

import javax.servlet.http.HttpSession;

import org.junit.Test;
import org.springframework.util.Assert;
import org.unitils.spring.annotation.SpringBeanByType;

import com.alibaba.fastjson.JSONObject;
import com.meizu.mshow.common.base.BaseResultModel;
import com.meizu.mshow.common.util.DateUtil;
import com.meizu.mshow.upload.web.ImageUploadController;

/**
 * @author anyuan
 * @version 1.0
 * @date 2013-5-30 下午3:06:51
 */
public class ImageUploadControllerTest extends JunitControllerSupport {
	
	@SpringBeanByType
	private ImageUploadController imageUploadController;
	private String fileId = "";
	private long nPos = 0L;

	@Test
	public void testUpload() throws Exception {
		request.setRequestURI("/browser/preupload");
		HttpSession session = request.getSession();
		session.setAttribute("SESSION_USER_ID", 1001L);
		request.setSession(session);
		request.setParameter("fileId", fileId);
		handlerAdapter.handle(request, response, imageUploadController);
		String value = new String(response.getContentAsByteArray(), "UTF-8");
		BaseResultModel model = JSONObject.parseObject(value,
				BaseResultModel.class);
		String rvalue = model.getReturnValue().toString();
		try {
			this.nPos = Long.parseLong(rvalue);
		} catch (NumberFormatException e) {
			this.fileId = rvalue;
		}
		Assert.isTrue(model.getReturnCode() == 0);
		Assert.hasLength(upload());
	}

	
	private String upload() throws Exception {
		String path = getClass().getResource("/1.jpg").getPath();
		RandomAccessFile f = new RandomAccessFile(path, "r");
		request.setRequestURI("/browser/upload");
		request.setParameter("nLen", String.valueOf(f.length()));
		request.setParameter("fileId", fileId);
		request.setParameter("fileName", "1.jpg");
		request.setParameter("cdate",
				String.valueOf(DateUtil.getNow().getTime() / 1000));

		f.seek(nPos);
		int nRead = 0;
		byte[] buffer = new byte[10240];
		while ((nRead = f.read(buffer)) > 0) {
			if (nRead != buffer.length) {
				byte[] data = new byte[nRead];
				for (int i = 0; i < nRead; i++) {
					data[i] = buffer[i];
				}
				request.setContent(data);
			} else {
				request.setContent(buffer);
			}

			request.setParameter("nPos", String.valueOf(nPos));
			handlerAdapter.handle(request, response, imageUploadController);
			
			nPos += nRead;
		}
		f.close();
		f = null;
		String str = new String(response.getContentAsByteArray(), "UTF-8");
		return str;
	}
}
