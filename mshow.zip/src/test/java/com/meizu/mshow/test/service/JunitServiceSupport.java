/**
 * 
 */
package com.meizu.mshow.test.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.meizu.mshow.common.util.ServiceLocator;

/**
 * @author anyuan
 * @version 1.0
 * @date 2013-5-23 下午1:40:44
 */
public class JunitServiceSupport {

	protected static ApplicationContext applicationContext = null;
	
	public void init() {
		if (applicationContext == null) {
			applicationContext = new ClassPathXmlApplicationContext(
					"classpath*:*.xml");
			ServiceLocator.getInstance().setContext(applicationContext);
		}
	}
}
