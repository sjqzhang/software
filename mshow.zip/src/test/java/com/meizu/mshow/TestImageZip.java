/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow<br/>
 * <b>文件名：</b>TestImageZip.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2012-12-5-下午5:10:39<br/>
 * <b>Copyright (c)</b> 2012魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow;

import java.io.File;

import com.meizu.mshow.common.util.ImageUtil;

/**
 * <b>类名称：</b>TestImageZip<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-5 下午5:10:39<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public class TestImageZip {

	public static void main(String[] args) {

		String baseDir = "D:/photo/";

		File f = new File(baseDir + "a");

		String[] list = f.list();

		for (int i = 0; i < list.length; i++) {
			System.out.println(list[i]);

			ImageUtil image = ImageUtil.getInstance(baseDir + "a/" + list[i]);

			// image.resize380();
			image.resizeByHeight(100);

			try {
				image.saveAs(baseDir + "c/" + list[i]);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}
}
