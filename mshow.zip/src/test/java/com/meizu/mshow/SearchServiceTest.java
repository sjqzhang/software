/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow<br/>
 * <b>文件名：</b>SearchServiceTest.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2012-12-14-上午11:16:32<br/>
 * <b>Copyright (c)</b> 2012魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow;

import org.junit.Test;

/**
 * <b>类名称：</b>SearchServiceTest<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-14 上午11:16:32<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public class SearchServiceTest extends TestBase {

	@Test
	public void searchPicture() {
		// PictureService pictureService = getBean(PictureService.class);
		// QueryModel model = new QueryModel();
		// model.getCondition(Map.class).put("keyWord", "a");
		// SearchModel model2 = pictureService.searchPicture(model);
		// Assert.assertTrue(model2.getList().size() > 0);
	}

	@Test
	public void searchTag() {
		// PictureService pictureService = getBean(PictureService.class);
		// QueryModel model = new QueryModel();
		// model.getCondition(Map.class).put("keyWord", "a");
		// SearchModel model2 = pictureService.searchTag(model);
		// Assert.assertTrue(model2.getList().size() > 0);
	}
}
