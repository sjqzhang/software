/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow<br/>
 * <b>文件名：</b>TestUpload.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2012-12-5-下午4:30:13<br/>
 * <b>Copyright (c)</b> 2012魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.ParseException;

/**
 * <b>类名称：</b>TestUpload<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-5 下午4:30:13<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public class TestUpload {

	private static int port = 8080;

	public static void main(String[] arg) throws ParseException {
		TestUpload client = new TestUpload();
		Socket socket;
		try {
			socket = new Socket("localhost", port);
			BufferedWriter wr = new BufferedWriter(new OutputStreamWriter(
					socket.getOutputStream(), "UTF8"));
			InputStream ins = socket.getInputStream();
			StringBuffer sb = new StringBuffer();
			sb = client.upload();
			wr.write(sb.toString());
			wr.flush();

			System.out.println(sb.toString());
			BufferedReader rd = new BufferedReader(new InputStreamReader(ins));
			String line = null;
			while ((line = rd.readLine()) != null) {
				System.out.println(line);
			}

			rd.close();

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public StringBuffer upload() {
		StringBuffer fsb = new StringBuffer();
		File file = new File("D:\\set.pdf");
		try {
			InputStream in = new FileInputStream(file);
			byte[] b = new byte[1024];
			while (in.read(b) != -1) {
				fsb.append(new String(b, "UTF-8"));// 读取文件内容到StringBuffer中
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		int len = fsb.length();
		String boundary = "7d";
		boundary += new String("" + (Math.random() + Math.random()))
				.substring(2);
		System.out.println("boundary:" + boundary);
		StringBuffer sb = new StringBuffer();

		// 模拟HTTP头
		sb.append("POST /upload.jsp HTTP/1.1\r\n");// 注意\r\n为回车换行
		sb.append("Accept-Language: zh-cn\r\n");
		sb.append("Connection: Keep-Alive\r\n");
		sb.append("Host:localhost\r\n");
		sb.append("Content-Length:" + len + "\r\n");
		sb.append("Content-Type: multipart/form-data; boundary=----------"
				+ boundary + "\r\n");
		sb.append("cookie: JSESSIONID=491E137FB1653E6D1628C119DCB12333\r\n");
		sb.append("\r\n");
		sb.append("------------" + boundary + "\r\n");
		sb.append("Content-Disposition: form-data; name=\"txtUpfile\"; filename=\"set.pdf\""
				+ "\r\n");
		sb.append("Content-Type: application/pdf\r\n");
		sb.append("\r\n");
		sb.append(fsb);// 写入文件
		sb.append("\r\n");
		sb.append("------------" + boundary + "--" + "\r\n");
		sb.append("\r\n");
		System.out.println(len);
		return sb;
	}
}
