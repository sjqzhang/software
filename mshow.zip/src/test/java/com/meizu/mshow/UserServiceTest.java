/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow<br/>
 * <b>文件名：</b>UserServiceTest.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2012-12-14-上午11:04:39<br/>
 * <b>Copyright (c)</b> 2012魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.meizu.mshow.user.dao.UserDAO;

/**
 * <b>类名称：</b>UserServiceTest<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-14 上午11:04:39<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public class UserServiceTest extends TestBase {

	/**
	 * <b>创建人：</b>张军强<br/>
	 * setUpBeforeClass<br/>
	 * <b>方法描述：</b> <br/>
	 * 
	 * @throws java.lang.Exception
	 *             void
	 * @exception
	 * @since 1.0.0
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

	}

	@Test
	/**
	 * 
	 * <b>创建人：</b>张军强<br/>
	 * getUserById<br/>
	 *<b>方法描述：</b> <br/> 
	 * void
	 * @exception 
	 * @since  1.0.0
	 */
	public void getUserById() {

		UserDAO userDao = getBean(UserDAO.class);
		
		Assert.assertNotNull(userDao.loadUserById(1462350L));

	}

}
