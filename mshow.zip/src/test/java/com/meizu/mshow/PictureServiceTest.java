/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow<br/>
 * <b>文件名：</b>PictureServiceTest.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2012-12-14-下午2:47:33<br/>
 * <b>Copyright (c)</b> 2012魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow;

import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.picture.business.PictureService;

/**
 * <b>类名称：</b>PictureServiceTest<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-14 下午2:47:33<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public class PictureServiceTest extends TestBase {

	@SuppressWarnings({ "unchecked", "unused", "rawtypes" })
	@Test
	public void getUserLikePicture() {
		 PictureService pictureService = getBean(PictureService.class);
		 System.err.println(pictureService);
		 QueryModel model = new QueryModel();
		 Map map = model.getCondition(Map.class);
		 map.put("userId", 1462350L);
		 Assert.assertTrue(true);
//		 List<Map> list = pictureService.loadUserLikePicture(model);
//		 System.out.println(list);
//		 Assert.assertTrue(list.size() > 0);
	}

	@Test
	public void getPicCommentByUerId() {

		// PictureService pictureService = getBean(PictureService.class);
		// System.err.println(pictureService);
		// QueryModel model = new QueryModel();
		// Map map = model.getCondition(Map.class);
		// map.put("userId", 1462350L);
		// Assert.assertTrue(true);
		// List<Map> list = pictureService.loadPicCommentByUerId(model);
		// System.out.println(list);
		// Assert.assertTrue(list.size() > 0);

	}
}
