/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow<br/>
 * <b>文件名：</b>TestBase.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2012-12-4-下午2:48:16<br/>
 * <b>Copyright (c)</b> 2012魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow;

import org.junit.BeforeClass;
import org.springframework.context.support.AbstractXmlApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * <b>类名称：</b>TestBase<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-4 下午2:48:16<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public class TestBase {

	private static AbstractXmlApplicationContext context = null;

	/**
	 * 创建一个新的实例 TestBase.
	 */

	public TestBase() {		
		TestBase.context = new ClassPathXmlApplicationContext("classpath*:*.xml");
	}

	@BeforeClass
	public static void beforeClass() {		
		TestBase.context=new ClassPathXmlApplicationContext("classpath*:*.xml");;
	}

	public Object getBean(String name) {
		return context.getBean(name);
	}

	public <T> T getBean(Class<T> classz) {
		return context.getBean(classz);
	}

	public static void main(String[] args) {

		System.setProperty("sun.misc.ProxyGenerator.saveGeneratedFiles", "true");

		TestBase t = new TestBase();

		// Object bb = t.getBean("uploadSettingService");
		// System.out.println(bb);
		//
		// UploadSettingService bb = (UploadSettingService) t
		// .getBean("uploadSettingService");
		//
		// UploadSetting setting = new UploadSetting();
		// setting.setFileClass("img");
		// setting.setFilePath("/mnt/img/");
		// setting.setFileDir("img");
		// setting.setFileMax(1000);
		// setting.setIsActive(1);
		// setting.setFileCount(0);
		// bb.createSetting(setting);

		// // System.out.println(bb.getSettingByFileClass("test"));
		// System.out.println(bb.getSettingByFileClass("test").getFilePath());

		// FileUpload fileUpload = (FileUpload) t.getBean("FileUpload");
		//
		// System.out.println(fileUpload);

		// System.setProperty(key, value)
		// byte[] b =
		// sun.misc.ProxyGenerator.generateProxyClass("com.meizu.mshow.user.business.UserServiceImpl",
		// com.meizu.mshow.user.business.UserServiceImpl.class.getInterfaces());
		//
		// File f = new File("c:/aa.class");
		// try
		// {
		// FileOutputStream out = new FileOutputStream(f);
		// out.write(b);
		// out.flush();
		// }
		// catch (Exception e)
		// {
		// // TODO: handle exception
		// }
		// com.meizu.mshow.user.business.UserServiceImpl.class.getInterfaces()

		// t.testUserSearch();
		// t.testImageSearch();

	}

}
