package com.meizu.mshow.common.servlet;

import java.util.List;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Logger;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.meizu.mshow.common.ApplicationConfig;
import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.resource.MessageSource;
import com.meizu.mshow.common.util.ServiceLocator;
import com.meizu.mshow.domain.pojo.TSysBadwords;
import com.meizu.mshow.system.dao.SystemDAO;
import com.meizu.mshow.timer.TimerFollow;
import com.meizu.mshow.timer.TimerLikeCommentTag;
import com.meizu.mshow.timer.TimerLog;
import com.meizu.mshow.timer.TimerPortal;

public class SystemContextListener implements ServletContextListener {

	private static WebApplicationContext wac = null;

	private static List<TSysBadwords> badwords = null;

	private static final Logger logger = Logger.getLogger(SystemContextListener.class);

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		stopTimer();
		wac = null;
	}

	@Override
	public void contextInitialized(ServletContextEvent sce) {

		loadBeansConfig(sce);
		loadI18NResources();
		loadBadWords();
		startTimer();
	}

	public static void loadBadWords() {
		SystemDAO systemDAO = ServiceLocator.getSystemDAO();
		badwords = systemDAO.loadAllBadwords();
	}

	public void loadI18NResources() {
		MessageSource resouce = new MessageSource();
		resouce.loadResouceToCache();
	}

	public void loadBeansConfig(ServletContextEvent event) {
		wac = WebApplicationContextUtils.getRequiredWebApplicationContext(event.getServletContext());
		ServiceLocator.getInstance().setContext(wac);
		if (wac == null) {
			logger.warn("WebApplicationContext:wac is null! ");
		}
	}

	private void startTimer() {
		ApplicationConfig config = ApplicationConfig.getInstance();
		if (config.getProperty(BusinessConstants.SYS_TIMER_PORTAL).equals("true"))
			TimerPortal.getInstance().start(); // 这个timer不是所有服务器都能起的
		else {
			logger.info("热算法队列未配置启动");
		}
		if (config.getProperty(BusinessConstants.SYS_TIMER_COMMENT).equals("true"))
			TimerLikeCommentTag.getInstance().start();
		else {
			logger.info("赞，评论队列未配置启动");
		}
		if (config.getProperty(BusinessConstants.SYS_TIMER_LOG).equals("true"))
			TimerLog.getInstance().start();
		else {
			logger.info("日志队列未配置启动");
		}
		if (config.getProperty(BusinessConstants.SYS_TIMER_FOLLOW).equals("true"))
			TimerFollow.getInstance().start();
		else {
			logger.info("关注队列未配置启动");
		}
	}

	private void stopTimer() {
		TimerPortal.getInstance().destroyTimer();// 这个timer不是所有服务器都能起的

		TimerLikeCommentTag.getInstance().destroyTimer();
		TimerLog.getInstance().destroyTimer();
	}

	public static List<TSysBadwords> getBadWords() {
		return badwords;
	}

	public static Object getBeanByName(String beanName) {
		try {
			if (wac == null) {
				return null;
			}
			return wac.getBean(beanName);
		} catch (Exception e) {
			logger.error(e.toString(), e);
			return null;
		}
	}
}
