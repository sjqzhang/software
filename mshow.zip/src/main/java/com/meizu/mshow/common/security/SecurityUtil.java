package com.meizu.mshow.common.security;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.SessionConstants;
import com.meizu.mshow.common.cache.RedisUtil;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.exception.ErrorCode;
import com.meizu.mshow.common.util.CacheKeyUtil;
import com.meizu.mshow.common.util.ServiceLocator;
import com.meizu.mshow.domain.model.UserModel;
import com.meizu.mshow.domain.pojo.TSysUser;
import com.meizu.mshow.user.business.UserService;
import com.meizu.mshow.user.web.UserController;

public class SecurityUtil {
	private static final Logger logger = Logger.getLogger(UserController.class);

	public static boolean checkLogin(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		Cookie[] cookies = request.getCookies();
		String jsessionid = null;
		for (int i = 0; cookies != null && i < cookies.length; i++) {
			if (cookies[i].getName().equalsIgnoreCase(SessionConstants.SEESION_COOKIEID)) {
				jsessionid = cookies[i].getValue();
				break;
			}
		}
		// when no jsessionid in cookie ,try request parameter
		if (jsessionid == null)
			jsessionid = request.getParameter(SessionConstants.SEESION_COOKIEID);
		// if the SESSION_CHECKED in session is not null just redirect
		RedisUtil ru = new RedisUtil();
		if (session != null && session.getAttribute(SessionConstants.SESSION_CHECKED) != null) {
			UserModel user = (UserModel) session.getAttribute(SessionConstants.SESSION_USER);
			if ((user.getUser().getStatus() & BusinessConstants.USER_STATUS_ACTIVE) != BusinessConstants.USER_STATUS_ACTIVE)
				throw new ApplicationException(ErrorCode.USER_SECURIY_INACTIVE);

			ru.expire(CacheKeyUtil.getSessionKey(jsessionid), BusinessConstants.CACHE_CATEGORY_SESSION_EXPIRES_SECOND);
			return true;
		}
		// if the user in cache not null just init with it & redirect
		if (jsessionid != null && !jsessionid.equals("")) {
			String userId = ru.getString(CacheKeyUtil.getSessionKey(jsessionid));
			long uid = -1;
			if (userId != null && !userId.equals("")) {
				try {
					uid = Long.parseLong(userId);
				} catch (Exception e) {
					uid = -1;
					if (logger.isDebugEnabled()) {
						logger.error(e.getMessage(), e);
					}
				}
			}
			if (uid < 0)
				return false;

			try {
				UserService userService = ServiceLocator.getUserService();
				UserModel user = userService.loadUserViaUserId(uid);
				if ((user.getUser().getStatus() & BusinessConstants.USER_STATUS_ACTIVE) != BusinessConstants.USER_STATUS_ACTIVE)
					throw new ApplicationException(ErrorCode.USER_SECURIY_INACTIVE);
				initSession(request, user);
				return true;
			} catch (Exception e) {
				if (logger.isDebugEnabled()) {
					logger.error(e.getMessage(), e);
				}
			}
		}
		return false;
	}

	public static void login(HttpServletRequest request, UserModel userModel) {
		UserService userService = ServiceLocator.getUserService();
		TSysUser user = userModel.getUser();
		UserModel originUser = userService.loadUserViaUserId(user.getUserId());
		if (originUser == null) {
			user.setCommentCount(0);
			user.setFansCount(0);
			user.setLikeCount(0);
			user.setHotCount(0);
			user.setImgCount(0);
			user.setStatus(BusinessConstants.USER_STATUS_DEFAULT);
			userService.createUser(userModel);
		} else {
			user = originUser.getUser();
			try {
				userService.updateUserLocation(user);
			} catch (Exception e) {
				logger.warn(e.getMessage(), e);
			}
		}
		userModel.setUser(user);
		initSession(request, userModel);
	}

	private static void initSession(HttpServletRequest request, UserModel user) {
		HttpSession session = request.getSession();
		session.setAttribute(SessionConstants.SESSION_USER_ID, user.getUser().getUserId());
		session.setAttribute(SessionConstants.SESSION_USER_NAME, user.getUser().getUserName());
		session.setAttribute(SessionConstants.SESSION_USER_ALIASNAME, user.getUser().getAliasName());
		session.setAttribute(SessionConstants.SESSION_USER, user);
		session.setAttribute(SessionConstants.SESSION_CHECKED, SessionConstants.SESSION_CHECKED);
		String sessionId = session.getId();
		RedisUtil ru = new RedisUtil();
		String jseesionId = ru.getString(CacheKeyUtil.getSessionUserKey(user.getUser().getUserId()));
		if (jseesionId != null && !"".equals(jseesionId)) {
			ru.expire(CacheKeyUtil.getSessionKey(jseesionId), 0);
		}

		ru.setString(CacheKeyUtil.getSessionKey(sessionId), user.getUser().getUserId() + "", BusinessConstants.CACHE_CATEGORY_SESSION_EXPIRES_SECOND);
		ru.setString(CacheKeyUtil.getSessionUserKey(user.getUser().getUserId()), sessionId, BusinessConstants.CACHE_CATEGORY_SESSION_EXPIRES_SECOND);
	}

	public static void logout(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session != null) {
			try {
				RedisUtil ru = new RedisUtil();
				Long userId = (Long) session.getAttribute(SessionConstants.SESSION_USER_ID);
				String sessionId = session.getId();
				ru.expire(CacheKeyUtil.getSessionKey(sessionId), 0);
				ru.expire(CacheKeyUtil.getSessionUserKey(userId), 0);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
			try {
				session.removeAttribute(SessionConstants.SESSION_USER_ID);
				session.removeAttribute(SessionConstants.SESSION_USER_NAME);
				session.removeAttribute(SessionConstants.SESSION_USER_ALIASNAME);
				session.removeAttribute(SessionConstants.SESSION_USER);
				session.removeAttribute(SessionConstants.SESSION_CHECKED);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
			session.invalidate();
		}
	}

	public static void trustAllCert() throws NoSuchAlgorithmException, KeyManagementException {
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {

			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs, String authType) {
			}

			public void checkServerTrusted(X509Certificate[] certs, String authType) {
			}
		} };
		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		HostnameVerifier allHostsValid = new HostnameVerifier() {

			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		};
		HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	}

	public static String toLogin() {
		return "";
	}

	public static String validate() {
		return "";
	}

}
