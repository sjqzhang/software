package com.meizu.mshow.common.cache;

import java.util.List;

import redis.clients.jedis.JedisPool;

public class CacheRouter {
	private List<JedisPool> writePool;
	private List<JedisPool> readPool;

	public CacheRouter(List<JedisPool> writePool, List<JedisPool> readPool) {
		super();
		this.writePool = writePool;
		this.readPool = readPool;
	}

	public JedisPool getWriteJedisPool() {
		if (writePool != null && writePool.size() > 0) {
			if (writePool.size() == 1)
				return writePool.get(0);
			else {
				int i = getRandomInt(0, writePool.size() * 3) % writePool.size();
				return writePool.get(i);
			}
		}
		return null;
	}

	public JedisPool getReadJedisPool() {
		if (readPool != null && readPool.size() > 0) {
			if (readPool.size() == 1)
				return readPool.get(0);
			else {
				int i = getRandomInt(0, readPool.size() * 3) % readPool.size();
				return readPool.get(i);
			}
		}
		return null;
	}

	public static int getRandomInt(int min, int max) {
		int result = min + new Double(Math.random() * (max - min)).intValue();
		return result;
	}
}
