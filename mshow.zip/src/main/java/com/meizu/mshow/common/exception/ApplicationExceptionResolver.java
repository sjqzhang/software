package com.meizu.mshow.common.exception;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.resource.MessageSource;
import com.meizu.mshow.common.util.ServiceLocator;

public class ApplicationExceptionResolver implements HandlerExceptionResolver {

	private Logger logger = Logger.getLogger(ApplicationExceptionResolver.class);

	@Override
	public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handle, Exception e) {
		Map<String, Object> model = new HashMap<String, Object>();
		MessageSource resource = ServiceLocator.getMessageSource();
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Pragma", "no-cache");
		response.setDateHeader("Expires", 0);
		model.put("ex", e);
		try {
			if (isAjaxRequest(request))
				handlerAjaxRequestException(request, response, e, resource);
			else
				return handlerNormalRequestException(request, response, e, resource);
		} catch (Throwable t) {
			try {
				if (isAjaxRequest(request)) {
					String errorMessage = resource.getMessage(ErrorKey.getKey(ErrorCode.UNKNOW_ERROR), null, request.getLocale());
					int errorcode = ErrorCode.UNKNOW_ERROR;
					PrintWriter writer = response.getWriter();
					response.setContentType("text/json; charset=utf-8");
					response.setCharacterEncoding("UTF-8");
					writer.write("{'returnValue':'','returnCode':" + errorcode + ",'returnMessage':'" + errorMessage + "','returnUrl':''}");
					writer.flush();
				} else {
					logger.error(t.getMessage(), t);
					return new ModelAndView("/WEB-INF/jsp/erro500.jsp");
				}
			} catch (Throwable t2) {
				logger.error(t2.getMessage(), t2);
			}
		} finally {
			try {
				logException(request, e, handle, resource);
			} catch (Throwable t) {
				logger.error(t.getMessage(), t.getCause());
			}
		}
		return new ModelAndView();
	}

	private final void handlerAjaxRequestException(final HttpServletRequest request, final HttpServletResponse response, Exception e, MessageSource resource) throws Throwable {
		String errorMessage = resource.getMessage(ErrorKey.getKey(ErrorCode.UNKNOW_ERROR), null, request.getLocale());
		int errorcode = ErrorCode.UNKNOW_ERROR;
		String redirectURL = "";
		if (e instanceof ApplicationException) {
			ApplicationException ae = (ApplicationException) e;
			errorcode = ae.getErrorCode();
			errorMessage = resource.getMessage(ErrorKey.getKey(errorcode, ErrorCode.UNKNOW_ERROR), ae.getMessageParams(), request.getLocale());
			redirectURL = ae.getSendRedirectURL();
		}
		response.setContentType("text/json; charset=utf-8");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out;
		out = (PrintWriter) response.getWriter();
		out.write("{'returnValue':'','returnCode':" + errorcode + ",'returnMessage':'" + errorMessage + "','returnUrl':''}");
		out.flush();
	}

	private final ModelAndView handlerNormalRequestException(final HttpServletRequest request, final HttpServletResponse response, Exception e, MessageSource resource) throws Throwable {
		Map<String, Object> model = new HashMap<String, Object>();
		String errorMessage = resource.getMessage(ErrorKey.getKey(ErrorCode.UNKNOW_ERROR), null, request.getLocale());
		int errorcode = ErrorCode.UNKNOW_ERROR;
		String redirectURL = "";
		String view = "error500";
		if (e instanceof ApplicationException) {
			ApplicationException ae = (ApplicationException) e;
			errorcode = ae.getErrorCode();
			errorMessage = resource.getMessage(ErrorKey.getKey(ae.getErrorCode(), ErrorCode.UNKNOW_ERROR), ae.getMessageParams(), request.getLocale());
			redirectURL = ae.getSendRedirectURL();
			view = "errorapplication";
		}
		model.put("returnCode", errorcode);
		model.put("returnMessage", errorMessage);
		model.put("returnUrl", redirectURL);
		model.put("returnValue", "");
		ModelAndView m = new ModelAndView("/WEB-INF/jsp/" + view + ".jsp", model);
		m.addObject("Cache-Control", "no-cache");
		m.addObject("Pragma", "no-cache");
		m.addObject("Expires", 0);
		return m;
	}

	private final boolean isAjaxRequest(final HttpServletRequest request) {
		boolean flag = false;
		if (request.getHeader("x-requested-with") != null && request.getHeader("x-requested-with").equalsIgnoreCase("XMLHttpRequest")) {
			flag = true;
		} else if (request.getRequestURI().indexOf(BusinessConstants.CLIENT_REQUEST) >= 0) {
			flag = true;
		}
		return flag;
	}

	private final void logException(HttpServletRequest request, Exception e, Object handle, MessageSource resource) {

		int errorcode = ErrorCode.UNKNOW_ERROR;
		boolean logError = true;
		String errorMessage = resource.getMessage(ErrorKey.getKey(ErrorCode.UNKNOW_ERROR), null, request.getLocale());
		if (e instanceof ApplicationException) {
			ApplicationException ae = (ApplicationException) e;
			logError = ae.isLogged();
			errorcode = ae.getErrorCode();
			errorMessage = resource.getMessage(ErrorKey.getKey(ae.getErrorCode(), ErrorCode.UNKNOW_ERROR), ae.getMessageParams(), request.getLocale());
		}
		if (logError) {
			StringBuffer msg = new StringBuffer("@E").append("['errorCode' : ").append(errorcode).append("  'errorMessage' : '").append(errorMessage).append("]");
			logger.error(msg, e);
		}
	}
}
