/**
 * <b>项目名：</b>spring3.1<br/>
 * <b>包名：</b>com.spring.study<br/>
 * <b>文件名：</b>ICache.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2013-1-7-下午1:34:03<br/>
 * <b>Copyright (c)</b> 2013魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.common.cache;

/**
 * <b>类名称：</b>ICache<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-7 下午1:34:03<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public interface ICache {

	<T> T get(CacheCategory category, String key, Class<T> classType);

	void put(CacheCategory category, String key, Object obj, int ttl);

	void remove(CacheCategory category, String key);

	void flush(CacheCategory categroy);

	void flushAll();

	void addEventLister(ICacheEvent event);

	boolean isDebug();

}
