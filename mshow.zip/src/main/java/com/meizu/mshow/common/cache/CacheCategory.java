/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.common.cache<br/>
 * <b>文件名：</b>CacheCategory.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2013-1-9-下午4:48:38<br/>
 * <b>Copyright (c)</b> 2013魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.common.cache;

/**
 * <b>类名称：</b>CacheCategory<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-9 下午4:48:38<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public enum CacheCategory {

	Defalut("defalut"), System("sys"), Dao("dao"), Web("web"), Service("service");

	/**
	 * 创建一个新的实例 CacheCategory.
	 */

	private String category;

	private CacheCategory(String val) {
		this.category = val;
	}

	public String getVal() {
		return this.category;
	}

}
