package com.meizu.mshow.common.ip;

public class GPoint
{
	
	private double lat;
	private double lng;
	private String localName;
	private String provice;
	private String city;
	private String country;
	public GPoint(double latitude,double longitude)
	{
	  this.setLat(latitude);
	  this.setLng(longitude);
	}
	public GPoint(double latitude,double longitude,String localName)
	{
	  this.setLat(latitude);
	  this.setLng(longitude);
	  this.setLocalName(localName);
	}
	public GPoint(double latitude,double longitude,String country,String provice,String city)
	{
		this.setCountry(country);
	  this.setLat(latitude);
	  this.setLng(longitude);
	  this.setCity(city);
	  this.setProvice(provice);
	  this.setLocalName(country+provice+city);
	}
	public void setLat(double lat) {
		this.lat = lat;
	}
	public double getLat() {
		return lat;
	}
	public void setLng(double lng) {
		this.lng = lng;
	}
	public double getLng() {
		return lng;
	}
	public void setLocalName(String localName) {
		this.localName = localName;
	}
	public String getLocalName() {
		return localName;
	}
	public String getProvice() {
		return provice;
	}
	public void setProvice(String provice) {
		this.provice = provice;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
}
