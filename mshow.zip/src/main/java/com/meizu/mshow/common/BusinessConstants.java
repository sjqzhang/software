package com.meizu.mshow.common;

public class BusinessConstants {

	public static final String SINA_PROTECTED_RESOURCE_URL = "https://api.weibo.com/2/account/get_uid.json";

	public static final String SINA_PROTECTED_USER_URL = "https://api.weibo.com/2/users/show.json";

	public static final String TENCENT_PROTECTED_RESOURCE_URL = "https://graph.qq.com/oauth2.0/me";

	public static final String TENCENT_PROTECTED_USER_URL = "https://graph.qq.com/user/get_info";

	public static final int PAGE_MAC_LIMIT = 100;

	public static final int CACHE_CATEGORY_MINI_EXPIRES_SECOND = 1;

	public static final int CACHE_CATEGORY_SHORT_EXPIRES_SECOND = 5;

	public static final int CACHE_CATEGORY_DEFAULT_EXPIRES_SECOND = 5 * 60;

	public static final int CACHE_CATEGORY_SESSION_EXPIRES_SECOND = 8 * 60 * 60;

	public static final int CACHE_CATEGORY_NEVER_EXPIRE = -1;

	public static final String CACHE_CATEGORY_WRITE = "cache_category_write";

	public static final String CACHE_CATEGORY_READ = "cache_category_read";

	public static final String LOCAL_CACHE_BADWORDS_LIST = "LOCAL_CACHE_BADWORDS";

	public static final int CLIENT_CATEGORY_WEB = 1;

	public static final int CLIENT_CATEGORY_PHONE = 2;

	public static final int PICTURE_STATUS_FORBIDDEN = 0;

	public static final int PICTURE_STATUS_NEW = 1;

	public static final int PICTURE_STATUS_APPROVAL = 2;

	public static final int PICTURE_STATUS_AUDITING = 3;

	public static final int PICTURE_STATUS_DESTORY = 9;// 用户删除

	public static final Integer DEFAULT = -1;

	public static final Integer TAG_STATUS_DEFAULT = -1;// need add

	public static final Integer TAG_STATUS_ACTIVE = 1;// 可用

	public static final Integer TAG_STATUS_RECOMMAND = 2;// 运营推荐

	public static final Integer TAG_STATUS_DELETED = 9;// 删除

	public static final String SYS_UPLOAD_DIR = "sys.upload.dir";

	public static final String SYS_BASE_URL = "sys.base.url";

	public static final String SYS_TIMER_PORTAL = "sys.timer.portal";

	public static final String SYS_TIMER_COMPRESS = "sys.timer.compress";

	public static final String SYS_TIMER_FOLLOW = "sys.timer.follow";

	public static final String SYS_TIMER_COMMENT = "sys.timer.comment";

	public static final String SYS_TIMER_LOG = "sys.timer.log";

	public static final Integer BUF_SIZE = 12 * 1024;

	public static final String FILE_SEPARATOR = "/";

	public static final String ICON_SEPARATOR = "icon";

	public static final int LIKE_STATUS_NORMAL = 1;

	public static final int LIKE_STATUS_CANCEL = 9;

	public static final int COMMENT_STATUS_FORBIDEN = 0;// 运营删除

	public static final int COMMENT_STATUS_NEW = 1;// 新发

	public static final int COMMENT_STATUS_AUDITED = 2;// 以审

	public static final int COMMENT_STATUS_DELETED = 9;// 用户删除

	/**
	 * 以下为图片大小定义
	 */
	public static final int IMAGE_ZIP_ICON_WIDTH = 100;

	public static final int IMAGE_ZIP_ICON_HEIGHT = 100;

	public static final int IMAGE_ZIP_SMALL_WIDTH = 260;

	public static final int IMAGE_ZIP_SMALL_HEIGHT = 260;

	public static final int IMAGE_ZIP_MIDDLE_HEIGHT = 780;

	public static final int IMAGE_ZIP_MIDDLE_WIDTH = 780;

	public static final int COMPLAIN_STATUS_NEW = 1;// 新投诉

	public static final int COMPLAIN_STATUS_APPROVED = 2;// 投诉通过

	public static final int COMPLAIN_STATUS_REJECTED = 3;// 投诉不合理

	public static final int PAGE_PLAZA_LIMIT = 3;// 每页显示三条记录

	public static final int PAGE_DEFAULT_CACHE_LIMIT = 300;// 缓存加载多少页记录

	public static final int VEST_TRUE = 1;// 马甲账号

	public static final int VEST_FALSE = 0;// 非马甲账号

	// 最大记录
	public static final int MARK_MAX_COUNT = 50;

	// 最大记录
	public static final int MESSAGE_MAX_COUNT = 120;
	// 赞
	public static final int MARK_CATEGORY_LIKE = 1;
	// 评论
	public static final int MARK_CATEGORY_COMMENT = 2;
	// 浏览
	public static final int MARK_CATEGORY_VIEW = 3;

	public static final double SCORE_COMMENT_WEIGHT = 0.75;// 热评论权重

	public static final double SCORE_LIKE_WEIGHT = 0.5;// 热赞权重

	public static final double SCORE_VIEW_WEIGHT = 0.25;// 热浏览权重

	public static final int PRT_CATEGORY_HOT = 1;

	public static final int PRT_CATEGORY_TAG = 2;

	public static final int PRT_LEVEL_RECOMMAND = 1;

	public static final int PRT_LEVEL_TIMMER = 2;

	public static final int PRT_STATUS_ACTIVE = 1;

	public static final int PRT_STATUS_INACTIVE = 0;

	public static final int USER_STATUS_ACTIVE = 8; // 可用

	public static final int USER_STATUS_COMMENT = 12; // 可发言

	public static final int USER_STATUS_UPLOAD = 10; // 可上传

	public static final int USER_STATUS_DEFAULT = 15; // 可上传

	public static final String CLIENT_REQUEST = "/c/android/";

	public static final int COMMNENT_MAX_LENGTH = 140;// 评论最大内容

	public static final int UPLOAD_DESC_MAX_LENGTH = 140;// 描述最大内空

	public static final int TAG_MAX_LENGTH = 20;// 标签最大长度

	public static final int TAG_MAX_SIZE = 6;// 标签最大个数

	public static final int MESSAGE_CATEGORY_LIKE = 1;

	public static final int MESSAGE_CATEGORY_COMMENT = 2;

	public static final int MESSAGE_CATEGORY_VIEW = 3;

	public static final int MESSAGE_CATEGORY_REPLY = 4;

	public static final int MAX_COMPRESS_SIZE = 20;
}
