package com.meizu.mshow.common.cache;

/**
 * <b>类名称：</b>DBCacheOperation<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-6 上午11:05:04<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public enum DBCacheOperation {
	SELECT(0), INSERT(1), UPDATE(2), DELETE(3), FLUSH(4);
	private int op = 0;

	private DBCacheOperation(int i) {
		this.op = i;
	}

	public int getVal() {
		return this.op;
	}

}
