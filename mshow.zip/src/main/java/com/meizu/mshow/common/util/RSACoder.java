package com.meizu.mshow.common.util;

import java.io.ByteArrayOutputStream;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;



public abstract class RSACoder {
	public static final String KEY_ALGORITHM = "RSA";
	public static final String SIGNATURE_ALGORITHM = "MD5withRSA";

	private static final String PUBLIC_KEY = "RSAPublicKey";
	private static final String PRIVATE_KEY = "RSAPrivateKey";
	
	private static final int ENCRYPT = 1;
	private static final int DECRYPT = 0;

	private static final int MD5_LENGTH = 16;
	private static SecretKey aesKey;

	/**
	 * 解密数据。
	 * <p>解密的同时做MD5的验证。
	 * <p>
	 * 时间： 2009-8-31上午09:56:02 </br>
	 * @since v0.1 
	 * @param cipher
	 * @param key
	 * @return 
	 * @throws Exception 
	 */
	public static String decryptWithRSA_AES(String cipher, Key key) throws Exception{
		try {
			String[] split = cipher.split("\\*");
			if(split.length!=2){
				throw new Exception("密文错误");
			}
		
			byte[] aeskeyAndMD5 = BASE64coderUrlSafe.decode(split[0]);
			byte[] decryptAesMd5 = decryptData(aeskeyAndMD5, key, "RSA/ECB/PKCS1Padding");
			
			byte[] encryptedData = BASE64coderUrlSafe.decode(split[1]);
			
			byte[] md5 = new byte[MD5_LENGTH];
			System.arraycopy(decryptAesMd5, 0, md5, 0, md5.length);
			byte[] aesKey = new byte[decryptAesMd5.length - MD5_LENGTH];
			System.arraycopy(decryptAesMd5, md5.length, aesKey, 0, aesKey.length);
			
			javax.crypto.spec.SecretKeySpec secretKeySpecDecrypted = new javax.crypto.spec.SecretKeySpec(
					aesKey, "AES");
			
			byte[] decryptData = decryptData(encryptedData, secretKeySpecDecrypted, "AES");
			MessageDigest md;
			md = MessageDigest.getInstance("MD5");
			md.update(decryptData);
			byte mdToVerify[] = md.digest();
			
			//验证MD5
			if(md5.length!=mdToVerify.length){
				throw new Exception("消息摘要不正确");
			}
			for(int i=0;i<md5.length; i++){
				if(md5[i] != mdToVerify[i]){
					throw new Exception("消息摘要不正确");
				}
			}
			return new String(decryptData,"UTF-8");
		}catch (Exception e) {
			throw new Exception(e);
		}
	}
	/**
	 * 使用AES加密明文数据。使用RSA加密AES KEY和数据摘要MD5
	 * <p>返回的字符串为BAS64(URL Safe)编码后的字符串。没有使用签名。
	 * <p>
	 * 时间： 2009-8-31上午09:05:52 </br>
	 * @since v0.1 
	 * @return 
	 * @throws Exception 
	 */
	public static String encryptWithRSA_AES(String plainText, Key key) throws Exception{
		try {
			// 1. 首先用AES对称加密算法加密
			SecretKey aesKey = getAESSecretKey();
			byte[] plain = plainText.getBytes("UTF-8");
			//AES加密
			byte[] cipher = encryptData(plain, aesKey,
					"AES");
			//MD5摘要
			MessageDigest md;
			md = MessageDigest.getInstance("MD5");
			md.update(plain);
			byte md5[] = md.digest();
			
			//用RSA加密 AES KEY
			byte[] aesKeyEncoded = aesKey.getEncoded();
			byte[] toencode = new byte[aesKeyEncoded.length+md5.length];
			System.arraycopy(md5, 0, toencode, 0, md5.length);
			System.arraycopy(aesKeyEncoded, 0, toencode, md5.length, aesKeyEncoded.length);

			byte[] byteEncryptWithPublicKey = encryptData(toencode, key,
			"RSA/ECB/PKCS1Padding");
			
			//RSA加密的MD5,AES KEY + AES加密的数据
			return BASE64coderUrlSafe.encode2String(byteEncryptWithPublicKey)+"*"+BASE64coderUrlSafe.encode2String(cipher);
		} catch (Exception e) {
			throw new Exception(e);
		}
	}
	
	/**
	 * 加密数据并签名。
	 * <p>加密后数据为：签名+AES Key + MD5 + 加密后的数据
	 * <p>
	 * 时间： 2009-8-31上午09:02:15 </br>
	 * @since v0.1 
	 * @param plainTxt
	 * @param publicKey
	 * @param privateKey
	 * @return
	 * @throws Exception 
	 */
	public static String encryptAndSign(String plainTxt, PublicKey publicKey,
			PrivateKey privateKey) throws Exception {
		byte[] plain = plainTxt.getBytes();
		SecretKey senderSecretKey = getAESSecretKey();
		// 1. 首先用AES对称加密算法加密
		byte[] byteCipherText = encryptData(plain, senderSecretKey,
				"AES");

		// 2. 使用RSA用公钥加密 AES密钥
		byte[] byteEncryptWithPublicKey = encryptData(senderSecretKey.getEncoded(), publicKey,
						"RSA/ECB/PKCS1Padding");
		String strSenbyteEncryptWithPublicKey = Base64Coder
				.encode2String(byteEncryptWithPublicKey);

		// 3. 计算数据的摘要
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(plain);
		byte byteMDofDataToTransmit[] = md.digest();
		String strMd = Base64Coder.encode2String(byteMDofDataToTransmit);

		// 4. 对加密后的AES密钥和消息摘要签名
		Signature mySign = Signature.getInstance("MD5withRSA");
		mySign.initSign(privateKey);
		String rsaData = strSenbyteEncryptWithPublicKey + "*" + strMd;
		mySign.update(rsaData.getBytes());
		byte[] byteSignedData = mySign.sign();

		// 消息签名+RSA加密的数据 + 密文
		return Base64Coder.encode2String(byteSignedData) + "*" + rsaData + "*"
				+ Base64Coder.encode2String(byteCipherText);
	}

	/**
	 * 解密并验证签名。
	 * <p>解密过程： 验证签名 --> 解密AES KEY --> 解密数据 --> 验证MD5
	 * <p>
	 * 时间： 2009-8-31上午09:03:21 </br>
	 * @since v0.1 
	 * @param cipher
	 * @param publicKey
	 * @param privateKey
	 * @return
	 * @throws Exception 
	 */
	public static String decryptAndVerify(String cipher, PublicKey publicKey,
			PrivateKey privateKey) throws Exception {
		String[] split = cipher.split("\\*");
		byte[] signedData = Base64Coder.decode(split[0]);
		String aesKey = split[1];
		String md5 = split[2];
		byte[] encodedData = Base64Coder.decode(split[3]);

		// 1. 验证签名。
		Signature myVerifySign = Signature.getInstance("MD5withRSA");
		myVerifySign.initVerify(publicKey);
		myVerifySign.update((aesKey + "*" + md5).getBytes());

		boolean verifySign = myVerifySign.verify(signedData);// 验证签名

		if (!verifySign) {
			throw new Exception("签名验证不正确");
		}

		// 2. 用RSA公钥解密 AES密钥
		byte[] decryptedAesKey = decryptData(Base64Coder
				.decode(aesKey), privateKey, "RSA/ECB/PKCS1Padding");

		javax.crypto.spec.SecretKeySpec secretKeySpecDecrypted = new javax.crypto.spec.SecretKeySpec(
				decryptedAesKey, "AES");

		byte[] decryptData = decryptData(encodedData,
				secretKeySpecDecrypted, "AES");

		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(decryptData);
		byte byteMDofDataToTransmit[] = md.digest();

		String strMD = Base64Coder.encode2String(byteMDofDataToTransmit);
		if (!strMD.equals(md5)) {
			throw new Exception("数据验证不正确");
		}
		return new String(decryptData);
	}

	
	/**
	 * 用私钥对信息生成数字签名
	 * 
	 * @param data
	 *            加密数据
	 * @param privateKey
	 *            私钥
	 * 
	 * @return
	 * @throws Exception
	 */
	public static String sign(byte[] data, String privateKey) throws Exception {
		// 解密由base64编码的私钥
		byte[] keyBytes = Base64Coder.decode(privateKey);

		// 构造PKCS8EncodedKeySpec对象
		PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);

		// KEY_ALGORITHM 指定的加密算法
		KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);

		// 取私钥匙对象
		PrivateKey priKey = keyFactory.generatePrivate(pkcs8KeySpec);
		return sign(data, priKey);
	}

	public static String sign(byte[] data, PrivateKey privateKey)
			throws Exception {
		// 用私钥对信息生成数字签名
		Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);
		signature.initSign(privateKey);
		signature.update(data);

		return Base64Coder.encode2String(signature.sign());
	}

	/**
	 * 校验数字签名
	 * 
	 * @param data
	 *            加密数据
	 * @param publicKey
	 *            公钥
	 * @param sign
	 *            数字签名
	 * 
	 * @return 校验成功返回true 失败返回false
	 * @throws Exception
	 * 
	 */
	public static boolean verify(byte[] data, String base64KeyPublicKey,
			String sign) throws Exception {

		// 解密由base64编码的公钥
		byte[] keyBytes = Base64Coder.decode(base64KeyPublicKey);

		// 构造X509EncodedKeySpec对象
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);

		// KEY_ALGORITHM 指定的加密算法
		KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);

		// 取公钥匙对象
		PublicKey pubKey = keyFactory.generatePublic(keySpec);

		// 验证签名是否正常
		return verify(data, pubKey, sign);
	}

	public static boolean verify(byte[] data, PublicKey publicKey, String sign)
			throws Exception {
		Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);
		signature.initVerify(publicKey);
		signature.update(data);
		// 验证签名是否正常
		return signature.verify(Base64Coder.decode(sign));
	}

	/**
	 * 解密<br>
	 * 用私钥解密
	 * 
	 * @param data
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static byte[] decryptByPrivateKey(byte[] data, String base64Key)
			throws Exception {
		// 对密钥解密
		byte[] keyBytes = Base64Coder.decode(base64Key);

		// 取得私钥
		PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
		PrivateKey privateKey = keyFactory.generatePrivate(pkcs8KeySpec);

		// 对数据解密
		return decryptByPrivateKey(data, privateKey);
	}

	public static byte[] decryptByPrivateKey(byte[] data, PrivateKey privateKey)
			throws Exception {
//		// 取得私钥
//		KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
//
//		// 对数据解密
//		Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
//		cipher.init(Cipher.DECRYPT_MODE, privateKey);
//
//		return cipher.doFinal(data);
		return encryptDecrypt(DECRYPT, data, privateKey);
	}

	/**
	 * 解密<br>
	 * 用私钥解密
	 * 
	 * @param data
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static byte[] decryptByPublicKey(byte[] data, String base64Publickey)
			throws Exception {
		// 对密钥解密
		byte[] keyBytes = Base64Coder.decode(base64Publickey);

		// 取得公钥
		X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
		PublicKey publicKey = keyFactory.generatePublic(x509KeySpec);

		return decryptByPublicKey(data, publicKey);
	}

	public static byte[] decryptByPublicKey(byte[] data, PublicKey publicKey)
			throws Exception {
//		KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
//		Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
//		cipher.init(Cipher.DECRYPT_MODE, publicKey);
//		return cipher.doFinal(data);
		return encryptDecrypt(DECRYPT, data, publicKey);
	}

	/**
	 * 加密<br>
	 * 用公钥加密
	 * 
	 * @param data
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static byte[] encryptByPublicKey(byte[] data, String key)
			throws Exception {
		// 对公钥解密
		byte[] keyBytes = Base64Coder.decode(key);

		// 取得公钥
		X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
		PublicKey publicKey = keyFactory.generatePublic(x509KeySpec);

		return encryptByPublicKey(data, publicKey);
	}

	public static byte[] encryptByPublicKey(byte[] data, PublicKey publicKey)
			throws Exception {
		// 取得公钥
		//KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
		// 对数据加密
//		Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
//		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
//
//		return cipher.doFinal(data);
		return encryptDecrypt(DECRYPT, data, publicKey);
	}

	private static byte[] encryptDecrypt(int type, byte[] data, Key secretKey)
			throws Exception {
		byte cryptedCipherText[] = null;
		try {
			Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
			
			int inputBlockSize = 128;
			
			if (type == ENCRYPT) {
				cipher.init(Cipher.ENCRYPT_MODE, secretKey);
				inputBlockSize = 117;
			} else if (type == DECRYPT) {
				cipher.init(Cipher.DECRYPT_MODE, secretKey);
				inputBlockSize = 128;
			}else{
				throw new Exception("Error type :"+type);
			}

			ByteArrayOutputStream cryptedTextBuffer = new ByteArrayOutputStream();
			
			int i = 0;
			boolean more = true;
			while (more) {
				int startPos = inputBlockSize*i;
				if((startPos+inputBlockSize)>data.length){
					more = false;
					int inputLen = data.length - startPos;
					cryptedTextBuffer.write(cipher.doFinal(data, startPos, inputLen));
				}else{
					cryptedTextBuffer.write(cipher.doFinal(data, startPos, inputBlockSize));
				}
				i++;
			}
			cryptedCipherText = cryptedTextBuffer.toByteArray();
		} catch (Exception e) {
			throw e;
		}
		return cryptedCipherText;

	}

	/**
	 * 加密<br>
	 * 用私钥加密
	 * 
	 * @param data
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static byte[] encryptByPrivateKey(byte[] data,
			String base64Privatekey) throws Exception {
		// 对密钥解密
		byte[] keyBytes = Base64Coder.decode(base64Privatekey);

		// 取得私钥
		PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
		PrivateKey privateKey = keyFactory.generatePrivate(pkcs8KeySpec);

		return encryptByPrivateKey(data, privateKey);
	}

	public static byte[] encryptByPrivateKey(byte[] data, PrivateKey privateKey)
			throws Exception {
//		KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
//		// 对数据加密
//		Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
//		cipher.init(Cipher.ENCRYPT_MODE, privateKey);
//
//		return cipher.doFinal(data);
		return encryptDecrypt(ENCRYPT, data, privateKey);
	}

	/**
	 * 取得私钥
	 * 
	 * @param keyMap
	 * @return
	 * @throws Exception
	 */
	public static String getPrivateKey(Map<String, Object> keyMap)
			throws Exception {
		Key key = (Key) keyMap.get(PRIVATE_KEY);

		return Base64Coder.encode2String(key.getEncoded());
	}

	/**
	 * 取得公钥
	 * 
	 * @param keyMap
	 * @return
	 * @throws Exception
	 */
	public static String getPublicKey(Map<String, Object> keyMap)
			throws Exception {
		Key key = (Key) keyMap.get(PUBLIC_KEY);

		return Base64Coder.encode2String(key.getEncoded());
	}

	/**
	 * 初始化密钥
	 * 
	 * @return
	 * @throws Exception
	 */
	public static Map<String, Object> initKey() throws Exception {
		KeyPairGenerator keyPairGen = KeyPairGenerator
				.getInstance(KEY_ALGORITHM);
		keyPairGen.initialize(1024);

		KeyPair keyPair = keyPairGen.generateKeyPair();

		// 公钥
		RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();

		// 私钥
		RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();

		Map<String, Object> keyMap = new HashMap<String, Object>(2);

		keyMap.put(PUBLIC_KEY, publicKey);
		keyMap.put(PRIVATE_KEY, privateKey);
		return keyMap;
	}

		private static SecretKey getAESSecretKey() throws Exception {
			/**
			 * Step 1. Generate an AES key using KeyGenerator Initialize the keysize
			 * to 128
			 */
			if(aesKey !=null)
				return aesKey;
			try {
				KeyGenerator keyGen = KeyGenerator.getInstance("AES");
				keyGen.init(128);
				aesKey = keyGen.generateKey();
				return aesKey;
			} catch (Exception exp) {
				throw new Exception(exp);
			}
		}

		/**
		 * Step2. Create a Cipher by specifying the following parameters a.
		 * Algorithm name - here it is AES
		 * @throws Exception 
		 */

		public static byte[] encryptData(byte[] byteDataToEncrypt, Key secretKey,
				String Algorithm) throws Exception {
			byte[] byteCipherText = new byte[200];

			try {
				Cipher aesCipher = Cipher.getInstance(Algorithm);

				/**
				 * Step 3. Initialize the Cipher for Encryption
				 */
				if (Algorithm.equals("AES")) {
					aesCipher.init(Cipher.ENCRYPT_MODE, secretKey, aesCipher
							.getParameters());
				} else if (Algorithm.equals("RSA/ECB/PKCS1Padding")) {
					aesCipher.init(Cipher.ENCRYPT_MODE, secretKey);
				} else {
					throw new Exception("不支持的加密算法 " + Algorithm);
				}

				/**
				 * Step 4. Encrypt the Data 1. Declare / Initialize the Data. Here
				 * the data is of type String 2. Convert the Input Text to Bytes 3.
				 * Encrypt the bytes using doFinal method
				 */
				byteCipherText = aesCipher.doFinal(byteDataToEncrypt);
			}

			catch (Exception e) {
				throw new Exception(e);
			}

			return byteCipherText;
		}

		/**
		 * Step 5. Decrypt the Data 1. Initialize the Cipher for Decryption 2.
		 * Decrypt the cipher bytes using doFinal method
		 * @throws Exception 
		 */

		public static byte[] decryptData(byte[] byteCipherText, Key secretKey,
				String Algorithm) throws Exception {
			byte[] byteDecryptedText = new byte[200];

			try {
				Cipher aesCipher = Cipher.getInstance(Algorithm);
				if (Algorithm.equals("AES")) {
					aesCipher.init(Cipher.DECRYPT_MODE, secretKey, aesCipher
							.getParameters());
				} else if (Algorithm.equals("RSA/ECB/PKCS1Padding")) {
					aesCipher.init(Cipher.DECRYPT_MODE, secretKey);
				}

				byteDecryptedText = aesCipher.doFinal(byteCipherText);
			}

			catch (Exception e) {
				throw new Exception(e);
			}

			return byteDecryptedText;
		}
}

