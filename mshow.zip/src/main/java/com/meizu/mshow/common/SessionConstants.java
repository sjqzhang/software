package com.meizu.mshow.common;

public interface SessionConstants {

	public static final String SESSION_CHECKED = "SESSION_CHECKED";

	public static final String SESSION_USER_ID = "SESSION_USER_ID";

	public static final String SESSION_USER_NAME = "SESSION_USER_NAME";

	public static final String SESSION_USER_ALIASNAME = "SESSION_USER_ALIASNAME";

	public static final String SESSION_USER = "SESSION_USER";

	public static final String SEESION_COOKIEID = "JSESSIONID";

	public static final String AUTHOR_CATEGORY = "_AUTHOR_CATEGORY_";

	public static final String AUTHOR_CATEGORY_SINA = "_SINA_";

	public static final String AUTHOR_CATEGORY_TENCENT = "_TENCENT_";

	public static final String AUTHOR_CATEGORY_FLYME = "_FLYME_";

	public static final String AUTHOR_COOKIE_USERNAME = "_aliasName_";

	public static final String AUTHOR_COOKIE_USERID = "_userId_";
}
