/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.common.upload<br/>
 * <b>文件名：</b>FileUpload.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2012-12-4-上午9:57:42<br/>
 * <b>Copyright (c)</b> 2012魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.common.upload;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;

import com.meizu.mshow.domain.pojo.UploadFileInfo;
import com.meizu.mshow.domain.pojo.UploadSetting;
import com.meizu.mshow.system.business.UploadSettingService;

/**
 * <b>类名称：</b>FileUpload<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 * 实现文件上传
 * </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-4 上午9:57:42<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public class FileUpload implements IFileUpload {

	private String filePath;

	private String fileClass;

	private int fileMax;

	@Autowired
	private UploadSettingService uploadSettingService;

	@Override
	public List<UploadFileInfo> upload(HttpServletRequest request,
			HttpServletResponse response) throws FileUploadException {
		ArrayList<UploadFileInfo> list = new ArrayList<UploadFileInfo>();
		DiskFileItemFactory factory = new DiskFileItemFactory();

		// Set factory constraints
		// factory.setSizeThreshold(yourMaxMemorySize);
		// factory.setRepository(tempPath);

		// Create a new file upload handler
		ServletFileUpload upload = new ServletFileUpload(factory);

		// Set overall request size constraint
		// upload.setSizeMax(yourMaxRequestSize);

		// Parse the request
		List items = upload.parseRequest(request);
		Iterator iter = items.iterator();
		while (iter.hasNext()) {
			FileItem item = (FileItem) iter.next();
			if (!item.isFormField()) {
				try {
					UploadFileInfo info = processUploadedFile(item);

				} catch (Exception e) {
					throw new FileUploadException("上传文件保存失败：" + e.getMessage());
				}

			}
		}
		return list;
	}

	/**
	 * processUploadedFile<br/>
	 * 方法描述：合成文件的基本信息 <br/>
	 * 
	 * @param item
	 *            void
	 * @throws Exception
	 * @exception
	 * @since 1.0.0
	 */

	private UploadFileInfo processUploadedFile(FileItem item) throws Exception {
		long time = new Date().getTime();
		UploadFileInfo info = new UploadFileInfo();
		UploadSetting setting = getUploadSettingService()
				.getSettingByFileClass(fileClass);

		if (setting == null) {
			UploadSetting set = new UploadSetting();
			set.setFileClass(fileClass);
			set.setFilePath(filePath);
			set.setFileDir("");
			set.setFileMax(fileMax);
			set.setIsActive(1);
			set.setFileCount(0);
			getUploadSettingService().createSetting(set);
			return processUploadedFile(item);
		}

		info.setFilePath(setting.getFilePath());
		info.setFileName(UUID.nameUUIDFromBytes(
				(item.getFieldName() + time).getBytes()).toString());// 按时间和文件名合成UUID　
		info.setFileSize(item.getSize());
		info.setFileType(item.getContentType());
		info.setCdate(time / 1000);

		File file = new File(info.getFilePath() + setting.getFileDir()
				+ info.getFileName());
		item.write(file);
		return info;
	}

	public UploadSettingService getUploadSettingService() {
		return uploadSettingService;
	}

	public void setUploadSettingService(
			UploadSettingService uploadSettingService) {
		this.uploadSettingService = uploadSettingService;
	}

	public String getFileClass() {
		return fileClass;
	}

	public void setFileClass(String fileClass) {
		this.fileClass = fileClass;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public int getFileMax() {
		return fileMax;
	}

	public void setFileMax(int fileMax) {
		this.fileMax = fileMax;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.common.upload.IFileUpload#isValid(org.apache.commons.
	 * fileupload.FileItem)
	 */

	@Override
	public boolean isValid(FileItem item) {
		return true;
	}
}
