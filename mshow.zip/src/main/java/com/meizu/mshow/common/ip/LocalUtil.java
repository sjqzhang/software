package com.meizu.mshow.common.ip;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class LocalUtil {

	private static final String GOOGLE_LOCATION_URL = "http://www.google.com/loc/json";

	/**
	 * 根据提交的ＪＳＯＮ数据取得经纬度信息
	 * 
	 * @param jsondata
	 * @return
	 */
	public static GPoint getPoint(String jsondata) {
		DefaultHttpClient client = new DefaultHttpClient();
		client.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);
		HttpPost post = new HttpPost(LocalUtil.GOOGLE_LOCATION_URL);
		StringBuffer sb = new StringBuffer();
		GPoint p = null;
		try {
			StringEntity se = new StringEntity(jsondata, "UTF-8");
			post.setEntity(se);

			HttpResponse resp = client.execute(post);

			HttpEntity entity = resp.getEntity();

			BufferedReader br = new BufferedReader(new InputStreamReader(entity.getContent(), java.nio.charset.Charset.forName("UTF-8")));

			String result = br.readLine();

			while (result != null) {

				sb.append(result);

				result = br.readLine();

			}

			JSONObject resultObject = new JSONObject().parseObject(sb.toString());

			JSONObject locationObject = resultObject.getJSONObject("location");

			if (!locationObject.isEmpty()) {
				double latitude = locationObject.getDouble("latitude");

				double longitude = locationObject.getDouble("longitude");

				JSONObject objaddr = locationObject.getJSONObject("address");

				String address = objaddr.getString("country") + objaddr.getString("region") + objaddr.getString("city") + objaddr.getString("street");

				p = new GPoint(latitude, longitude, objaddr.getString("country"), objaddr.getString("region"), objaddr.getString("city"));
			}
		} catch (Exception err) {

			// throw new BizException("无法取得经纬度信息");
			p = new GPoint(0, 0, "", "", "");

		}

		return p;

	}

	/*
	 * 
	 * 
	 * {"address_language":"zh_CN","wifi_towers":[{"mac_address":"d8:5d:4c:6d:29:60"
	 * ,"age":0,"signal_strength":-74},
	 * {"mac_address":"00:21:29:7d:cf:66","age":0,"signal_strength":-88},
	 * {"mac_address":"00:1c:df:60:cb:3c","age":0,"signal_strength":-92},
	 * {"mac_address":"f4:ec:38:39:39:66","age":0,"signal_strength":-65},
	 * {"mac_address":"e0:05:c5:be:27:88","age":0,"signal_strength":-71}],
	 * "host":"maps.google.com",
	 * "cell_towers":[{"mobile_network_code":0,"location_area_code"
	 * :9876,"mobile_country_code":460,"cell_id":65535},
	 * {"mobile_network_code":0
	 * ,"location_area_code":9876,"mobile_country_code":460,"cell_id":65535},
	 * {"mobile_network_code"
	 * :0,"location_area_code":9876,"mobile_country_code":460,"cell_id":3175},
	 * {"mobile_network_code"
	 * :0,"location_area_code":9876,"mobile_country_code":460,"cell_id":65535},
	 * {
	 * "mobile_network_code":0,"location_area_code":9879,"mobile_country_code":
	 * 460 ,"cell_id":3081},
	 * {"mobile_network_code":0,"location_area_code":9876,"mobile_country_code"
	 * :460,"cell_id":3173}], "request_address":true,"version":"1.1.0"}
	 */
	/* 生成提交的JSON数据 */
	/* 说明：处理短信提交的位置信息，只要是基站信息，因为如果有Wifi直接走Wifi接口 */
	public static String processLocationCell(String data) {
		String[] row = data.split(";");
		JSONObject holder = new JSONObject();
		holder.put("version", "1.1.0");
		holder.put("host", "maps.google.com");
		holder.put("address_language", "zh_CN");
		holder.put("request_address", true);
		JSONArray array = new JSONArray();
		for (int i = 0; i < row.length; ++i) {
			String[] cells = row[i].split(",");
			/*if (cells.length < 4) {
				throw new BizException("location参数不正确");
			}*/
			JSONObject neighData = new JSONObject();
			// 25070
			neighData.put("cell_id", cells[0]); 
			// 4474
			neighData.put("location_area_code", cells[1]);
			// 460
			neighData.put("mobile_country_code", cells[2]);
			// 0
			neighData.put("mobile_network_code", cells[3]);
			array.add(neighData);
		}
		holder.put("cell_towers", array);
		return holder.toString();
	}

	/**
	 * 
	 * @param map
	 * @return
	 */
	public static GPoint getPoint(List<Map<String, String>> listMap) {
		String cellId, locationAreaCode, mobileCountryCode, mobileNetworkCode, cellTowers = "";

		for (int i = 0; i < listMap.size(); i++) {
			Map<String, String> map = listMap.get(i);
			cellId = map.get("cell_id");
			locationAreaCode = map.get("location_area_code");
			mobileCountryCode = map.get("mobile_country_code");
			mobileNetworkCode = map.get("mobile_network_code");
			cellTowers += cellId + "," + locationAreaCode + "," + mobileCountryCode + "," + mobileNetworkCode + ";";

		}
		if (cellTowers.length() > 0){
			cellTowers = cellTowers.substring(0, cellTowers.length() - 1);
		}
		return getPoint(processLocationCell(cellTowers));

	}

	public static void main(String[] args) {

		GPoint point = getPoint(processLocationCell("3173,9876,460,0"));
		System.out.println(point.getLocalName());
	}

}
