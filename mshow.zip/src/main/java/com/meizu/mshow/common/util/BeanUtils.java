package com.meizu.mshow.common.util;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

/**
 * 
 * <b>类名称：</b>BeanUtils<br/>
 * <b>类描述：Bean工具类</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-4 下午1:28:28<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */
public class BeanUtils {

	private static String defaultDatePattern = "yyyy-MM-dd";

	@SuppressWarnings("rawtypes")
	public static <T> List<T> map2Bean(List<Object> list, Class<T> cls) {
		List<T> retlist = new ArrayList<T>();
		for (int i = 0; i < list.size(); i++) {
			retlist.add(map2Bean((Map) list.get(i), cls));
		}
		return retlist;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static <T> T map2Bean(Map map, Class<T> cls) {
		Object obj = null;
		try {
			obj = cls.newInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// 取出bean里的所有方法
		Method[] methods = cls.getMethods();
		for (int i = 0; i < methods.length; i++) {
			// 取方法名
			String method = methods[i].getName();
			// 取出方法的类型
			Class[] cc = methods[i].getParameterTypes();
			if (cc.length != 1)
				continue;

			// 如果方法名没有以set开头的则退出本次for
			if (method.indexOf("set") < 0)
				continue;
			// 类型
			String type = cc[0].getSimpleName();

			try {
				// 转成小写
				// Object value = method.substring(3).toLowerCase();
				Object value = method.substring(3, 4).toLowerCase() + method.substring(4);
				// 如果map里有该key
				if (map.containsKey(value) && map.get(value) != null) {
					// 调用其底层方法
					setValue(type, map.get(value), i, methods, obj);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return (T) obj;
	}

	private static void setValue(String type, Object value, int i, Method[] method, Object bean) {
		if (value != null && !value.equals("")) {
			try {
				if (type.equals("String")) {
					// 第一个参数:从中调用基础方法的对象 第二个参数:用于方法调用的参数
					method[i].invoke(bean, new Object[] { value });
				} else if (type.equals("int") || type.equals("Integer")) {
					method[i].invoke(bean, new Object[] { new Integer("" + value) });
				} else if (type.equals("long") || type.equals("Long")) {
					method[i].invoke(bean, new Object[] { new Long("" + value) });
				} else if (type.equals("boolean") || type.equals("Boolean")) {
					method[i].invoke(bean, new Object[] { Boolean.valueOf("" + value) });
				} else if (type.equals("BigDecimal")) {
					method[i].invoke(bean, new Object[] { new BigDecimal("" + value) });
				} else if (type.equals("Date")) {
					Date date = null;
					if (value.getClass().getName().equals("java.util.Date")) {
						date = (Date) value;
					} else if (value.getClass().getName().equals("java.sql.Timestamp")) {
						date = new Date(((Timestamp) (value)).getTime());
					} else if (value.getClass().getName().equals("java.lang.Integer")) {
						date = new Date(((Integer) (value)));
					} else {
						String format = ((String) value).indexOf(":") > 0 ? "yyyy-MM-dd hh:mm:ss" : "yyyy-MM-dd";
						SimpleDateFormat fmt = new SimpleDateFormat(format);
						date = fmt.parse((String) value);

					}
					if (date != null) {
						method[i].invoke(bean, new Object[] { date });
					}
				} else if (type.equals("byte[]")) {
					method[i].invoke(bean, new Object[] { new String(value + "").getBytes() });
				}
			} catch (Exception e) {
				System.out.println("将linkHashMap 或 HashTable 里的值填充到javabean时出错,请检查!");
				e.printStackTrace();
			}
		}
	}

	private static PropertyDescriptor[] getPropertyDescriptors(Object obj) {
		BeanInfo ObjInfo;
		try {
			ObjInfo = Introspector.getBeanInfo(obj.getClass());
		} catch (IntrospectionException e) {
			return new PropertyDescriptor[0];
		}
		PropertyDescriptor[] propertyDesc = ObjInfo.getPropertyDescriptors();
		return propertyDesc;
	}

	//
	// public static void mapToPojo(Map map, Object obj) {
	// PropertyDescriptor[] propertyDesc = getPropertyDescriptors(obj);
	// for (int i = 0; i < propertyDesc.length; i++) {
	// if (propertyDesc[i].getName().compareToIgnoreCase("class") == 0)
	// continue;
	// // String strValue = (String) map.get(propertyDesc[i].getName());
	// String strValue = String
	// .valueOf(map.get(propertyDesc[i].getName()));
	// Object value = parseObject(strValue,
	// propertyDesc[i].getPropertyType());
	// try {
	// propertyDesc[i].getWriteMethod().invoke(obj, value);
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }
	// }

	public static void map2pojo(Map<String, Object> map, Object obj) throws Exception {

		Class<? extends Object> clazz = obj.getClass();
		for (Entry<String, Object> entry : map.entrySet()) {
			try {
				Field field = clazz.getDeclaredField(entry.getKey());
				field.setAccessible(true);
				field.set(obj, entry.getValue());
			} catch (Exception e) {
				throw new Exception(entry.getKey() + "属性不存在");
			}
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void pojoToMap(Object obj, Map map) {
		PropertyDescriptor[] propertyDesc = getPropertyDescriptors(obj);
		for (int i = 0; i < propertyDesc.length; i++) {
			if (propertyDesc[i].getName().compareToIgnoreCase("class") == 0)
				continue;
			propertyDesc[i].getName();
			try {
				map.put(propertyDesc[i].getName(), propertyDesc[i].getReadMethod().invoke(obj));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static java.util.Date toDate(String dateStr) {
		String pattern = "yyyy-MM-dd";
		if (dateStr.indexOf(".") > 0) {
			pattern = "yyyy-MM-dd HH:mm:ss.SSS";
		} else if (dateStr.indexOf(":") > 0) {
			pattern = "yyyy-MM-dd HH:mm:ss";
		}
		return toDate(dateStr, pattern);
	}

	public static java.util.Date toDate(String dateStr, String pattern) {
		SimpleDateFormat sdf = new SimpleDateFormat(pattern == null ? defaultDatePattern : pattern, Locale.CHINA);
		java.util.Date dateReturn = null;
		try {
			dateReturn = sdf.parse(dateStr);
		} catch (ParseException e) {
			System.out.println((new StringBuilder("unknown date format:")).append(dateStr).toString());
		}
		return dateReturn;
	}

	public static Calendar toCalendar(String dateStr) {
		return toCalendar(dateStr, null);
	}

	public static Calendar toCalendar(String dateStr, String pattern) {
		java.util.Date date = toDate(dateStr, pattern);
		Calendar calendarReturn = Calendar.getInstance();
		calendarReturn.setTime(date);
		return calendarReturn;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Object parseObject(String fromObj, Class toClass) {
		Object objReturn = null;
		if (fromObj.equals("")) {
			return objReturn;
		}
		String toClassName = toClass.getName();
		if (fromObj.getClass().getName().equals(toClassName)) {
			objReturn = fromObj;
		} else if ("java.util.Date".equals(toClassName)) {
			objReturn = toDate(fromObj);
		} else if ("java.util.Calendar".equals(toClassName)) {
			objReturn = toCalendar(fromObj);
		} else if ("java.sql.Date".equals(toClassName)) {
			objReturn = new Date(toDate(fromObj).getTime());
		} else if ("java.sql.Time".equals(toClassName)) {
			objReturn = new Timestamp(toDate(fromObj).getTime());
		} else if ("java.sql.Timestamp".equals(toClassName)) {
			objReturn = new Timestamp(toDate(fromObj, "yyyy-MM-dd HH:mm:ss.SSS").getTime());
		} else if ("java.lang.Integer".equals(toClassName) || "java.lang.Long".equals(toClassName) || "java.lang.Double".equals(toClassName) || "java.lang.Float".equals(toClassName) || "java.math.BigDecimal".equals(toClassName)
				|| "java.lang.Short".equals(toClassName)) {
			try {
				Constructor constructor = toClass.getConstructor(new Class[] { java.lang.String.class });
				objReturn = constructor.newInstance(new Object[] { fromObj });
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			throw new IllegalArgumentException("toClassName= " + toClassName + ", unsupported");
		}
		return objReturn;
	}

	/**
	 * Bean属性拷贝，从Source拷贝到target
	 * <p>
	 * 从Source拷贝内容到target的Bean, 所有的source有的属性，而target没有的属性都被忽略。
	 * <p>
	 * 
	 * @since v0.1
	 * @param source
	 * @param target
	 * 
	 */
	public static void copyProperties(Object source, Object target) {
		org.springframework.beans.BeanUtils.copyProperties(source, target);
	}

	/**
	 * Bean属性拷贝，从Source拷贝到target
	 * <p>
	 * 从Source拷贝内容到target的Bean, 所有的source有的属性，而target没有的属性都被忽略。
	 * 同时忽略掉应有的ignoreProperties指定的属性。
	 * <p>
	 * 
	 * @since v0.1
	 * @param source
	 * @param target
	 * 
	 */
	public static void copyProperties(Object source, Object target, String[] ignoreProperties) {
		org.springframework.beans.BeanUtils.copyProperties(source, target, ignoreProperties);
	}

	/**
	 * 从source对象拷贝指定的属性properties的值到一个新生成的Map，并返回该生成Map对象。
	 * <p>
	 * 生成的对象包含 properties 指定的所有属性。如果指定的属性在源bean里面不存在，将会抛出RuntimeException.
	 * <p>
	 * 日期格式会转换成字符串, 如：2005-8-9。
	 * <p>
	 * 时间： 2009-8-14下午05:12:35 </br>
	 * 
	 * @since v0.1
	 * @param source
	 * @param properties
	 * @return 生成的新的对象，该对象包含了所有properties属性。
	 * @throws Exception 
	 * 
	 */
	public static Map<String, Object> swallowBean(Object source, String... properties) throws Exception {
		if (source == null) {
			return null;
		}
		Map<String, Object> result = new HashMap<String, Object>();
		PropertyDescriptor[] sourcePro = org.springframework.beans.BeanUtils.getPropertyDescriptors(source.getClass());
		for (int i = 0; i < properties.length; i++) {
			boolean existsProp = false;
			for (int j = 0; j < sourcePro.length; j++) {
				if (properties[i].equals(sourcePro[j].getName())) {
					try {
						Object value = sourcePro[j].getReadMethod().invoke(source);
						if (value instanceof java.sql.Date) {
							result.put(properties[i], value);
						} else if (value instanceof java.util.Date) {
							result.put(properties[i], value);
						} else {
							result.put(properties[i], value);
						}
						existsProp = true;
						break;
					} catch (Throwable t) {
						throw new Exception(t);
					}
				}
			}
			if (!existsProp) {
				throw new Exception("Bean's property not exists: " + properties[i]);
			}
		}
		return result;
	}

	/**
	 * 
	 * swallowBeans<br/>
	 * 方法描述：拷贝列表里Bean的指定的属性properties
	 * <p>
	 * 该方法会生成一个新的对象，包含所有的properties属性，生成的新对象将从Object继承 。
	 * <p>
	 * <br/>
	 * 
	 * @param sources
	 * @param properties
	 * @return List
	 * @throws Exception 
	 * @exception
	 * @since 1.0.0
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static List swallowBeans(List sources, String... properties) throws Exception {
		if (sources == null) {
			return null;
		}
		List beans = new ArrayList(sources.size());
		for (int i = 0; i < sources.size(); i++) {
			beans.add(swallowBean(sources.get(i), properties));
		}
		return beans;
	}

	/**
	 * 
	 * swallowBeans<br/>
	 * 方法描述： 批量操作 转换后属性值以别名展示 <br/>
	 * 
	 * @param sources
	 * @param props
	 * @param aliasProps
	 * @return List
	 * @throws Exception 
	 * @exception
	 * @since 1.0.0
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static List swallowBeans(List sources, String[] props, String[] aliasProps) throws Exception {
		if (sources == null) {
			return null;
		}
		List beans = new ArrayList(sources.size());
		for (int i = 0; i < sources.size(); i++) {
			beans.add(swallowBean(sources.get(i), props, aliasProps));
		}
		return beans;
	}

	/**
	 * 
	 * swallowBean<br/>
	 * 方法描述： 转换后属性值以别名展示 <br/>
	 * 
	 * @param source
	 * @param props
	 * @param aliasProps
	 * @return Map<String,Object>
	 * @throws Exception 
	 * @exception
	 * @since 1.0.0
	 */
	public static Map<String, Object> swallowBean(Object source, String[] props, String[] aliasProps) throws Exception {
		if (source == null) {
			return null;
		}
		Map<String, Object> result = new HashMap<String, Object>();
		PropertyDescriptor[] sourcePro = org.springframework.beans.BeanUtils.getPropertyDescriptors(source.getClass());
		for (int i = 0; i < props.length; i++) {
			boolean existsProp = false;
			for (int j = 0; j < sourcePro.length; j++) {
				if (props[i].equals(sourcePro[j].getName())) {
					try {
						Object value = sourcePro[j].getReadMethod().invoke(source);
						if (value instanceof java.sql.Date) {
							result.put(aliasProps[i], value);
						} else if (value instanceof java.util.Date) {
							result.put(aliasProps[i], value);
						} else {
							result.put(aliasProps[i], value);
						}
						existsProp = true;
						break;
					} catch (Throwable t) {
						throw new Exception(t);
					}
				}
			}
			if (!existsProp) {
				throw new Exception("Bean's property not exists: " + props[i]);
			}
		}
		return result;
	}

	/**
	 * @see #swallowBeans(List, String...)
	 * @param sources
	 * @param transMap
	 *            把transMap里面的属性从key转换为value对应的属性。
	 * @param properties
	 * @return
	 * @throws Exception 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static List swallowBeans(List sources, Map<String, String> transMap, String... properties) throws Exception {
		if (sources == null) {
			return null;
		}
		List beans = new ArrayList(sources.size());
		for (int i = 0; i < sources.size(); i++) {
			Map<String, Object> bean = swallowBean(sources.get(i), properties);
			Iterator<Entry<String, String>> iterator = transMap.entrySet().iterator();
			for (; iterator.hasNext();) {
				Entry<String, String> next = iterator.next();
				String key = next.getKey();
				Object object = bean.remove(key);
				bean.put(next.getValue(), object);
			}
			beans.add(bean);
		}
		return beans;
	}

	public static void main(String[] args) {

		// UploadSetting st = new UploadSetting();
		// st.setFileClass("upload");
		// HashMap<String, Object> map = new HashMap<String, Object>();
		//
		// pojoToMap(st, map);
		//
		// System.out.println(map);

	}

	/**
	 * map2pojo<br/>
	 * 方法描述： <br/>
	 * 
	 * @param map
	 * @param obj
	 *            void
	 * @exception
	 * @since 1.0.0
	 */

}
