package com.meizu.mshow.common.base;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.SessionConstants;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.exception.Error;
import com.meizu.mshow.common.security.SecurityUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.UserModel;

public class BaseController {
	private static final Logger logger = Logger.getLogger(BaseController.class);

	private static final String NGINX_HEADER_IP = "x-real-ip";

	protected String getBasePath(HttpServletRequest request) {
		String contextPath = request.getContextPath();
		String port = request.getServerPort() == 80 ? "" : ":" + request.getServerPort();
		String basePath = request.getScheme() + "://" + request.getServerName() + port + contextPath;
		return basePath;
	}

	public String getRemoteIp(HttpServletRequest request) {
		if (request == null) {
			return "127.0.0.1";
		}
		String remoteip = request.getHeader(NGINX_HEADER_IP);
		if (remoteip == null) {
			remoteip = request.getRemoteAddr();
		}
		return remoteip;
	}

	protected UserModel getUser(HttpServletRequest request) throws ApplicationException {
		if (!checkLogin(request)) {
			throw new ApplicationException(Error.INVALID_LOGIN);
		}
		HttpSession session = request.getSession(false);
		UserModel user = null;
		user = (UserModel) session.getAttribute(SessionConstants.SESSION_USER);
		return user;
	}

	protected boolean checkLogin(HttpServletRequest request) {
		return SecurityUtil.checkLogin(request);
	}

	protected long getUserId(HttpServletRequest request) throws ApplicationException {
		HttpSession session = request.getSession(false);
		if (session != null) {
			Long userId = (Long) session.getAttribute(SessionConstants.SESSION_USER_ID);
			if (userId != null)
				return userId.longValue();
			else
				return -1;
		} else {
			return -1;
		}
	}

	protected String getUserName(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		String userName = (String) session.getAttribute(SessionConstants.SESSION_USER_NAME);
		return userName;
	}

	protected QueryModel loadQueryModel(HttpServletRequest request) {
		QueryModel queryModel = new QueryModel();
		try {
			String strStart = request.getParameter("start");
			String strLimit = request.getParameter("limit");
			String strRecordCount = request.getParameter("recordCount");
			String pageForward = request.getParameter("pageForward");
			if (pageForward == null) {
				queryModel.setPageForward(QueryModel.ORDER_BY_DESC);
			} else {
				if (pageForward.equalsIgnoreCase(QueryModel.ORDER_BY_ASC))
					queryModel.setPageForward(QueryModel.ORDER_BY_ASC);
				else
					queryModel.setPageForward(QueryModel.ORDER_BY_DESC);
			}
			int start = 0;
			int limit = queryModel.getLimit();
			long recourdCount = -1;
			if (strStart != null && !strStart.equals("")) {
				try {
					start = Integer.parseInt(strStart);
				} catch (Exception e) {
					start = 0;
					logger.warn("parse start fail! set defaul 0");
				}
			}
			if (strLimit != null && !strLimit.equals("")) {
				try {
					limit = Integer.parseInt(strLimit);
					if (limit > BusinessConstants.PAGE_MAC_LIMIT)
						limit = BusinessConstants.PAGE_MAC_LIMIT;
				} catch (Exception e) {
					limit = queryModel.getLimit();
					logger.debug("parse limit" + strLimit + " fail! set defaul " + limit);
				}
			}
			if (strRecordCount != null && !strRecordCount.equals("")) {
				try {
					recourdCount = Long.parseLong(strRecordCount);
				} catch (Exception e) {
					recourdCount = -1;
					logger.warn("parse limit fail! set defaul " + limit);
				}
			}
			queryModel.setStart(start);
			queryModel.setLimit(limit);
			queryModel.setRecordCount(recourdCount);
		} catch (Exception e) {
			if (logger.isDebugEnabled())
				logger.error("load querymodel fail", e);
		}
		return queryModel;
	}
}
