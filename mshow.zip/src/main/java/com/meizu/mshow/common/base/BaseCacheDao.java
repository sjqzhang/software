package com.meizu.mshow.common.base;

public class BaseCacheDao extends BaseDao
{

}
