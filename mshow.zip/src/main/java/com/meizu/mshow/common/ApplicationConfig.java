package com.meizu.mshow.common;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class ApplicationConfig {

	private static Properties properties;

	private static final String PROPERTIES_FILE = "applicationconfig.properties";

	private static ApplicationConfig instance = null;

	private static final Logger logger = Logger.getLogger( ApplicationConfig.class );

	public static synchronized ApplicationConfig getInstance() {
		if( instance == null ) {
			instance = new ApplicationConfig();

		}
		return instance;

	}

	public ApplicationConfig() {
		init();
	}

	public void init() {
		properties = new Properties();
		try {
			InputStream is = ApplicationConfig.class.getResourceAsStream( "/"
					+ PROPERTIES_FILE );
			properties.load( is );
		} catch( IOException ioe ) {
			logger.error( ioe );
		}
	}

	public String getProperty( String key ) {
		return properties.getProperty( key );
	}
}
