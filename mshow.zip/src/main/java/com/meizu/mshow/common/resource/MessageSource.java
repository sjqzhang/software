package com.meizu.mshow.common.resource;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Locale;
import java.util.Properties;

import org.springframework.context.support.ResourceBundleMessageSource;

public class MessageSource extends ResourceBundleMessageSource {

	public MessageSource() {
		super();
	}

	public void loadResouceToCache() {
		InputStream is = null;
		try {
			File i18nDir = new File(this.getClass().getClassLoader()
					.getResource("i18n").getPath());
			File[] list = i18nDir.listFiles();
			for (int i = 0; list != null && i < list.length; i++) {
				is = this.getClass().getClassLoader()
						.getResourceAsStream("i18n/" + list[i].getName());
				Properties lables = new Properties();
				lables.load(is);
				String[] i18nFileName = list[i].getName().split("_");
				Locale locale = new Locale("", "");
				if (i18nFileName.length > 1) {
					locale = new Locale(
							i18nFileName[1],
							i18nFileName[i18nFileName.length - 1].split("\\.")[0]);
				}
				for (Iterator iter = lables.keySet().iterator(); iter.hasNext();) {
					super.resolveCode(iter.next().toString(), locale);
				}
				logger.info("all messageformat in [" + list[i].getName()
						+ "] was loaded ");
			}
			try {
				if (is != null)
					is.close();
			} catch (Exception ex) {
				logger.error(
						"inputstream can not be cloed when load messageformat",
						ex);
			}
			logger.info("all messageformat was loaded!");
		} catch (RuntimeException re) {
			re.printStackTrace();
			logger.warn("load resouce to cache failed!", re.getCause());
		} catch (IOException e) {
			e.printStackTrace();
			logger.warn("load resouce to cache failed!", e.getCause());
		} finally {
			try {
				if (is != null)
					is.close();
			} catch (Exception ex) {
				logger.error(
						"inputstream can not be cloed when load messageformat",
						ex);
			}
		}
	}
}
