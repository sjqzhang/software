package com.meizu.mshow.common.servlet;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.meizu.mshow.common.SessionConstants;

public class InitSessionFilter implements Filter {
	private static final Logger logger = Logger.getLogger(InitSessionFilter.class);

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		try {
			HttpServletRequest httpServletRequest = (HttpServletRequest) request;
			HttpSession session = httpServletRequest.getSession(false);
			if (session.getAttribute(SessionConstants.SESSION_USER_ID) == null) {

			}
			chain.doFilter(request, response);
		} catch (IOException ioe) {
			throw ioe;

		} catch (ServletException se) {
			throw se;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}

	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}
}
