package com.meizu.mshow.common.base;

public class BaseResultModel {

	private int returnCode = 0;

	private String returnMessage="";

	private Object returnValue;

	private String returnUrl="";

	public int getReturnCode() {
		return returnCode;
	}

	public void setReturnCode( int returnCode ) {
		this.returnCode = returnCode;
	}

	public String getReturnMessage() {
		return returnMessage;
	}

	public void setReturnMessage( String returnMessage ) {
		this.returnMessage = returnMessage;
	}

	public Object getReturnValue() {
		return returnValue;
	}

	public void setReturnValue( Object returnValue ) {
		this.returnValue = returnValue;
	}

	public String getReturnUrl() {
		return returnUrl;
	}

	public void setReturnUrl( String returnUrl ) {
		this.returnUrl = returnUrl;
	}

}