package com.meizu.mshow.common.ip;

public interface Message {   
    String bad_ip_file="IP地址库文件错误";   
    String unknown_country="未知国家";   
    String unknown_area="未知地区";   
}  