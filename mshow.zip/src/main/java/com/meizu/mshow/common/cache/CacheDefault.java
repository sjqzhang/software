/**
 * <b>项目名：</b>spring3.1<br/>
 * <b>包名：</b>com.spring.study<br/>
 * <b>文件名：</b>Cache.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2013-1-7-下午1:36:15<br/>
 * <b>Copyright (c)</b> 2013魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.common.cache;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

/**
 * <b>类名称：</b>Cache<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-7 下午1:36:15<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public final class CacheDefault implements ICache {

	/**
	 * 创建一个新的实例 CacheDefault.
	 */

	@SuppressWarnings("unused")
	private static Logger logger = Logger.getLogger(CacheDefault.class);
	// 实例引用
	private static ICache _cacheDefault;

	// 注册事件列表
	private final static ArrayList<ICacheEvent> eventList = new ArrayList<ICacheEvent>();

	// 是否开启事件支持
	@SuppressWarnings("unused")
	private static boolean enableEVent = true;

	// 是否调试

	@SuppressWarnings("unused")
	private static boolean isDebug = true;

	// Key是否使用ＭＤ５
	// private static boolean enableMd5 = false;

	private CacheDefault() {
	}

	public static ICache getInstance() {
		if (_cacheDefault == null) {

			_cacheDefault = new CacheRedis();
		}
		return _cacheDefault;
	}

	class CacheObject {
		private int ttl;
		private Object obect;
		private long startTime;

		/**
		 * 创建一个新的实例 CacheDefault.CacheObject.
		 */

		public CacheObject(int ttl, Object obj) {
			this.obect = obj;
			this.ttl = ttl;
			this.startTime = System.currentTimeMillis() / 1000;
		}

		public int getTtl() {
			return ttl;
		}

		public void setTtl(int ttl) {
			this.ttl = ttl;
		}

		public Object getObect() {
			return obect;
		}

		public void setObect(Object obect) {
			this.obect = obect;
		}

		public long getStartTime() {
			return startTime;
		}

		public void setStartTime(long startTime) {
			this.startTime = startTime;
		}
	}

	// private final static HashMap<String, CacheObject> cacheMap = new
	// HashMap<String, CacheObject>(1000000);

	// private final static ConcurrentHashMap<String, CacheObject> cacheMap =
	// new ConcurrentHashMap<String, CacheObject>(1000000);
	private final static ConcurrentHashMap<String, ConcurrentHashMap<String, CacheObject>> cacheMap = new ConcurrentHashMap<String, ConcurrentHashMap<String, CacheObject>>(100);

	@SuppressWarnings("unused")
	private final static ConcurrentHashMap<String, ConcurrentHashMap<String, CacheObject>> asyncMap = new ConcurrentHashMap<String, ConcurrentHashMap<String, CacheObject>>(10);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.spring.study.ICache#get(java.lang.Class)
	 */

	@Override
	public <T> T get(CacheCategory category, String key, Class<T> classType) {
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.spring.study.ICache#put(java.lang.Object)
	 */

	 /*private void put(String key, Object obj) {
	 CacheObject cacheObject = new CacheObject(-1, obj);
	 cacheMap.put(key, cacheObject);
	 if (eventList.size() > 0) {
	 asyncMap.put("onput:" + key, cacheObject);
	 }
	 }*/

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.spring.study.ICache#put(java.lang.Object, int)
	 */

	@Override
	public void put(CacheCategory category, String key, Object obj, int ttl) {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.spring.study.ICache#remove(java.lang.String)
	 */

	@Override
	public void remove(CacheCategory category, String key) {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.common.cache.ICache#flush(com.meizu.mshow.common.cache
	 * .CacheCategory)
	 */

	@Override
	public void flush(CacheCategory categroy) {
		cacheMap.remove(categroy.getVal());

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.meizu.mshow.common.cache.ICache#flushAll()
	 */

	@Override
	public void flushAll() {
		cacheMap.clear();
	}

	@Override
	public void addEventLister(ICacheEvent event) {
		if (event != null) {
			eventList.add(event);
		}
	}

	public static void main(String[] args) {
		// 性能测试
		ICache cache = CacheDefault.getInstance();
		long start = System.currentTimeMillis();
		ArrayList<Double> list = new ArrayList<Double>();
		for (int i = 0; i < 1000000; i++) {
			Double rnd = Math.random();
			cache.put(CacheCategory.Defalut, rnd.toString(), rnd, -1);
			if (i % 10000 == 0) {
				list.add(rnd);
			}
		}
		for (int i = 0; i < list.size(); i++) {
			System.out.println(cache.get(CacheCategory.Defalut, list.get(i).toString(), Double.class));
		}
		System.out.println(list.size());
		long end = System.currentTimeMillis();
		System.out.println(end - start);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.meizu.mshow.common.cache.ICache#isDebug()
	 */

	@Override
	public boolean isDebug() {
		
		return false;
	}

}
