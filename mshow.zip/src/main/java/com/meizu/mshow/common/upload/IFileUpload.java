/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.common.upload<br/>
 * <b>文件名：</b>IFileUpload.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2012-12-4-上午9:48:42<br/>
 * <b>Copyright (c)</b> 2012魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.common.upload;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;

import com.meizu.mshow.domain.pojo.UploadFileInfo;

/**
 * <b>类名称：</b>IFileUpload<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 * 文件上传接口
 * </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-4 上午9:48:42<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public interface IFileUpload {

	/**
	 * 
	 * upload<br/>
	 * 方法描述：文件上传接口，返回文件的基本信息 <br/>
	 * 
	 * @param request
	 * @param response
	 * @return UploadFileInfo
	 * @throws FileUploadException
	 * @exception
	 * @since 1.0.0
	 */
	public List<UploadFileInfo> upload(HttpServletRequest request,
			HttpServletResponse response) throws FileUploadException;

	/**
	 * 
	 * isValid<br/>
	 * 方法描述：检查上传文件是否符合要求 <br/>
	 * 
	 * @param item
	 * @return boolean
	 * @exception
	 * @since 1.0.0
	 */
	public boolean isValid(FileItem item);

}
