package com.meizu.mshow.common.cache;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import redis.clients.jedis.Builder;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.Pipeline;
import redis.clients.jedis.SortingParams;
import redis.clients.util.SafeEncoder;

import com.meizu.mshow.common.util.ServiceLocator;

public class RedisUtil {

	private static final Logger logger = Logger.getLogger(RedisUtil.class);

	public RedisUtil() {
		super();
	}

	public long zcount(String key, double min, double max) {
		JedisPool readPool = null;
		Jedis jedis = null;
		try {
			readPool = ServiceLocator.getCacheRouter().getReadJedisPool();
			jedis = readPool.getResource();
			long value = jedis.zcount(key, min, max);
			readPool.returnResource(jedis);
			return value;
		} catch (Throwable T) {
			try {
				logger.error(T.getCause(), T);
				if (jedis != null)
					readPool.returnBrokenResource(jedis);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return -1;
	}

	public long increase(String key) {
		JedisPool writePool = null;
		Jedis jedis = null;
		try {
			writePool = ServiceLocator.getCacheRouter().getWriteJedisPool();
			jedis = writePool.getResource();
			Long id = jedis.incr(key);
			writePool.returnResource(jedis);
			return id;
		} catch (Throwable T) {
			try {
				logger.error(T.getCause(), T);
				if (jedis != null)
					writePool.returnBrokenResource(jedis);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return -1;
	}

	public long expire(String key, int second) {
		JedisPool writePool = null;
		Jedis jedis = null;
		try {
			writePool = ServiceLocator.getCacheRouter().getWriteJedisPool();
			jedis = writePool.getResource();
			Long status = jedis.expire(key, second);
			writePool.returnResource(jedis);
			return status;
		} catch (Throwable T) {
			try {
				logger.error(T.getCause(), T);
				if (jedis != null)
					writePool.returnBrokenResource(jedis);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return -1;
	}

	public String setString(String key, String value) {
		JedisPool writePool = null;
		Jedis jedis = null;
		try {
			writePool = ServiceLocator.getCacheRouter().getWriteJedisPool();
			jedis = writePool.getResource();
			String status = jedis.set(key, value);
			writePool.returnResource(jedis);
			return status;
		} catch (Throwable T) {
			try {
				logger.error(T.getCause(), T);
				if (jedis != null)
					writePool.returnBrokenResource(jedis);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return null;
	}

	public String setString(String key, String value, int exsec) {
		JedisPool writePool = null;
		Jedis jedis = null;
		try {
			writePool = ServiceLocator.getCacheRouter().getWriteJedisPool();
			jedis = writePool.getResource();
			String status = null;
			if (exsec > 0) {
				status = jedis.setex(key, exsec, value);
			} else {
				status = jedis.set(key, value);
			}
			writePool.returnResource(jedis);
			return status;
		} catch (Throwable T) {
			try {
				logger.error(T.getCause(), T);
				if (jedis != null) {
					writePool.returnBrokenResource(jedis);
				}
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return null;
	}

	public String getString(String key) {
		JedisPool readPool = null;
		Jedis jedis = null;
		try {
			readPool = ServiceLocator.getCacheRouter().getReadJedisPool();
			jedis = readPool.getResource();
			String value = jedis.get(key);
			readPool.returnResource(jedis);
			return value;
		} catch (Throwable T) {
			try {
				logger.error(T.getCause(), T);
				if (jedis != null) {
					readPool.returnBrokenResource(jedis);
				}
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return null;
	}

	public List<Object> batchSetString(final List<Pair<String, String>> pairs, int sec) {
		JedisPool writePool = null;
		Jedis jedis = null;
		try {
			writePool = ServiceLocator.getCacheRouter().getWriteJedisPool();
			jedis = writePool.getResource();
			Pipeline pipeline = jedis.pipelined();
			for (Pair<String, String> pair : pairs) {
				if (sec > 0) {
					pipeline.setex(pair.getKey(), sec, pair.getValue());
				} else {
					pipeline.set(pair.getKey(), pair.getValue());
				}
			}
			List<Object> status = pipeline.syncAndReturnAll();
			writePool.returnResource(jedis);
			return status;
		} catch (Throwable T) {
			try {
				if (jedis != null) {
					writePool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return null;
	}

	public List<String> batchGetString(final Collection<String> keys) {
		JedisPool readPool = null;
		Jedis jedis = null;
		try {
			readPool = ServiceLocator.getCacheRouter().getReadJedisPool();
			jedis = readPool.getResource();
			Pipeline pipeline = jedis.pipelined();
			for (String key : keys) {
				pipeline.get(key);
			}
			List<Object> dataList = pipeline.syncAndReturnAll();
			readPool.returnResource(jedis);
			List<String> rtnDataList = new ArrayList<String>();
			for (Object data : dataList) {
				if (data != null) {
					rtnDataList.add(data.toString());
				} else {
					rtnDataList.add(null);
				}
			}
			if (rtnDataList.size() > 0) {
				return rtnDataList;
			}
		} catch (Throwable T) {
			try {
				if (jedis != null) {
					readPool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return null;
	}

	public List<String> batchGetString(final Collection<String> keys, String prefix) {
		JedisPool readPool = null;
		Jedis jedis = null;
		try {
			readPool = ServiceLocator.getCacheRouter().getReadJedisPool();
			jedis = readPool.getResource();
			Pipeline pipeline = jedis.pipelined();
			for (String key : keys) {
				pipeline.get(prefix + key);
			}
			List<Object> dataList = pipeline.syncAndReturnAll();
			readPool.returnResource(jedis);
			List<String> rtnDataList = new ArrayList<String>();
			for (Object data : dataList) {
				if (data != null) {
					rtnDataList.add(data.toString());
				} else {
					rtnDataList.add(null);
				}
			}
			if (rtnDataList.size() > 0) {
				return rtnDataList;
			}
		} catch (Throwable T) {
			try {
				if (jedis != null) {
					readPool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return null;
	}

	public long hashSet(String key, String field, String value) {
		JedisPool writePool = null;
		Jedis jedis = null;
		try {
			writePool = ServiceLocator.getCacheRouter().getWriteJedisPool();
			jedis = writePool.getResource();
			long count = jedis.hset(key, field, value);
			writePool.returnResource(jedis);
			return count;
		} catch (Throwable T) {
			try {
				logger.error(T.getCause(), T);
				if (jedis != null) {
					writePool.returnBrokenResource(jedis);
				}
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return -1;
	}

	public String hashGet(String key, String field) {
		JedisPool readPool = null;
		Jedis jedis = null;
		try {
			readPool = ServiceLocator.getCacheRouter().getReadJedisPool();
			jedis = readPool.getResource();
			String value = jedis.hget(key, field);
			readPool.returnResource(jedis);
			return value;
		} catch (Throwable T) {
			try {
				if (jedis != null) {
					readPool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
		}
		return null;
	}

	public String hashMultipleSet(String key, Map<String, String> hash) {
		JedisPool writePool = null;
		Jedis jedis = null;
		try {
			writePool = ServiceLocator.getCacheRouter().getWriteJedisPool();
			jedis = writePool.getResource();
			String count = jedis.hmset(key, hash);
			writePool.returnResource(jedis);
			return count;
		} catch (Throwable T) {
			try {
				logger.error(T.getCause(), T);
				if (jedis != null) {
					writePool.returnBrokenResource(jedis);
				}
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return null;
	}

	public List<String> hashMultipleGet(String key, String... fields) {

		JedisPool readPool = null;
		Jedis jedis = null;
		try {
			readPool = ServiceLocator.getCacheRouter().getReadJedisPool();
			jedis = readPool.getResource();
			List<String> dataList = jedis.hmget(key, fields);
			readPool.returnResource(jedis);
			if (dataList != null && dataList.size() > 0) {
				return dataList;
			}
		} catch (Throwable T) {
			try {
				if (jedis != null) {
					readPool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
		}
		return null;
	}

	public Long delete(String[] key) {
		JedisPool writePool = null;
		Jedis jedis = null;
		long retValue = -1;
		try {
			writePool = ServiceLocator.getCacheRouter().getReadJedisPool();
			jedis = writePool.getResource();
			retValue = jedis.del(key);
			writePool.returnResource(jedis);
		} catch (Throwable T) {
			try {
				if (jedis != null) {
					writePool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return retValue;
	}

	public final Builder<String> STRING = new Builder<String>() {

		@Override
		public String build(Object data) {
			return SafeEncoder.encode((byte[]) data);
		}

		@Override
		public String toString() {
			return "string";
		}

	};

	public final Builder<List<String>> STRING_LIST = new Builder<List<String>>() {

		@Override
		@SuppressWarnings("unchecked")
		public List<String> build(Object data) {
			if (null == data) {
				return null;
			}
			List<byte[]> l = (List<byte[]>) data;
			final ArrayList<String> result = new ArrayList<String>(l.size());
			for (final byte[] barray : l) {
				if (barray == null) {
					result.add(null);
				} else {
					result.add(SafeEncoder.encode(barray));
				}
			}
			return result;
		}

		@Override
		public String toString() {
			return "List<String>";
		}

	};

	public final Builder<Map<String, String>> STRING_MAP = new Builder<Map<String, String>>() {

		@Override
		@SuppressWarnings("unchecked")
		public Map<String, String> build(Object data) {
			final List<byte[]> flatHash = (List<byte[]>) data;
			final Map<String, String> hash = new HashMap<String, String>();
			final Iterator<byte[]> iterator = flatHash.iterator();
			while (iterator.hasNext()) {
				hash.put(SafeEncoder.encode(iterator.next()), SafeEncoder.encode(iterator.next()));
			}

			return hash;
		}

		@Override
		public String toString() {
			return "Map<String, String>";
		}

	};

	public <K, V> Pair<K, V> makePair(K key, V value) {
		return new Pair<K, V>(key, value);
	}

	// 取Redis中具体一个List中，从start开始，至end结束的数据P1_COMMENTS
	public List<String> lrange(String key, long start, long end) {
		JedisPool readPool = null;
		Jedis jedis = null;
		List<String> dataList = null;
		try {
			readPool = ServiceLocator.getCacheRouter().getReadJedisPool();
			jedis = readPool.getResource();
			dataList = jedis.lrange(key, start, end);
			readPool.returnResource(jedis);
			return dataList;
		} catch (Throwable T) {
			try {
				if (jedis != null) {
					readPool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return dataList;
	}

	public Set<String> zrevrangebyscore(String key, int offset, int count, double max, double min) {
		JedisPool readPool = null;
		Jedis jedis = null;
		Set<String> dataList = null;
		try {
			readPool = ServiceLocator.getCacheRouter().getReadJedisPool();
			jedis = readPool.getResource();
			dataList = jedis.zrevrangeByScore(key, max, min, offset, count);
			readPool.returnResource(jedis);
			return dataList;
		} catch (Throwable T) {
			try {
				if (jedis != null) {
					readPool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return dataList;
	}

	public Set<String> zrangebyscore(String key, int offset, int count, double max, double min) {
		JedisPool readPool = null;
		Jedis jedis = null;
		Set<String> dataList = null;
		try {
			readPool = ServiceLocator.getCacheRouter().getReadJedisPool();
			jedis = readPool.getResource();
			dataList = jedis.zrangeByScore(key, min, max, offset, count);
			readPool.returnResource(jedis);
			return dataList;
		} catch (Throwable T) {
			try {
				if (jedis != null) {
					readPool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return dataList;
	}

	// 取Redis中具体一个List中，从start开始，至end结束的数据
	public List<String> sort(String mainListKey, String[] subKeyPattern, int start, int count) {
		JedisPool readPool = null;
		Jedis jedis = null;
		List<String> dataList = null;
		if (subKeyPattern == null || subKeyPattern.length == 0) {
			subKeyPattern = new String[] { "#" };
		}
		try {
			readPool = ServiceLocator.getCacheRouter().getReadJedisPool();
			jedis = readPool.getResource();
			SortingParams sortingParameters = new SortingParams();
			sortingParameters.limit(start, count);
			sortingParameters.get(subKeyPattern);
			sortingParameters.by("nonexistentkey");
			dataList = jedis.sort(mainListKey, sortingParameters);
			readPool.returnResource(jedis);
			return dataList;
		} catch (Throwable T) {
			try {
				if (jedis != null) {
					readPool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return dataList;
	}

	public Set<String> smembers(String key) {
		JedisPool readPool = null;
		Jedis jedis = null;
		try {
			readPool = ServiceLocator.getCacheRouter().getReadJedisPool();
			jedis = readPool.getResource();
			Set<String> status = jedis.smembers(key);
			readPool.returnResource(jedis);
			return status;
		} catch (Throwable T) {
			try {
				if (jedis != null) {
					readPool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return null;
	}

	public void zadd(String key, Map<Double, String> members, int sec) {
		JedisPool writePool = null;
		Jedis jedis = null;
		try {
			writePool = ServiceLocator.getCacheRouter().getWriteJedisPool();
			jedis = writePool.getResource();
			jedis.zadd(key, members);
			if (sec > 0) {
				jedis.expire(key, sec);
			}
			writePool.returnResource(jedis);
		} catch (Throwable T) {
			try {
				if (jedis != null) {
					writePool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
	}

	public void zadd(String key, double score, String member, int sec) {
		JedisPool writePool = null;
		Jedis jedis = null;
		try {
			writePool = ServiceLocator.getCacheRouter().getWriteJedisPool();
			jedis = writePool.getResource();
			jedis.zadd(key, score, member);
			if (sec > 0) {
				jedis.expire(key, sec);
			}
			writePool.returnResource(jedis);
		} catch (Throwable T) {
			try {
				if (jedis != null) {
					writePool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
	}

	public void zrem(String key, String[] members) {
		JedisPool writePool = null;
		Jedis jedis = null;
		try {
			writePool = ServiceLocator.getCacheRouter().getWriteJedisPool();
			jedis = writePool.getResource();
			jedis.zrem(key, members);
			writePool.returnResource(jedis);
		} catch (Throwable T) {
			try {
				if (jedis != null) {
					writePool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
	}

	public static void rpush(String key, String member) {
		JedisPool writePool = null;
		Jedis jedis = null;
		Set<String> dataList = null;
		try {
			writePool = ServiceLocator.getCacheRouter().getWriteJedisPool();
			jedis = writePool.getResource();
			jedis.rpush(key, member);
			writePool.returnResource(jedis);
		} catch (Exception T) {
			try {
				if (jedis != null) {
					writePool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
	}

	public static String lpop(String key) {
		JedisPool writePool = null;
		Jedis jedis = null;
		try {
			writePool = ServiceLocator.getCacheRouter().getWriteJedisPool();
			jedis = writePool.getResource();
			String json = jedis.lpop(key);
			writePool.returnResource(jedis);
			return json;
		} catch (Exception T) {
			try {
				if (jedis != null) {
					writePool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return null;
	}

	public static long lcount(String key) {
		JedisPool writePool = null;
		Jedis jedis = null;
		try {
			writePool = ServiceLocator.getCacheRouter().getWriteJedisPool();
			jedis = writePool.getResource();
			long json = jedis.llen(key);
			writePool.returnResource(jedis);
			return json;
		} catch (Exception T) {
			try {
				if (jedis != null) {
					writePool.returnBrokenResource(jedis);
				}
				logger.error(T.getCause(), T);
			} catch (Throwable e) {
				logger.error(e.getCause(), e);
			}
			logger.error(T.getMessage(), T);
		}
		return 0;
	}
}