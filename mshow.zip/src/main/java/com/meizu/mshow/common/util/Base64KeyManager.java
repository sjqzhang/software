/*
 * 类型：Base64KeyManager
 * 版本：
 * 日期：2010-6-6
 * Copyright (C) 2010 中国广东省珠海市魅族科技有限公司版权所有
 * 修改历史记录：
 * 2010-6-6  hewei  初始版本创建      
 */
package com.meizu.mshow.common.util;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import org.springframework.beans.factory.InitializingBean;


/**
 * key保存在Base64字符串<p>
 * 公钥使用 X509EncodedKeySpec 编码
 * 私钥使用 PKCS8EncodedKeySpec 编码
 * @author hewei
 * @version 1.0 2010-6-6
 * @since 1.0
 */
public class Base64KeyManager implements  InitializingBean {

    private PublicKey publicKey;
    private PrivateKey privateKey;
    
    private byte[] bpublicKey;
    private byte[] bprivateKey;
    
    private String algorithm = "RSA";
    
    /** 
     * @see com.meizu.framework.service.security.IKeyManager#getPrivateKey()
     */
    //@Override
    public PrivateKey getPrivateKey() {
        return privateKey;
    }

    /** 
     * @see com.meizu.framework.service.security.IKeyManager#getPublicKey()
     */
   // @Override
    public PublicKey getPublicKey() {
        return publicKey;
    }

    /** 
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        KeyFactory keyFactory = KeyFactory.getInstance(algorithm);
        if(bpublicKey != null){
            publicKey = keyFactory.generatePublic(new X509EncodedKeySpec(bpublicKey));
            bpublicKey = null;
        }
        if(bprivateKey != null){
            privateKey = keyFactory.generatePrivate(new PKCS8EncodedKeySpec(bprivateKey));
            bprivateKey = null;
        }
    }
    
    /**
     * Base64编码的私钥
     * @param base64key
     */
    public void setBase64PrivateKey(String base64key){
        bprivateKey = Base64Coder.decode(base64key);
    }
    
    /**
     * Base64编码的公钥
     * @param base64key
     */
    public void setBase64PublicKey(String base64key){
        bpublicKey = Base64Coder.decode(base64key);
    }
    
    /**
     * 算法， 默认RSA
     */
    public void setAlgorithm(String algorithm) {
        this.algorithm = algorithm;
    }

}
