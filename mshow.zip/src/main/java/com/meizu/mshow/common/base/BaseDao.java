package com.meizu.mshow.common.base;

import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.support.SqlSessionDaoSupport;

public class BaseDao extends SqlSessionDaoSupport {

	protected SqlSession getBatchSqlSession() {
		SqlSessionFactory sqlSessionFactory = ( ( SqlSessionTemplate )getSqlSession() ).getSqlSessionFactory();
		return new SqlSessionTemplate( sqlSessionFactory, ExecutorType.BATCH );
	}
}
