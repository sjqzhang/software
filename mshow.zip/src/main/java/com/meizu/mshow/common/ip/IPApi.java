package com.meizu.mshow.common.ip;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.meizu.mshow.common.util.StringUtil;

public class IPApi {
	private static final Logger logger = org.apache.log4j.Logger.getLogger(IPApi.class);
	/**
	 * 通过IP取地区信息 有异常是因为地址数据库文件读取出错
	 * 
	 * @param ip
	 * @return
	 * @throws IOException
	 */

	public static final String[] ProviceNames = { "山东", "山西", "河南", "河北", "湖南", "湖北", "广东", "广西", "黑龙江", "辽宁", "浙江", "安徽", "江苏", "福建", "甘肃", "江西", "云南", "贵州", "四川", "青海", "陕西", "吉林", "宁夏", "海南", "西藏", "内蒙古", "新疆", "台湾" };

	public static String getAreaByIp(String ip) throws IOException {
		IPSeeker seeker = IPSeeker.getInstance();
		CityInfo city = seeker.getLocation(ip);
		if (city != null) {
			return city.toString();
		} else {
			return "";
		}

	}

	/**
	 * 返回城市信息
	 * 
	 * @param ip
	 * @return
	 * @throws IOException
	 */
	public static CityInfo getCityInfoByIp(String ip) {
		CityInfo city = null;
		try {
			IPSeeker seeker = IPSeeker.getInstance();
			city = seeker.getLocation(ip);
		} catch (Exception e) {
			logger.debug("无法取得相应的IP:" + ip);
		}
		if (city == null) {
			city = new CityInfo("", "");
		}
		return city;
	}

	/**
	 * 返回城市信息
	 * 
	 * @param ip
	 * @return
	 * @throws IOException
	 */
	@Deprecated
	public static CityInfo getCityWithUnitByIp(String ip) {
		CityInfo city = null;
		try {
			IPSeeker seeker = IPSeeker.getInstance();
			city = seeker.getLocation(ip);
			if (city != null) {
				String p = city.getProvince();
				String c = city.getCity();
				if (p != null && !p.equals("") && p.indexOf("省") < 0) {
					city.setProvince(p + "省");
				}
				if (c != null && !c.equals("") && c.indexOf("市") < 0) {
					city.setCity(c + "市");
				}
			}
		} catch (Exception e) {
			logger.error("无法取得相应的IP", e);
		}
		if (city == null) {
			city = new CityInfo("", "");
		}
		return city;
	}

	/**
	 * 通过基站信息取地区信息 其中参数map中要包含以下几个信息 当无法获取信息时,会返回空字符串函数 cell_id,
	 * location_area_code, mobile_network_code, mobile_country_code
	 * 
	 * @param map
	 * @return
	 */
	public static String getAreaByTower(List<Map<String, String>> listMap) {
		return LocalUtil.getPoint(listMap).getLocalName();
	}

	/**
	 * 通过字符串取地区信息
	 * 
	 * @param towerStr
	 * @return
	 */
	public static GPoint getAreaByTowerStr(String towerStr) {
		String postStr = LocalUtil.processLocationCell(towerStr);

		return processProviceName(LocalUtil.getPoint(postStr));
	}

	/**
	 * 按预先设定的名称设定省名
	 * 
	 * @param gp
	 * @return
	 */

	public static GPoint processProviceName(GPoint gp) {
		if (gp == null) {
			return new GPoint(0, 0, "", "", "");
		}
		if (!gp.getProvice().trim().equals("")) {

			for (int i = 0; i < ProviceNames.length; i++) {

				if (gp.getProvice().indexOf(ProviceNames[i]) >= 0) {
					gp.setProvice(ProviceNames[i]);
				}
			}
		}
		return gp;
	}

	/**
	 * 通过Tower信息取地区信息
	 * 
	 * @param towerStr
	 * @param ip
	 * @return
	 */
	@Deprecated
	public static GPoint getAreaByTowerOrIP(String towerStr, String ip) {
		try {
			GPoint gp = new GPoint(0, 0, "", "", "");
			if (!StringUtil.isEmpty(towerStr)) {
				String postStr = LocalUtil.processLocationCell(towerStr);

				// gp= LocalUtil.getPoint(postStr);
				if (gp == null)
					gp = new GPoint(0, 0, "", "", "");
				if (gp.getLat() == 0 && gp.getLng() == 0) {
					CityInfo cityinfo = getCityInfoByIp(ip);
					if (cityinfo != null) {
						gp.setProvice(cityinfo.getProvince());
						gp.setCity(cityinfo.getCity());
					}
				}
			} else {
				CityInfo cityinfo = getCityInfoByIp(ip);
				if (cityinfo != null) {
					gp.setProvice(cityinfo.getProvince());
					gp.setCity(cityinfo.getCity());
				}
			}
			return processProviceName(gp);
		} catch (Exception e) {
			return new GPoint(0, 0, "", "", "");

		}
	}

	/**
	 * 获取本机Ip地址
	 * 
	 * @return
	 */
	public static String getLocalHost() {
		String ip = "127.0.0.1";
		try {
			InetAddress inet = InetAddress.getLocalHost();
			ip = inet.getHostAddress();
		} catch (UnknownHostException err) {
		}
		return ip;
	}

	public static void main(String[] args) {
		System.out.println();

	}
}
