/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.common.cache<br/>
 * <b>文件名：</b>CacheEventImpl.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2013-1-9-上午9:39:58<br/>
 * <b>Copyright (c)</b> 2013魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.common.cache;

import java.util.concurrent.ConcurrentHashMap;

import com.meizu.mshow.common.cache.CacheDefault.CacheObject;

/**
 * <b>类名称：</b>CacheEventImpl<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-9 上午9:39:58<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public class CacheEventImpl implements ICacheEvent {

	/**
	 * 创建一个新的实例 CacheEventImpl.
	 */

	public CacheEventImpl() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.meizu.mshow.common.cache.ICacheEvent#onGet(java.util.concurrent.
	 * ConcurrentHashMap, java.lang.String, java.lang.String)
	 */

	@Override
	public <T> T onGet(ConcurrentHashMap<String, ConcurrentHashMap<String, CacheObject>> cache, String category, String key) {
		System.err.println(key);
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.meizu.mshow.common.cache.ICacheEvent#onPut(java.util.concurrent.
	 * ConcurrentHashMap, java.lang.String, java.lang.String, java.lang.Object)
	 */

	@Override
	public void onPut(ConcurrentHashMap<String, ConcurrentHashMap<String, CacheObject>> cache, String category, String key, Object obj) {

		System.err.println(key);
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.meizu.mshow.common.cache.ICacheEvent#onDel(java.lang.String,
	 * java.lang.String, java.lang.Object)
	 */

	@Override
	public void onDel(String category, String key, Object obect) {
		// TODO Auto-generated method stub

	}

}
