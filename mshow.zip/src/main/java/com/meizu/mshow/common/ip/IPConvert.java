package com.meizu.mshow.common.ip;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class IPConvert {
	/**
	 * ip地址转成整数.
	 * 
	 * @param ip
	 * @return
	 * @throws IOException 
	 */
	/*public static long ip2long(String ip) {
		String[] ips = ip.split("[.]");
		long num = 16777216L * Long.parseLong(ips[0]) + 65536L
				* Long.parseLong(ips[1]) + 256 * Long.parseLong(ips[2])
				+ Long.parseLong(ips[3]);
		return num;
	}*/

	/**
	 * 整数转成ip地址.
	 * 
	 * @param ipLong
	 * @return
	 */
	/*public static String long2ip(long ipLong) {
		 long ipLong = 1037591503;
		long mask[] = { 0x000000FF, 0x0000FF00, 0x00FF0000, 0xFF000000 };
		long num = 0;
		StringBuffer ipInfo = new StringBuffer();
		for (int i = 0; i < 4; i++) {
			num = (ipLong & mask[i]) >> (i * 8);
			if (i > 0)
				ipInfo.insert(0, ".");
			ipInfo.insert(0, Long.toString(num, 10));
		}
		return ipInfo.toString();
	}*/
	
	
    /*private static void run(final IPSeeker ip, final String ipstr, final String expect){
        Thread t = new Thread(){
            *//** 
             * @see java.lang.Thread#run()
             *//*
            @Override
            public void run() {
                for(int i=0; i<100000; i++){
                String city = ip.getIPLocation(ipstr).getCountry();
                if(city.equals(expect)){
                    //System.out.println(city);    
                }else{
                    System.err.println(city);
                }
            }
            }
        };
        t.start();
    }*/

	public static void main(String[] args) throws IOException {
		 /*System.out.println(ip2long("58.20.43.13"));
		 System.out.println(long2ip(3395968127l));
		 指定纯真数据库的文件名，所在文件夹
		IPSeeker ip = IPSeeker.getInstance("X:\\IP数据库", "QQWry.Dat");*/
		IPSeeker ip = IPSeeker.getInstance("D:\\Program Files\\cz88.net\\ip", "QQWry.Dat");
		
		// 测试IP 58.20.43.13
		
		System.out.println(IPSeeker.getLocation("74.86.1.218"));
		System.out.println(IPSeeker.getLocation("122.89.61.122"));
		System.out.println(IPSeeker.getLocation("221.236.31.145"));
		System.out.println(IPSeeker.getLocation("61.147.122.94"));
		System.out.println(IPSeeker.getLocation("220.171.152.136"));
		System.out.println(IPSeeker.getLocation("202.103.240.200"));
		System.out.println(IPSeeker.getLocation("58.155.31.255"));
		System.out.println(IPSeeker.getLocation("219.151.34.142"));
		System.out.println(IPSeeker.getLocation("58.18.118.255"));
		System.out.println(IPSeeker.getLocation("218.95.168.63"));
		System.out.println(IPSeeker.getLocation("219.130.137.134"));
		System.out.println(IPSeeker.getLocation("219.135.73.127"));

		/*run(ip , "125.89.61.122", "广东省珠海市");
		run(ip , "122.89.61.122", "江苏省南通市");
		run(ip , "221.236.31.145", "四川省成都市");
		run(ip , "61.147.122.94", "江苏省连云港市");
		run(ip, "221.4.214.83","");*/
	 }
	
    private static Pattern p=  Pattern.compile("(内蒙古|宁夏|西藏|广西|新疆|\\S{2,3}省)?(\\S{1,4}市).*");

    public static void getCity(String city) throws IOException {
        Matcher m= p.matcher(city);
        
        if (m.matches() && m.groupCount() == 2) {
            String c = m.group(2);
            if(c.charAt(c.length()-1)=='市'){
                System.out.println(c.substring(0, c.length()-1));
            }else{
                System.out.println(c);
            }
        } else {
            System.out.println("-");
        }
    }
}