package com.meizu.mshow.common.security;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.exception.Error;

@Component
@Aspect
public class SecurityInteceptor {

	private Logger logger = Logger.getLogger(SecurityInteceptor.class);

	@Pointcut("@annotation(com.meizu.mshow.common.security.SecurityAnnotation)")
	public void methodSecuriryPointcut() {
	}

	@Around("methodSecuriryPointcut()")
	public Object methodSecuriryHold(ProceedingJoinPoint joinPoint) throws Throwable {
		joinPoint.getSignature();
		Class<? extends Object> clazz = joinPoint.getTarget().getClass();
		String methodName = joinPoint.getSignature().getName();
		Method methods[] = clazz.getMethods();
		Method method = null;
		for (Method method1 : methods) {
			if (method1.isAnnotationPresent(SecurityAnnotation.class) && method1.getName().equals(methodName)) {
				method = method1;
				break;
			}
		}
		SecurityAnnotation annotation = method.getAnnotation(SecurityAnnotation.class);
		if (annotation != null && annotation.gateway()) {
			return joinPoint.proceed();
		}
		ServletRequestAttributes rr = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
		HttpServletRequest request = rr.getRequest();
		if (!SecurityUtil.checkLogin(request)) {
			throw new ApplicationException(Error.INVALID_LOGIN, null, false);
		}
		return joinPoint.proceed();
	}
}
