package com.meizu.mshow.common.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.support.WebApplicationContextUtils;

import com.meizu.mshow.common.util.Base64KeyManager;
import com.meizu.mshow.common.util.RSACoder;

public class LoginServlet extends HttpServlet {

	private Base64KeyManager base64KeyManager;


	private static final long serialVersionUID = 1L;

	@Override
	public void init( ServletConfig config ) throws ServletException {
		super.init( config );

	}

	@SuppressWarnings("unused")
	@Override
	protected void service( HttpServletRequest req, HttpServletResponse resp )
			throws ServletException, IOException {

		
		
		base64KeyManager=(Base64KeyManager)WebApplicationContextUtils.getWebApplicationContext( req.getSession().getServletContext() ).getBean( "Base64KeyManager" );
		
		
		String token = req.getParameter( "token" );

		try {
			String plainToken = RSACoder.decryptWithRSA_AES( token,
					base64KeyManager.getPublicKey() );
		} catch (Exception e) {
			
			e.printStackTrace();
		}

	}



}