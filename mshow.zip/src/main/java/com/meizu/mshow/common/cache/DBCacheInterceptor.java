package com.meizu.mshow.common.cache;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

/**
 * <b>类名称：</b>DBCacheInterceptor<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-6 上午11:05:04<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */
@Component
@Aspect
public class DBCacheInterceptor {
	private Logger logger = Logger.getLogger(DBCacheInterceptor.class);
	public static final String NULL_VALUE = "#NULL_VALUE#";

	@Pointcut("@annotation(com.meizu.mshow.common.cache.DBCache)")
	public void methodSecuriryPointcut() {
	}

	private static ICache sysCache = CacheDefault.getInstance();

	static {
		sysCache.addEventLister(new CacheEventImpl());
	}

	private static final String TPL_REG = "\\#p\\[(\\d+)\\]([^,}]+)?";

	private static final Pattern TPL_PAT = Pattern.compile(TPL_REG);

	@SuppressWarnings("rawtypes")
	private String getCacheKey(String tpl, Object[] args, Method srcMethod) {
		Matcher m = TPL_PAT.matcher(tpl);
		String key = "";
		String methodName = "";
		int index = 0;
		try {
			while (m != null && m.find()) {
				index = Integer.valueOf(m.group(1));
				if (m.groupCount() == 2) {
					if (m.group(2) == null) {
						key += args[index].toString() + "$";
					} else {

						if (args[index] instanceof Map) {
							key += ((Map) (args[index])).get(m.group(2).substring(1)) + "$";
						} else {
							methodName = m.group(2).substring(1, 2).toUpperCase() + m.group(2).substring(2);

							Method method = args[index].getClass().getMethod("get" + methodName, null);
							key += method.invoke(args[index]).toString() + "$";
						}
					}
				} else if (m.groupCount() == 1) {
					key += args[index].toString() + "$";
				}
			}
			return key;
		} catch (Exception e) {
			logger.error("getCacheKey:" + e.getMessage(), e);

		}
		return key;

	}

	@Around("methodSecuriryPointcut()")
	public Object doAround(ProceedingJoinPoint pjp) throws Throwable {
		Signature tt = pjp.getSignature();
		Class<? extends Object> clazz = pjp.getTarget().getClass();
		Method[] methods = clazz.getMethods();
		Object[] args = pjp.getArgs();
		Object retVal = null;
		for (Method method : methods) {
			if (method.getName().equals(tt.getName())) {
				DBCache cache = method.getAnnotation(DBCache.class);
				if (cache != null) {
					String key = cache.keyPrefix() + getCacheKey(cache.key(), args, method);
					if (cache.op() == DBCacheOperation.DELETE) {
						sysCache.remove(cache.category(), key);
					} else if (cache.op() == DBCacheOperation.SELECT) {
						RedisUtil ru = new RedisUtil();
						String value = ru.getString(key);
						if (value != null && value.equals(NULL_VALUE))
							return null;
						retVal = sysCache.get(cache.category(), key, method.getReturnType());
						if (retVal == null) {
							retVal = pjp.proceed();
							if (retVal == null) {
								ru.setString(key, NULL_VALUE, cache.ttl());
							} else {
								sysCache.put(cache.category(), key, retVal, cache.ttl());
							}
						}
						return retVal;
					} else if (cache.op() == DBCacheOperation.INSERT || DBCacheOperation.UPDATE == cache.op()) {
						retVal = pjp.proceed();
						sysCache.put(cache.category(), key, retVal, cache.ttl());
						return retVal;
					}
				}
			}
		}
		retVal = pjp.proceed();
		return retVal;

	}

	public static void main(String[] args) {

		// String tpl = "{\"#p[0].appId\", \"#p[0].contentId\",\"#p[4]\"}";
		String tpl = "#p[0].name";

		Pattern p = Pattern.compile(TPL_REG);

		Matcher m = p.matcher(tpl);

		while (m.find()) {
			System.out.println(m.group(1));
		}

		HashMap<String, String> map = new HashMap<String, String>();

		System.out.println(map instanceof Map);

	}

}
