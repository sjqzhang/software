/*
 * 类型：CityInfo
 * 版本：
 * 日期：2011-1-20
 * Copyright (C) 2010 中国广东省珠海市魅族科技有限公司版权所有
 * 修改历史记录：
 * 2011-1-20  hewei  初始版本创建      
 */
package com.meizu.mshow.common.ip;

/**
 * ip地址数据
 * 
 * @author HEWEI
 * @version 1.0 2011-1-20
 * @since 1.0
 */
public class CityInfo {
	/** 省份 */
	private String province;
	/** 城市 */
	private String city;

	public CityInfo(String province, String city) {
		this.province = province;
		this.city = city;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return getProvince() + " / " + getCity();
	}

	public String getCity() {
		return city;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public void setCity(String city) {
		this.city = city;
	}

}
