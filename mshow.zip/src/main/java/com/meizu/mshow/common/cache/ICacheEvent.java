/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.common.cache<br/>
 * <b>文件名：</b>ICacheEvent.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2013-1-9-上午8:53:52<br/>
 * <b>Copyright (c)</b> 2013魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.common.cache;

import java.util.concurrent.ConcurrentHashMap;

import com.meizu.mshow.common.cache.CacheDefault.CacheObject;

/**
 * <b>类名称：</b>ICacheEvent<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-9 上午8:53:52<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public interface ICacheEvent {

	public <T> T onGet(ConcurrentHashMap<String, ConcurrentHashMap<String, CacheObject>> cache, String category, String key);

	public void onPut(ConcurrentHashMap<String, ConcurrentHashMap<String, CacheObject>> cache, String category, String key, Object obj);

	public void onDel(String category, String key, Object obect);
}
