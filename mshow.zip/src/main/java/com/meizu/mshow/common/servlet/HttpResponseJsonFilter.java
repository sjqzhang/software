package com.meizu.mshow.common.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.meizu.mshow.domain.model.ResultModel;

public class HttpResponseJsonFilter implements Filter {
	public void destroy() {
		// TODO Auto-generated method stub
	}

	@SuppressWarnings("rawtypes")
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		chain.doFilter(request, response);
		Object result = request.getAttribute("resultJSON");
		if (result != null && result instanceof ResultModel) {
			writeJson((ResultModel) result, response);
		} else {
			writeJson(new ResultModel<Object>(result), response);
		}
	}

	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
	}

	@SuppressWarnings("rawtypes")
	private void writeJson(ResultModel result, ServletResponse response) throws IOException {
		response.setContentType("text/html;charset="
				+ response.getCharacterEncoding());
		PrintWriter pw = null;
		try {
			pw = response.getWriter();
			pw.write(result.toJsonString());
			pw.flush();
		} catch (IOException e) {
			
		} finally {
			if (pw != null) {
				pw.close();
			}
		}
	}

}
