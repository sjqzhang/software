package com.meizu.mshow.common.cache;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

import com.meizu.mshow.common.util.DateUtil;

public class O2MapUtil {

	public final static String JSON_TYPE_INTEGER = "java.lang.Integer";

	public final static String JSON_TYPE_DOUBLE = "java.lang.Double";

	public final static String JSON_TYPE_LONG = "java.lang.Long";

	public final static String JSON_TYPE_SHORT = "java.lang.Short";

	public final static String JSON_TYPE_BOOLEAN = "java.lang.Boolean";

	public final static String JSON_TYPE_STRING = "java.lang.String";

	public final static String JSON_TYPE_UTIL_DATE = "java.util.Date";

	public final static String JSON_TYPE_SQL_DATE = "java.sql.Date";

	public final static String JSON_TYPE_INT = "int";

	public final static String JSON_TYPE_DOU = "double";

	public final static String JSON_TYPE_LON = "long";

	public final static String JSON_TYPE_SHO = "short";

	public final static String JSON_TYPE_BOO = "boolean";

	public final static String JSON_TYPE_FLOAT = "java.lang.Float";

	private static final Logger logger = Logger.getLogger(O2MapUtil.class);

	private O2MapUtil() {
	}

	@SuppressWarnings("rawtypes")
	private static Pair<String, String> castValue(Object result, String field,
			Class type) {
		String key = field;
		String value = "";
		Pair<String, String> p2 = new Pair<String, String>(key, value);
		if (result == null) {
			Pair<String, String> p = new Pair<String, String>(field, "");
			return p;
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_DOUBLE)
				|| type.getName().equals(O2MapUtil.JSON_TYPE_DOU)) {
			double tempValue = ((Double) result).doubleValue();
			value = tempValue + "";
			Pair<String, String> p = new Pair<String, String>(field, value);
			return p;
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_SHORT)
				|| type.getName().equals(O2MapUtil.JSON_TYPE_SHO)) {
			short tempValue = ((Short) result).shortValue();
			value = tempValue + "";
			Pair<String, String> p = new Pair<String, String>(field, value);
			return p;
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_INTEGER)
				|| type.getName().equals(O2MapUtil.JSON_TYPE_INT)) {
			int tempValue = ((Integer) result).intValue();
			value = tempValue + "";
			Pair<String, String> p = new Pair<String, String>(field, value);
			return p;
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_LONG)
				|| type.getName().equals(O2MapUtil.JSON_TYPE_LON)) {
			Long tempValue = ((Long) result).longValue();
			value = tempValue + "";
			Pair<String, String> p = new Pair<String, String>(field, value);
			return p;
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_BOO)
				|| type.getName().equals(O2MapUtil.JSON_TYPE_BOOLEAN)) {
			Boolean tempValue = ((Boolean) result).booleanValue();
			value = tempValue + "";
			Pair<String, String> p = new Pair<String, String>(field, value);
			return p;
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_STRING)) {
			String tempValue = ((String) result).toString();
			value = tempValue + "";
			Pair<String, String> p = new Pair<String, String>(field, value);
			return p;
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_SQL_DATE)) {
			java.sql.Date tempDate = (java.sql.Date) result;
			String strTempValue = DateUtil.formatDate2NN(tempDate);
			value = strTempValue + "";
			Pair<String, String> p = new Pair<String, String>(field, value);
			return p;
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_UTIL_DATE)) {
			java.util.Date tempDate = (java.util.Date) result;
			String strTempValue = DateUtil.formatFullDateTime2NN(tempDate);
			value = strTempValue + "";
			Pair<String, String> p = new Pair<String, String>(field, value);
			return p;
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_FLOAT)) {
			float tempValue = ((Float) result).floatValue();
			value = tempValue + "";
			Pair<String, String> p = new Pair<String, String>(field, value);
			return p;
		}
		return p2;
	}

	private static boolean isSupport(Field field) {
		if (field.getType().getName().equals(O2MapUtil.JSON_TYPE_DOUBLE)) {
			return true;
		}
		if (field.getType().getName().equals(O2MapUtil.JSON_TYPE_INTEGER)) {
			return true;
		}
		if (field.getType().getName().equals(O2MapUtil.JSON_TYPE_LONG)) {
			return true;
		}
		if (field.getType().getName().equals(O2MapUtil.JSON_TYPE_SHORT)) {
			return true;
		}
		if (field.getType().getName().equals(O2MapUtil.JSON_TYPE_STRING)) {
			return true;
		}
		if (field.getType().getName().equals(O2MapUtil.JSON_TYPE_INT)) {
			return true;
		}
		if (field.getType().getName().equals(O2MapUtil.JSON_TYPE_DOU)) {
			return true;
		}
		if (field.getType().getName().equals(O2MapUtil.JSON_TYPE_LON)) {
			return true;
		}
		if (field.getType().getName().equals(O2MapUtil.JSON_TYPE_SQL_DATE)) {
			return true;
		}
		if (field.getType().getName().equals(O2MapUtil.JSON_TYPE_UTIL_DATE)) {
			return true;
		}
		if (field.getType().getName().equals(O2MapUtil.JSON_TYPE_SHO)) {
			return true;
		}
		if (field.getType().getName().equals(O2MapUtil.JSON_TYPE_BOO)) {
			return true;
		}
		if (field.getType().getName().equals(O2MapUtil.JSON_TYPE_BOOLEAN)) {
			return true;
		}
		if (field.getType().getName().equals(O2MapUtil.JSON_TYPE_FLOAT)) {
			return true;
		}
		return false;
	}

	@SuppressWarnings("rawtypes")
	private static void parseObject(Field[] fields, List<String> methods,
			List<Class> type, List<String> field) throws ClassNotFoundException {

		for (int i = 0; i < fields.length; i++) {
			fields[i].setAccessible(true);
			if (Modifier.isStatic(fields[i].getModifiers())) {
				continue;
			}
			if (isSupport(fields[i])) {
				if (fields[i].getType().getName()
						.equals(O2MapUtil.JSON_TYPE_BOO)) {
					methods.add("is"
							+ Character.toUpperCase(fields[i].getName().charAt(
									0)) + fields[i].getName().substring(1));
				} else if (fields[i].getType().getName()
						.equals(O2MapUtil.JSON_TYPE_BOOLEAN)) {
					methods.add("is"
							+ Character.toUpperCase(fields[i].getName().charAt(
									0)) + fields[i].getName().substring(1));
				} else {
					methods.add("get"
							+ Character.toUpperCase(fields[i].getName().charAt(
									0)) + fields[i].getName().substring(1));
				}
				type.add(fields[i].getType());
				field.add(fields[i].getName());
			}
		}
	}

	@SuppressWarnings({ "rawtypes", "unused", "unchecked" })
	public static List<Pair<String, HashMap<String, String>>> buildMapList(
			List list, Class clazz, String keyField) {
		if (list == null || list.size() == 0)
			return null;
		try {
			Class c = clazz;
			Field[] fields = c.getDeclaredFields();
			List<String> methods = new ArrayList<String>();
			List<Class> types = new ArrayList<Class>();
			List<String> strfields = new ArrayList<String>();

			O2MapUtil.parseObject(fields, methods, types, strfields);
			StringBuffer strJson = new StringBuffer();
			String strMethod = null;
			String field = null;
			Class[] type = null;
			Method method = null;
			Object result = null;
			List<Pair<String, HashMap<String, String>>> retList = new LinkedList<Pair<String, HashMap<String, String>>>();
			int k = 0;
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				k++;
				Object object = iter.next();
				String key = "";
				HashMap<String, String> objMap = new HashMap<String, String>();
				for (int i = 0; i < methods.size(); i++) {
					strMethod = (String) methods.get(i);
					field = strfields.get(i);

					type = new Class[] { (Class) types.get(i) };
					try {
						method = c.getMethod(strMethod);
						if (method != null) {
							result = method.invoke(object);
							Pair<String, String> p = O2MapUtil.castValue(
									result, field, type[0]);
							if (field.equals(keyField)) {
								key = p.getValue();
							}
							objMap.put(p.getKey(), p.getValue());
						}
					} catch (Exception e) {
						logger.error(e.getCause(), e);
					} finally {
						method = null;
						result = null;
					}

				}
				Pair<String, HashMap<String, String>> objPair = new Pair<String, HashMap<String, String>>(
						key, objMap);
				retList.add(objPair);
			}
			return retList;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return null;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static HashMap<String, String> buildMap(Object object, Class clazz) {
		if (object == null)
			return null;
		try {
			Class c = clazz;
			Field[] fields = c.getDeclaredFields();
			List<String> methods = new ArrayList<String>();
			List<Class> types = new ArrayList<Class>();
			List<String> strfields = new ArrayList<String>();

			O2MapUtil.parseObject(fields, methods, types, strfields);
			HashMap<String, String> retMap = new HashMap<String, String>();
			for (int i = 0; i < methods.size(); i++) {
				String strMethod = (String) methods.get(i);
				String field = (String) strfields.get(i);
				Class[] type = new Class[] { (Class) types.get(i) };
				Method method;
				Object result;
				try {
					method = c.getMethod(strMethod);
					if (method != null) {
						result = method.invoke(object);
						Pair<String, String> p = O2MapUtil.castValue(result,
								field, type[0]);
						retMap.put(p.getKey(), p.getValue());
					}
				} catch (Exception e) {
					logger.error(e.getCause(), e);
				} finally {
					method = null;
					result = null;
				}

			}
			return retMap;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return null;
	}

	@SuppressWarnings("rawtypes")
	private static Object castValue(String v, Class type) {
		if (type.getName().equals(O2MapUtil.JSON_TYPE_DOUBLE)
				|| type.getName().equals(O2MapUtil.JSON_TYPE_DOU)) {
			if (v != null && !v.equals("")) {
				Double d = Double.parseDouble(v);
				return d;
			}
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_SHORT)
				|| type.getName().equals(O2MapUtil.JSON_TYPE_SHO)) {
			if (v != null && !v.equals("")) {
				Short s = Short.parseShort(v);
				return s;
			}
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_INTEGER)
				|| type.getName().equals(O2MapUtil.JSON_TYPE_INT)) {
			if (v != null && !v.equals("")) {
				Integer i = Integer.parseInt(v);
				return i;
			}
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_LONG)
				|| type.getName().equals(O2MapUtil.JSON_TYPE_LON)) {
			if (v != null && !v.equals("")) {
				Long l = Long.parseLong(v);
				return l;
			}
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_BOO)
				|| type.getName().equals(O2MapUtil.JSON_TYPE_BOOLEAN)) {
			if (v != null && !v.equals("")) {
				Boolean b = Boolean.parseBoolean(v);
				return b;
			}
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_STRING)) {
			return v;
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_SQL_DATE)) {
			Date ud = DateUtil.getDate(v);
			java.sql.Date d = new java.sql.Date(ud.getTime());
			return d;
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_UTIL_DATE)) {
			Date d = DateUtil.getDate(v);
			return d;
		}
		if (type.getName().equals(O2MapUtil.JSON_TYPE_FLOAT)) {
			if (v != null && !v.equals("")) {
				Float f = Float.parseFloat(v);
				return f;
			}
		}
		return null;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Object buildObject(HashMap<String, String> value, Class clazz) {
		if (value == null || value.keySet().size() == 0)
			return null;
		try {
			Field[] fields = clazz.getDeclaredFields();
			Object o = clazz.newInstance();
			for (int i = 0; i < fields.length; i++) {
				if (Modifier.isStatic(fields[i].getModifiers())) {
					continue;
				}
				if (!isSupport(fields[i])) {
					continue;
				}
				fields[i].setAccessible(true);
				if (value.containsKey(fields[i].getName())) {
					String methodName = "";
					fields[i].setAccessible(true);
					if (isSupport(fields[i])) {
						methodName = "set"
								+ Character.toUpperCase(fields[i].getName()
										.charAt(0))
								+ fields[i].getName().substring(1);
					}
					Method method = clazz.getMethod(methodName,
							fields[i].getType());
					if (method != null) {
						method.invoke(
								o,
								castValue(value.get(fields[i].getName()),
										fields[i].getType()));
					}
				}
			}
			return o;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return null;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static List buildObjectList(
			List<Pair<String, HashMap<String, String>>> list, Class clazz) {
		if (list == null || list.size() == 0)
			return null;
		try {
			Field[] fields = clazz.getDeclaredFields();
			List retList = new ArrayList();
			for (Iterator<Pair<String, HashMap<String, String>>> iter = list
					.iterator(); iter.hasNext();) {
				Object o = clazz.newInstance();
				Pair<String, HashMap<String, String>> p = iter.next();
				HashMap<String, String> value = p.getValue();
				for (int i = 0; i < fields.length; i++) {
					if (Modifier.isStatic(fields[i].getModifiers())) {
						continue;
					}
					if (!isSupport(fields[i])) {
						continue;
					}
					fields[i].setAccessible(true);
					if (value.containsKey(fields[i].getName())) {
						String methodName = "";
						fields[i].setAccessible(true);
						if (isSupport(fields[i])) {
							methodName = "set"
									+ Character.toUpperCase(fields[i].getName()
											.charAt(0))
									+ fields[i].getName().substring(1);
						}
						try {
							Method method = clazz.getMethod(methodName,
									fields[i].getType());
							if (method != null) {
								method.invoke(
										o,
										castValue(
												value.get(fields[i].getName()),
												fields[i].getType()));
							}
						} catch (Exception e) {
							System.out.println(methodName);
							e.printStackTrace();
						}
					}
				}
				retList.add(o);
			}
			return retList;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return null;
	}

	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	public static void main(String args[]) {
		ArrayList<TestDto> list = new ArrayList();
		System.out.println("init datetime:"
				+ DateUtil.formatFullDateTime2NN(DateUtil.getNow()));
		long startTime = DateUtil.getNow().getTime();
		for (int i = 0; i < 10000; i++) {
			list.add(new TestDto(true, i + "name", (short) i, new Date()));
		}
		System.out.println("build-init datetime:"
				+ DateUtil.formatFullDateTime2NN(DateUtil.getNow()));
		TestDto d = new TestDto(false, "abc", (short) 152, DateUtil.getNow());
		HashMap map = O2MapUtil.buildMap(d, d.getClass());
		TestDto d2 = (TestDto) O2MapUtil.buildObject(map, TestDto.class);
		for (Iterator iter3 = map.keySet().iterator(); iter3.hasNext();) {
			String key = (String) iter3.next();
			System.out.print("  " + key + " : " + map.get(key) + ",");
		}
		System.out.println();
		System.out.println("-------------------------------------------------");
		List<Pair<String, HashMap<String, String>>> testList = O2MapUtil
				.buildMapList(list, TestDto.class, "strTest");
		List list2 = O2MapUtil.buildObjectList(testList, TestDto.class);
		long endTime = DateUtil.getNow().getTime();
		System.out.println("time:" + (endTime - startTime));
		System.out.println("finish datetime:"
				+ DateUtil.formatFullDateTime2NN(DateUtil.getNow()));

		/*
		 * test result: 1000000 23S 100000 2.5S
		 */
	}

}

class TestDto {

	private boolean blnTest;

	private String strTest;

	private Short shtTest;

	private Date dtDate;

	public TestDto() {

	}

	public TestDto(boolean blnTest, String strTest, Short shtTest, Date dtDate) {
		this.blnTest = blnTest;
		this.strTest = strTest;
		this.shtTest = shtTest;
		this.dtDate = dtDate;
	}

	public boolean isBlnTest() {
		return blnTest;
	}

	public void setBlnTest(boolean blnTest) {
		this.blnTest = blnTest;
	}

	public String getStrTest() {
		return strTest;
	}

	public void setStrTest(String strTest) {
		this.strTest = strTest;
	}

	public Short getShtTest() {
		return shtTest;
	}

	public void setShtTest(Short shtTest) {
		this.shtTest = shtTest;
	}

	public Date getDtDate() {
		return dtDate;
	}

	public void setDtDate(Date dtDate) {
		this.dtDate = dtDate;
	}

}
