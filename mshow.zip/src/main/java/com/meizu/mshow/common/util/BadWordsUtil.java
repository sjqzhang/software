package com.meizu.mshow.common.util;

import java.util.List;

import com.meizu.mshow.common.servlet.SystemContextListener;
import com.meizu.mshow.domain.pojo.TSysBadwords;

public class BadWordsUtil {
	public static String replaceBadwords(String content) {
		List<TSysBadwords> list = SystemContextListener.getBadWords();
		String tmpContent = content;
		if (list != null) {
			for (TSysBadwords badwords : list) {
				tmpContent = tmpContent.replaceAll(badwords.getFind(), badwords.getReplacement());
			}
		}
		return tmpContent;
	}

	public static boolean containBadWords(String content) {
		if (content == null || content.trim().length() == 0) {
			return false;
		}
		List<TSysBadwords> list = SystemContextListener.getBadWords();
		if (list != null) {
			for (TSysBadwords badwords : list) {
				if (content.indexOf(badwords.getFind()) >= 0) {
					return true;
				}
			}
		}
		return false;
	}

	public static void reloadBadWords() {
		SystemContextListener.loadBadWords();
	}
}