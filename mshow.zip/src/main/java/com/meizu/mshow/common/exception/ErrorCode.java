package com.meizu.mshow.common.exception;

public interface ErrorCode {

	int SUCCESS = 0;

	int UNKNOW_ERROR = 1;

	int LOG_STEP = 10000;

	// both log and message
	int ELOG = 1 * LOG_STEP;

	// 按模块分CODE,一个模块分10000个code
	int MODULE_STEP = 1000;

	// 系统
	int SYS = 1 * MODULE_STEP;

	int SECURITY_FAIL = ELOG + SYS + 1;

	int FILE_WRITE_ERROR = ELOG + SYS + 2;

	int SECURITY_ILLEGALCHAR = ELOG + SYS + 3;

	// 用户
	int USR = 2 * MODULE_STEP;
	// 未登录
	int INVALID_LOGIN = ELOG + USR + 1;
	// 用户不存在
	int USER_NOT_EXIST = ELOG + USR + 2;
	// 昵称不能超过45个字符
	int USER_ALIASNAME_TOOLONG = ELOG + USR + 3;
	// 昵称被占用
	int USER_ALIASNAME_HASTAKEN = ELOG + USR + 4;
	// 禁言
	int USER_SECURIY_NOCOMMENT = ELOG + USR + 5;
	// 禁上传
	int USER_SECURIY_NOPOST = ELOG + USR + 6;
	// 禁用
	int USER_SECURIY_INACTIVE = ELOG + USR + 7;
	// 禁用
	int USER_MESSAGE_ILLEAGAL = ELOG + USR + 8;

	// 图片 12001
	int IMG = 3 * MODULE_STEP;
	// 已赞
	int PICTURE_HAS_LIKED = ELOG + IMG + 1;
	// 照片不存在
	int PICTURE_NOT_EXIST = ELOG + IMG + 2;
	// 照片已投诉
	int PICTURE_HAS_COMPLAINED = ELOG + IMG + 3;
	// 评论内容过长
	int PICTURE_COMMENT_TOOLONG = ELOG + IMG + 4;
	// 重复评论
	int PICTURE_COMMENT_REPEAT = ELOG + IMG + 5;
	// 自己赞自己的
	int PICTURE_SELF_LIKE = ELOG + IMG + 6;
	// 描述太长
	int PICTURE_DESC_TOOLONG = ELOG + IMG + 7;
	// 描述太长
	int PICTURE_COMMENT_EMPTY = ELOG + IMG + 8;
	// 限制赞的频率
	int PICTURE_LIKE_REPEAT = ELOG + IMG + 9;
	// 文件压缩失败
	int PICTURE_COMPRESS_FAIL = ELOG + IMG + 10;

	// 标签 12001
	int TAG = 4 * MODULE_STEP;
	// 标签非法
	int TAG_NAME_LLEGAL = ELOG + TAG + 1;
	// 标签最多6个
	int TAG_MAX_SIZE = ELOG + TAG + 2;

	// 文件上传
	int UPLOAD = 5 * MODULE_STEP;
	// 参数错误
	int UPLOAD_PARAMETER_ERROR = ELOG + UPLOAD + 1;
	// 服务器内部错误
	int UPLOAD_SERVER_ERROR = ELOG + UPLOAD + 2;
}
