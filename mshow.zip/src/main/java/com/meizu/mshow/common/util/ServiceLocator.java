package com.meizu.mshow.common.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;

import com.meizu.mshow.common.cache.CacheRouter;
import com.meizu.mshow.common.resource.MessageSource;
import com.meizu.mshow.picture.business.PictureService;
import com.meizu.mshow.picture.business.TimerService;
import com.meizu.mshow.picture.cache.CacheService;
import com.meizu.mshow.picture.dao.PictureDAO;
import com.meizu.mshow.system.dao.SystemDAO;
import com.meizu.mshow.user.business.UserService;
import com.meizu.mshow.user.dao.MessageDAO;
import com.meizu.mshow.user.dao.UserDAO;

public final class ServiceLocator {

	private static ServiceLocator instance = new ServiceLocator();
	private static Log log = LogFactory.getLog(ServiceLocator.class.getName());
	private ApplicationContext context = null;

	private ApplicationContext getContext() {
		return context;
	}

	/**
	 * 设置这个 sping 的 beanFactory 实例
	 * 
	 * @param context
	 */
	public void setContext(ApplicationContext context) {
		this.context = context;
	}

	/**
	 * 得到ServiceLocator类的实例
	 * 
	 * @return ServiceLocator类的实例
	 */
	public static ServiceLocator getInstance() {
		return instance;
	}

	public static <T> T getService(final String service) {
		Object obj = instance.context.getBean(service);
		return (T) obj;
	}

	public static <T> T getService(Class<T> clz) {
		return instance.context.getBean(clz);
	}

	private ServiceLocator() {

	}

	public static MessageSource getMessageSource() {
		return (MessageSource) ServiceLocator.getInstance().getService("messageSource");
	}

	public static CacheRouter getCacheRouter() {
		return (CacheRouter) ServiceLocator.getInstance().getService("cacheRouter");
	}

	public static UserService getUserService() {
		return (UserService) ServiceLocator.getInstance().getService("userService");
	}

	public static PictureDAO getPictureDAO() {
		return (PictureDAO) ServiceLocator.getInstance().getService("pictureDAO");
	}

	public static UserDAO getUserDAO() {
		return (UserDAO) ServiceLocator.getInstance().getService("userDAO");
	}

	public static PictureService getPictureService() {
		return (PictureService) ServiceLocator.getInstance().getService("pictureService");
	}

	public static CacheService getCacheService() {
		return (CacheService) ServiceLocator.getInstance().getService("cacheService");
	}

	public static TimerService getTimerService() {
		return (TimerService) ServiceLocator.getInstance().getService("timerService");
	}

	public static MessageDAO getMessageDAO() {
		return (MessageDAO) ServiceLocator.getInstance().getService("messageDAO");
	}

	public static SystemDAO getSystemDAO() {
		return (SystemDAO) ServiceLocator.getInstance().getService("systemDAO");
	}
}
