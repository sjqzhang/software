package com.meizu.mshow.common.exception;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.Serializable;

public class ApplicationException extends RuntimeException implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -560581110872734762L;

	private boolean logged=true;

	private int errorCode;

	private String[] messageParams;

	private String sendRedirectURL;

	public String getSendRedirectURL() {
		return sendRedirectURL;
	}

	public String[] getMessageParams() {
		return messageParams;
	}

	public void setMessageParams( String[] messageParams ) {
		this.messageParams = messageParams;
	}

	public void setSendRedirectURL( String sendRedirectURL ) {
		this.sendRedirectURL = sendRedirectURL;
	}

	public void setErrorCode( int errorCode ) {
		this.errorCode = errorCode;
	}

	public ApplicationException( int errorCode ) {
		super();
		this.errorCode = errorCode;
	}

	public ApplicationException( int errorCode, String[] messageParams ) {
		super();
		this.errorCode = errorCode;
		this.messageParams = messageParams;
	}

	public ApplicationException( int errorCode, String[] messageParams, Throwable cause ) {
		super( cause );
		this.errorCode = errorCode;
		this.messageParams = messageParams;
	}

	public ApplicationException( int errorCode, String[] messageParams, boolean logged ) {
		this.logged = logged;
		this.errorCode = errorCode;
		this.messageParams = messageParams;
	}

	public ApplicationException( int errorCode, String[] messageParams, String sendRedirectURL ) {
		this.sendRedirectURL = sendRedirectURL;
		this.errorCode = errorCode;
		this.messageParams = messageParams;
	}

	public ApplicationException( int errorCode, String[] messageParams, Throwable cause, boolean logged ) {
		super( cause );
		this.errorCode = errorCode;
		this.messageParams = messageParams;
		this.logged = logged;
	}

	public ApplicationException( int errorCode, String[] messageParams, Throwable cause, String sendRedirectURL ) {
		super( cause );
		this.errorCode = errorCode;
		this.messageParams = messageParams;
		this.sendRedirectURL = sendRedirectURL;
	}

	public ApplicationException( int errorCode, String[] messageParams, Throwable cause, boolean logged, String sendRedirectURL ) {
		super( cause );
		this.logged = logged;
		this.errorCode = errorCode;
		this.messageParams = messageParams;
		this.sendRedirectURL = sendRedirectURL;
	}

	public boolean isLogged() {
		return this.logged;
	}

	public void setLogged( boolean logged ) {
		this.logged = logged;
	}

	public int getErrorCode() {
		return this.errorCode;
	}

	public void printStackTrace() {
		super.printStackTrace();
	}

	public void printStackTrace( PrintStream s ) {
		super.printStackTrace( s );
	}

	public void printStackTrace( PrintWriter s ) {
		super.printStackTrace( s );
	}
}
