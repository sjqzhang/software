package com.meizu.mshow.common.ip;

/**  
 * <pre>  
 * 一条IP范围记录，不仅包括国家和区域，也包括起始IP和结束IP  
 * </pre>  
 */  
public class IPEntry {   
    private String beginIp;   
    private String endIp;   
    private String country;   
    private String area;   
       
    /**  
     * 构造函数  
     */  
    public IPEntry() {   
        beginIp = "";
        endIp = "";
        country = "";
        area = "";   
    }

	public String getBeginIp() {
		return beginIp;
	}

	public void setBeginIp(String beginIp) {
		this.beginIp = beginIp;
	}

	public String getEndIp() {
		return endIp;
	}

	public void setEndIp(String endIp) {
		this.endIp = endIp;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}   
}  