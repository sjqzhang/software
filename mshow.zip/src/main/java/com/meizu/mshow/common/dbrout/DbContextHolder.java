package com.meizu.mshow.common.dbrout;

public class DbContextHolder {

	public static final String ORDER_DATASOURCE="orderDataSource";
	public static final String USER_DATASOURCE="userDataSource";
	private static final ThreadLocal contextHolder = new ThreadLocal();

	public static void setDbType( String dbType ) {
		contextHolder.set( dbType );
	}

	public static String getDbType() {
		return ( ( String )contextHolder.get() );
	}

	public static void clearDbType() {
		contextHolder.remove();
	}
}