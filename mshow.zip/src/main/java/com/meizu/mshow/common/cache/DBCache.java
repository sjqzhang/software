/**

 * <b>项目名：</b>spring3.1<br/>
 * <b>包名：</b>com.spring.study<br/>
 * <b>文件名：</b>Cache.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2013-1-6-上午11:05:04<br/>
 * <b>Copyright (c)</b> 2013魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.common.cache;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <b>类名称：</b>Cache<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-6 上午11:05:04<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */
@Target({ ElementType.METHOD, ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface DBCache {

	String key() default "";

	String keyPrefix() default "";

	int ttl() default -1;

	CacheCategory category() default CacheCategory.Defalut;

	DBCacheOperation op() default DBCacheOperation.SELECT;

}
