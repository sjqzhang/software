package com.meizu.mshow.common.util;

public class CacheKeyUtil {

	public static final String P_PICTURE = "p_";

	public static final String P_USER = "u_";

	public static final String S_USER = "su_";

	public static final String S_SESSION = "ss_";

	public static final String P_PLAZAHOT = "ph_";

	public static final String P_PLAZANEW = "pn_";

	public static final String P_HOT_TAG = "ht_";

	public static final String P_TAG_IMG = "ti_";

	public static final String P_IMG_TAG = "ig_";

	public static final String P_COMMENT = "c_";

	public static final String P_COMMENTLIST = "cl_";

	public static final String P_MESSAGE = "pm_";

	public static final String P_MESSAGE_COUNT = "pmg_";

	public static final String P_SEARCH = "s_";

	public static final String P_SEARCHTAG = "pts_";

	public static final String P_SEARCHUSER = "ptu_";

	public static final String P_USERMARK = "um_";

	public static final String P_USERPOST = "up_";

	public static final String P_USERLIKE = "ul_";

	public static final String P_CITY = "pc_";

	public static final String P_REPEAT_COMMENT = "rc_";

	public static final String P_REPEAT_LIKE = "rl_";

	public static final String P_LOCATION = "l_";

	public static final String P_TAGNAME = "tn_";

	public static final String P_PINEDTAG = "upt_";

	public static final String F_USER = "fu_";

	public static final String MESSAGE = "m_";

	public static final String MESSAGE_COUNT = "mc_";

	public static final String MESSAGE_BOX = "mb_";

	public static final String MESSAGE_ID = "message_id";

	public static final String USERMARK_ID = "usermark_id";

	public static final String USERMARK = "um_";

	public static final String USERMARK_SET = "ums_";

	public static final String USERFOLLOW_SET = "ufs_";

	public static final String USERFOLLOW = "uf_";

	public static final String COMPRESSION = "pc_";

	// 压缩队列
	public static String getCompressionKey() {
		return COMPRESSION + "1";
	}

	public static String getUserMarkIdKey() {
		return USERMARK_ID;
	}

	public static String getUserFollowSetKey(Long userId) {
		return USERFOLLOW_SET + userId;
	}

	// sourceUserId follow destUserId
	public static String getUserFollowKey(Long sourceUserId, Long destUserId) {
		return USERFOLLOW + sourceUserId + "_" + destUserId;
	}

	// sourceUserId mark destUserId
	public static String getUserMarkKey(Long sourceUserId, Long destUserId) {
		return USERMARK + sourceUserId + "_" + destUserId;
	}

	public static String getUserMarkSetKey(Long userId) {
		return USERMARK_SET + userId;
	}

	public static String getUserMessageCountKey(Long userId) {
		return MESSAGE_COUNT + userId.longValue();
	}

	public static String getMessageKey(Long messageId) {
		return MESSAGE + messageId.longValue();
	}

	public static String getUserMessageBoxKey(Long userId) {
		return MESSAGE_BOX + userId.longValue();
	}

	public static String getMessageIdKey() {
		return MESSAGE_ID;
	}

	public static String getUserLikeKey(Long imgId, Long userId) {
		return P_USERLIKE + imgId + "_" + userId + "$";
	}

	public static String getSessionUserKey(Long userId) {
		return S_USER + userId;
	}

	public static String getSessionKey(String sessionId) {
		return S_SESSION + sessionId;
	}

	public static String getPictureKey(Long imgId) {
		return P_PICTURE + imgId;
	}

	public static String getUserKey(Long userId) {
		return P_USER + userId;
	}

	public static String getPlazaHotKey() {
		return P_PLAZAHOT;
	}

	public static String getPlazaNewKey() {
		return P_PLAZANEW;
	}

	public static String getHotTagKey() {
		return P_HOT_TAG;
	}

	public static String getTagSetKey(Long tagId) {
		return P_TAG_IMG + tagId;
	}

	public static String getRepeatLikeKey(Long userId, Long imgId) {
		return P_REPEAT_LIKE + userId + "_" + imgId;
	}

	public static String getRepeatCommentKey(String commentMD5) {
		return P_REPEAT_COMMENT + commentMD5;
	}
}
