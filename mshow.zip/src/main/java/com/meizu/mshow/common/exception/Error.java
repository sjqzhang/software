package com.meizu.mshow.common.exception;


public class Error implements ErrorCode{

}
