package com.meizu.mshow.common.cache;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;

public class CacheRedis implements ICache {

	private static final Logger logger = Logger.getLogger(RedisUtil.class);

	@Override
	public <T> T get(CacheCategory category, String key, Class<T> classType) {

		try {
			RedisUtil ru = new RedisUtil();
			String value = ru.getString(key);
			if (value != null && !value.equals("") && !value.equals(DBCacheInterceptor.NULL_VALUE)) {
				T retObj = (T) JSON.parse(value);
				return retObj;
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return null;

	}

	@SuppressWarnings("rawtypes")
	@Override
	public void put(CacheCategory category, String key, Object obj, int ttl) {
		if (!isDebug()) {
			try {
				HashMap<String, Object> map = new HashMap<String, Object>();
				if (obj != null) {
					RedisUtil ru = new RedisUtil();
					ru.setString(key, JSONObject.toJSONString(obj, SerializerFeature.WriteClassName), ttl);
				}
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	@Override
	public void remove(CacheCategory category, String key) {
		RedisUtil ru = new RedisUtil();
		ru.expire(key, 0);

	}

	@Override
	public void flush(CacheCategory categroy) {
		// TODO Auto-generated method stub

	}

	@Override
	public void flushAll() {
		// TODO Auto-generated method stub

	}

	@Override
	public void addEventLister(ICacheEvent event) {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.meizu.mshow.common.cache.ICache#isDebug()
	 */

	@Override
	public boolean isDebug() {
		// TODO Auto-generated method stub
		return false;
	}

}
