/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.domain.pojo<br/>
 * <b>文件名：</b>UploadFileInfo.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2012-12-4-上午9:25:27<br/>
 * <b>Copyright (c)</b> 2012魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.domain.pojo;

/**
 * <b>类名称：</b>UploadFileInfo<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 * 
 * 文件上传的元数据
 * </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-4 上午9:25:27<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public class UploadFileInfo {

	/**
	 * 文件ＩＤ
	 */
	long fileId;
	/**
	 * 文件名称
	 */
	String fileName;
	/**
	 * 文件大小
	 */
	long fileSize;
	/**
	 * 文件创建日期（存时间截）
	 */
	long cdate;
	/**
	 * 文件路径（不存前缀）
	 */
	String filePath;
	/**
	 * 文件类型
	 */
	String fileType;

	public long getFileId() {
		return fileId;
	}

	public void setFileId(long fileId) {
		this.fileId = fileId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public long getFileSize() {
		return fileSize;
	}

	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	public long getCdate() {
		return cdate;
	}

	public void setCdate(long cdate) {
		this.cdate = cdate;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

}
