package com.meizu.mshow.domain.pojo;

public class TImgTag {

	private Long tagId;

	private Long userId;

	private String tagName;

	private Long cdate;

	private Long imgId;

	private Integer status;

	private String tagCover;

	private Integer imgCount;

	public Integer getImgCount() {
		return imgCount;
	}

	public void setImgCount(Integer imgCount) {
		this.imgCount = imgCount;
	}

	public String getTagCover() {
		return tagCover;
	}

	public void setTagCover(String tagCover) {
		this.tagCover = tagCover;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Long getTagId() {
		return tagId;
	}

	public void setTagId(Long tagId) {
		this.tagId = tagId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	public Long getCdate() {
		return cdate;
	}

	public void setCdate(Long cdate) {
		this.cdate = cdate;
	}

	public Long getImgId() {
		return imgId;
	}

	public void setImgId(Long imgId) {
		this.imgId = imgId;
	}

}
