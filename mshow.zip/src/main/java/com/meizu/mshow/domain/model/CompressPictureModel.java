package com.meizu.mshow.domain.model;

import com.meizu.mshow.domain.pojo.TImgPicture;

public class CompressPictureModel {

	private TImgPicture picture;

	private String datePath;

	private String fileName;

	public TImgPicture getPicture() {
		return picture;
	}

	public void setPicture(TImgPicture picture) {
		this.picture = picture;
	}

	public String getDatePath() {
		return datePath;
	}

	public void setDatePath(String datePath) {
		this.datePath = datePath;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}