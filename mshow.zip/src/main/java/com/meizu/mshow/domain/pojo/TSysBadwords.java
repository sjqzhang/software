package com.meizu.mshow.domain.pojo;

public class TSysBadwords {
	private int id;
	private String admin;
	private String find;
	private String replacement;
	private String findpattern;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAdmin() {
		return admin;
	}

	public void setAdmin(String admin) {
		this.admin = admin;
	}

	public String getFind() {
		return find;
	}

	public void setFind(String find) {
		this.find = find;
	}

	public String getReplacement() {
		return replacement;
	}

	public void setReplacement(String replacement) {
		this.replacement = replacement;
	}

	public String getFindpattern() {
		return findpattern;
	}

	public void setFindpattern(String findpattern) {
		this.findpattern = findpattern;
	}

}