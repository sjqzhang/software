package com.meizu.mshow.domain.pojo;

public class TImgActivity {

	private Long activityId;
	private Long tagId;
	private String tagName;
	private String tagCover;
	private String largeCover;
	private Integer largeWidth;
	private Integer largeHeight;
	private String minCover;
	private Integer minWidth;
	private Integer minHeight;
	private String desc;
	private Integer imgCount;
	private Integer commentCount;
	private Integer userCount;
	private Integer startTime;
	private Integer endTime;
	private Integer status;
	private Integer cdate;
	private Long userId;
	private String userName;

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	public String getTagCover() {
		return tagCover;
	}

	public void setTagCover(String tagCover) {
		this.tagCover = tagCover;
	}

	public Long getActivityId() {
		return activityId;
	}

	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}

	public Long getTagId() {
		return tagId;
	}

	public void setTagId(Long tagId) {
		this.tagId = tagId;
	}

	public String getLargeCover() {
		return largeCover;
	}

	public void setLargeCover(String largeCover) {
		this.largeCover = largeCover;
	}

	public Integer getLargeWidth() {
		return largeWidth;
	}

	public void setLargeWidth(Integer largeWidth) {
		this.largeWidth = largeWidth;
	}

	public Integer getLargeHeight() {
		return largeHeight;
	}

	public void setLargeHeight(Integer largeHeight) {
		this.largeHeight = largeHeight;
	}

	public String getMinCover() {
		return minCover;
	}

	public void setMinCover(String minCover) {
		this.minCover = minCover;
	}

	public Integer getMinWidth() {
		return minWidth;
	}

	public void setMinWidth(Integer minWidth) {
		this.minWidth = minWidth;
	}

	public Integer getMinHeight() {
		return minHeight;
	}

	public void setMinHeight(Integer minHeight) {
		this.minHeight = minHeight;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Integer getImgCount() {
		return imgCount;
	}

	public void setImgCount(Integer imgCount) {
		this.imgCount = imgCount;
	}

	public Integer getCommentCount() {
		return commentCount;
	}

	public void setCommentCount(Integer commentCount) {
		this.commentCount = commentCount;
	}

	public Integer getUserCount() {
		return userCount;
	}

	public void setUserCount(Integer userCount) {
		this.userCount = userCount;
	}

	public Integer getStartTime() {
		return startTime;
	}

	public void setStartTime(Integer startTime) {
		this.startTime = startTime;
	}

	public Integer getEndTime() {
		return endTime;
	}

	public void setEndTime(Integer endTime) {
		this.endTime = endTime;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getCdate() {
		return cdate;
	}

	public void setCdate(Integer cdate) {
		this.cdate = cdate;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}