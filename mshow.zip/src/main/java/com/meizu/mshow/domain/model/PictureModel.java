package com.meizu.mshow.domain.model;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSONObject;
import com.meizu.mshow.domain.pojo.TImgComment;
import com.meizu.mshow.domain.pojo.TImgPicture;
import com.meizu.mshow.domain.pojo.TImgTag;
import com.meizu.mshow.domain.pojo.TSysUser;

public class PictureModel {

	private TImgPicture picture;

	private TSysUser user;

	private List<TImgComment> comments;

	private List<TImgTag> tags;

	public TImgPicture getPicture() {
		return picture;
	}

	public void setPicture( TImgPicture picture ) {
		this.picture = picture;
	}

	public TSysUser getUser() {
		return user;
	}

	public void setUser( TSysUser user ) {
		this.user = user;
	}

	public List<TImgComment> getComments() {
		return comments;
	}

	public void setComments( List<TImgComment> comments ) {
		this.comments = comments;
	}

	public List<TImgTag> getTags() {
		return tags;
	}

	public void setTags( List<TImgTag> tags ) {
		this.tags = tags;
	}

	public static void main( String args[] ) {
		PictureModel p = new PictureModel();
		TSysUser u = new TSysUser();
		u.setEmail( "x@X.COM" );
		u.setComment( "abccefasdfa" );
		p.setUser( u );
		List list = new ArrayList();
		TImgComment c = new TImgComment();
		c.setContinent( "sweet heart" );
		list.add( c );
		p.setComments( list );

		String json = JSONObject.toJSONString( p );
		System.out.println( json );
		PictureModel p1 = JSONObject.parseObject( json, PictureModel.class );
		System.out.println( p1.getUser().getEmail() + " and comment size is " + p1.getComments().size() );
	}
}