package com.meizu.mshow.domain.model;

public class TimerModel {
	private Long imgId;
	private Integer commentCount;
	private Integer likeCount;
	private Integer viewCount;
	private Double hotScore;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((commentCount == null) ? 0 : commentCount.hashCode());
		result = prime * result + ((hotScore == null) ? 0 : hotScore.hashCode());
		result = prime * result + ((imgId == null) ? 0 : imgId.hashCode());
		result = prime * result + ((likeCount == null) ? 0 : likeCount.hashCode());
		result = prime * result + ((viewCount == null) ? 0 : viewCount.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TimerModel other = (TimerModel) obj;
		if (imgId == null) {
			if (other.imgId != null)
				return false;
		} else if (!imgId.equals(other.imgId))
			return false;
		return true;
	}

	public Long getImgId() {
		return imgId;
	}

	public void setImgId(Long imgId) {
		this.imgId = imgId;
	}

	public Integer getCommentCount() {
		return commentCount;
	}

	public void setCommentCount(Integer commentCount) {
		this.commentCount = commentCount;
	}

	public Integer getLikeCount() {
		return likeCount;
	}

	public void setLikeCount(Integer likeCount) {
		this.likeCount = likeCount;
	}

	public Integer getViewCount() {
		return viewCount;
	}

	public void setViewCount(Integer viewCount) {
		this.viewCount = viewCount;
	}

	public Double getHotScore() {
		return hotScore;
	}

	public void setHotScore(Double hotScore) {
		this.hotScore = hotScore;
	}

}
