package com.meizu.mshow.domain.model;

import java.io.Serializable;
import java.util.Date;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializeConfig;
import com.alibaba.fastjson.serializer.SimpleDateFormatSerializer;
import com.meizu.mshow.common.exception.ErrorCode;

public class ResultModel<T> implements Serializable {
	private static final long serialVersionUID = 8482909105020394870L;
    private int               returnCode       = ErrorCode.SUCCESS;
    private String            returnMessage;
    private String            returnErrorStackTrace;
    private String            returnUrl;
    private T                 returnValue;
    
    // 定制化mapping
    private static SerializeConfig mapping = new SerializeConfig();
    static {
        mapping.put(Date.class, new SimpleDateFormatSerializer("yyyy-MM-dd HH:mm:ss"));
    }
    /**
     * @return the returnUrl
     */
    public String getReturnUrl() {
        return returnUrl;
    }
    /**
     * @param returnUrl the returnUrl to set
     */
    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
    }
    /**
     * @return the returnErrorStackTrace
     */
    public String getReturnErrorStackTrace() {
        return returnErrorStackTrace;
    }
    /**
     * @param returnErrorStackTrace the returnErrorStackTrace to set
     */
    public void setReturnErrorStackTrace(String returnErrorStackTrace) {
        this.returnErrorStackTrace = returnErrorStackTrace;
    }
    public ResultModel() {
    }
    public ResultModel(int returnCode, String returnMessage, String returnUrl) {
        this.returnCode = returnCode;
        this.returnMessage = returnMessage;
        this.returnUrl = returnUrl;
    }
    public ResultModel(int returnCode, String returnMessage) {
        this.returnCode = returnCode;
        this.returnMessage = returnMessage;
    }
    public ResultModel(T returnValue) {
        this.returnValue = returnValue;
    }
    public ResultModel(T returnValue, int returnCode, String returnMessage) {
        this.returnValue = returnValue;
        this.setReturnCode(returnCode);
        this.setReturnMessage(returnMessage);
    }
    public ResultModel(T returnValue, int returnCode, String returnMessage, String returnUrl) {
        this.returnValue = returnValue;
        this.setReturnCode(returnCode);
        this.setReturnMessage(returnMessage);
        this.setReturnUrl(returnUrl);
    }
    /**
     * @return the returnValue
     */
    public T getReturnValue() {
        return returnValue;
    }
    /**
     * @param returnValue the returnValue to set
     */
    public void setReturnValue(T returnValue) {
        this.returnValue = returnValue;
    }
//    public String toString() {
//        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
//    }
    public String toJsonString() {
        return JSONObject.toJSONString(this, mapping);
    }
    /**
     * @return the isSuccessed
     */
    public boolean isSuccessed() {
        if (this.returnCode == ErrorCode.SUCCESS) {
            return true;
        } else {
            return false;
        }
    }
    /**
     * @return the returnMsg
     */
    public String getReturnMessage() {
        return returnMessage;
    }
    /**
     * @param returnMsg the returnMsg to set
     */
    
    public void setReturnMessage(String returnMessage) {
        this.returnMessage = returnMessage;
    }
    /**
     * @return the returnCode
     */
    public int getReturnCode() {
        return returnCode;
    }
    /**
     * @param returnCode the returnCode to set
     */
    public void setReturnCode(int returnCode) {
        this.returnCode = returnCode;
    }
}
