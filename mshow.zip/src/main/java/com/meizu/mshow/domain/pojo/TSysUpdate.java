/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.domain.pojo<br/>
 * <b>文件名：</b>TSysUpdate.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2013-1-5-上午10:01:17<br/>
 * <b>Copyright (c)</b> 2013魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.domain.pojo;

/**
 * <b>类名称：</b>TSysUpdate<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-5 上午10:01:17<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public class TSysUpdate {
	private Integer id;
	private String desc;
	private String srcVersion;
	private String desVersion;
	private java.util.Date cdate;
	private Integer updateType;
	private String url;

	// public void setId(Integer id) {
	// this.id = id;
	// }
	//
	// public Integer getId() {
	// return this.id;
	// }

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getDesc() {
		return this.desc;
	}

	public void setSrcVersion(String srcVersion) {
		this.srcVersion = srcVersion;
	}

	public String getSrcVersion() {
		return this.srcVersion;
	}

	public void setDesVersion(String desVersion) {
		this.desVersion = desVersion;
	}

	public String getDesVersion() {
		return this.desVersion;
	}

	public void setCdate(java.util.Date cdate) {
		this.cdate = cdate;
	}

	public java.util.Date getCdate() {
		return this.cdate;
	}

	public void setUpdateType(Integer updateType) {
		this.updateType = updateType;
	}

	public Integer getUpdateType() {
		return this.updateType;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUrl() {
		return this.url;
	}
}
