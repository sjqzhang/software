package com.meizu.mshow.domain.model;

import java.util.List;

import com.meizu.mshow.domain.pojo.TSysUser;

public class UserModel {
	private TSysUser user;

	private List unitUser;

	public TSysUser getUser() {
		return user;
	}

	public void setUser(TSysUser user) {
		this.user = user;
	}

	public List getUnitUser() {
		return unitUser;
	}

	public void setUnitUser(List unitUser) {
		this.unitUser = unitUser;
	}

}