package com.meizu.mshow.domain.model;

public class UserMarkModel implements Comparable<UserMarkModel> {
	private Long markId;

	private Long userId;

	private Long destUserId;

	private String headIcon;

	private String aliasName;

	private Integer cdate;

	private Integer category;

	private Long imgId;

	public Long getMarkId() {
		return markId;
	}

	public void setMarkId(Long markId) {
		this.markId = markId;
	}

	public Long getImgId() {
		return imgId;
	}

	public void setImgId(Long imgId) {
		this.imgId = imgId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getDestUserId() {
		return destUserId;
	}

	public void setDestUserId(Long destUserId) {
		this.destUserId = destUserId;
	}

	public String getHeadIcon() {
		return headIcon;
	}

	public void setHeadIcon(String headIcon) {
		this.headIcon = headIcon;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public Integer getCdate() {
		return cdate;
	}

	public void setCdate(Integer cdate) {
		this.cdate = cdate;
	}

	public Integer getCategory() {
		return category;
	}

	public void setCategory(Integer category) {
		this.category = category;
	}

	@Override
	public int compareTo(UserMarkModel o) {
		return this.cdate - o.cdate;
	}
}
