/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.domain.pojo<br/>
 * <b>文件名：</b>UploadSetting.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2012-12-4-上午11:01:14<br/>
 * <b>Copyright (c)</b> 2012魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.domain.pojo;

/**
 * <b>类名称：</b>UploadSetting<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-4 上午11:01:14<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public class UploadSetting {

	/**
	 * 文件分类
	 */
	String fileClass;
	/**
	 * 文件路径
	 */
	String filePath;

	/**
	 * 文件目录
	 */
	String fileDir;
	/**
	 * 当前文件数
	 */
	int fileCount;
	/**
	 * 最大文件数
	 */
	int fileMax;
	/**
	 * 当前是否可用
	 */
	int isActive;

	public String getFileClass() {
		return fileClass;
	}

	public void setFileClass(String fileClass) {
		this.fileClass = fileClass;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getFileDir() {
		return fileDir;
	}

	public void setFileDir(String fileDir) {
		this.fileDir = fileDir;
	}

	public int getFileCount() {
		return fileCount;
	}

	public void setFileCount(int fileCount) {
		this.fileCount = fileCount;
	}

	public int getFileMax() {
		return fileMax;
	}

	public void setFileMax(int fileMax) {
		this.fileMax = fileMax;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

}
