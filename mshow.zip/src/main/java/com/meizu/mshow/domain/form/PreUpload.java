/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.domain.form<br/>
 * <b>文件名：</b>PreUpload.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2013-1-14-下午3:32:27<br/>
 * <b>Copyright (c)</b> 2013魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.domain.form;

/**
 * <b>类名称：</b>PreUpload<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-14 下午3:32:27<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public class PreUpload {

	private String fingerprint;

	public String getFingerprint() {
		return fingerprint;
	}

	public void setFingerprint(String fingerprint) {
		this.fingerprint = fingerprint;
	}

}
