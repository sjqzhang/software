/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.domain.form<br/>
 * <b>文件名：</b>TImgBreakpoint.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2013-1-11-下午3:59:49<br/>
 * <b>Copyright (c)</b> 2013魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.domain.form;

/**
 * <b>类名称：</b>TImgBreakpoint<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>刘安源<br/>
 * <b>修改时间：</b>2013-5-28 下午3:59:49<br/>
 * <b>修改备注：增加字段和注释</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public class TImgBreakpoint {
	/**
	 * 拍照时间
	 */
	private Long cdate;
	/**
	 * 文件名
	 */
	private String fileName;
	/**
	 * 文件大小（byte)
	 */
	private Long fileSize;
	/**
	 * 文件指纹
	 */
	private String fingerprint;
	/**
	 * 序号（自增）
	 */
	private Integer pointId;
	/**
	 * 状态
	 */
	private Integer status;
	/**
	 * 文件路径
	 */
	private String tmpPath;
	/**
	 * 用户ID
	 */
	private Long userId;	
	/**
	 * 创建时间
	 */
	private Long createTime;
	/**
	 * 更新时间
	 */
	private Long updateTime;

	public void setCdate(Long cdate) {
		this.cdate = cdate;
	}

	public Long getCdate() {
		return this.cdate;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileName() {
		return this.fileName;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public Long getFileSize() {
		return this.fileSize;
	}

	public void setFingerprint(String fingerprint) {
		this.fingerprint = fingerprint;
	}

	public String getFingerprint() {
		return this.fingerprint;
	}

	public void setPointId(Integer pointId) {
		this.pointId = pointId;
	}

	public Integer getPointId() {
		return this.pointId;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getStatus() {
		return this.status;
	}

	public void setTmpPath(String tmpPath) {
		this.tmpPath = tmpPath;
	}

	public String getTmpPath() {
		return this.tmpPath;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getUserId() {
		return this.userId;
	}

	/**
	 * @return the createTime
	 */
	public Long getCreateTime() {
		return createTime;
	}

	/**
	 * @param createTime the createTime to set
	 */
	public void setCreateTime(Long createTime) {
		this.createTime = createTime;
	}

	/**
	 * @return the updateTime
	 */
	public Long getUpdateTime() {
		return updateTime;
	}

	/**
	 * @param updateTime the updateTime to set
	 */
	public void setUpdateTime(Long updateTime) {
		this.updateTime = updateTime;
	}	
}
