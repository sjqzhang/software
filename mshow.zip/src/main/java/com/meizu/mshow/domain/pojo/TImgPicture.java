package com.meizu.mshow.domain.pojo;

public class TImgPicture {

	private Long imgId;

	private Long userId;

	private String aliasName;

	private String headIcon;

	private String desc;

	private Long cdate;

	private Integer viewCount;

	private Integer likeCount;

	private Integer commentCount;

	private Integer status;

	private String sourceImg;

	private String middleImg;

	private String minImg;

	private String device;

	private String continent;

	private String country;

	private String province;

	private String city;

	private String district;

	private String street;

	private String streetNumber;

	private Double lng;

	private Double lat;

	private String ip;

	private Integer sourceWidth;

	private Integer sourceHeight;

	private Integer middleWidth;

	private Integer middleHeight;

	private Integer minWidth;

	private Integer minHeight;

	private Double weight;

	private String filterName;

	private Long fileSize;

	private Long activityId;

	public Long getActivityId() {
		return activityId;
	}

	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public String getHeadIcon() {
		return headIcon;
	}

	public void setHeadIcon(String headIcon) {
		this.headIcon = headIcon;
	}

	public Integer getSourceWidth() {
		return sourceWidth;
	}

	public void setSourceWidth(Integer sourceWidth) {
		this.sourceWidth = sourceWidth;
	}

	public Integer getSourceHeight() {
		return sourceHeight;
	}

	public void setSourceHeight(Integer sourceHeight) {
		this.sourceHeight = sourceHeight;
	}

	public Integer getMiddleWidth() {
		return middleWidth;
	}

	public void setMiddleWidth(Integer middleWidth) {
		this.middleWidth = middleWidth;
	}

	public Integer getMiddleHeight() {
		return middleHeight;
	}

	public void setMiddleHeight(Integer middleHeight) {
		this.middleHeight = middleHeight;
	}

	public Integer getMinWidth() {
		return minWidth;
	}

	public void setMinWidth(Integer minWidth) {
		this.minWidth = minWidth;
	}

	public Integer getMinHeight() {
		return minHeight;
	}

	public void setMinHeight(Integer minHeight) {
		this.minHeight = minHeight;
	}

	public Long getImgId() {
		return imgId;
	}

	public void setImgId(Long imgId) {
		this.imgId = imgId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Long getCdate() {
		return cdate;
	}

	public void setCdate(Long cdate) {
		this.cdate = cdate;
	}

	public Integer getViewCount() {
		return viewCount;
	}

	public void setViewCount(Integer viewCount) {
		this.viewCount = viewCount;
	}

	public Integer getLikeCount() {
		return likeCount;
	}

	public void setLikeCount(Integer likeCount) {
		this.likeCount = likeCount;
	}

	public Integer getCommentCount() {
		return commentCount;
	}

	public void setCommentCount(Integer commentCount) {
		this.commentCount = commentCount;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getSourceImg() {
		return sourceImg;
	}

	public void setSourceImg(String sourceImg) {
		this.sourceImg = sourceImg;
	}

	public String getMiddleImg() {
		return middleImg;
	}

	public void setMiddleImg(String middleImg) {
		this.middleImg = middleImg;
	}

	public String getMinImg() {
		return minImg;
	}

	public void setMinImg(String minImg) {
		this.minImg = minImg;
	}

	public String getDevice() {
		return device;
	}

	public void setDevice(String device) {
		this.device = device;
	}

	public String getContinent() {
		return continent;
	}

	public void setContinent(String continent) {
		this.continent = continent;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getStreetNumber() {
		return streetNumber;
	}

	public void setStreetNumber(String streetNumber) {
		this.streetNumber = streetNumber;
	}

	public Double getLng() {
		return lng;
	}

	public void setLng(Double lng) {
		this.lng = lng;
	}

	public Double getLat() {
		return lat;
	}

	public void setLat(Double lat) {
		this.lat = lat;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

}