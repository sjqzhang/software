package com.meizu.mshow.domain.model;

public class MessageModel implements Comparable<MessageModel> {
	// tu.user_id,tu.head_icon,tu.user_name,tp.img_id,tp.source_img,tp.middle_img,tp.min_img,v.cdate,v.remark,v.ca

	private Long messageId;

	private Long userId;// 谁

	private String headIcon;// 谁

	private String aliasName;// 谁

	private long imgId;

	private String sourceImg;

	private String minImg;

	private String middleImg;

	private Integer cdate;

	private String comment;

	private Integer messageCategory;

	private Long destUserId;// 给谁的消息

	private Long replyUserId;

	private String replyAliasName;

	private Integer sourceWidth;

	private Integer sourceHeight;

	private Integer middleWidth;

	private Integer middleHeight;

	private Integer minWidth;

	private Integer minHeight;

	public Integer getSourceWidth() {
		return sourceWidth;
	}

	public void setSourceWidth(Integer sourceWidth) {
		this.sourceWidth = sourceWidth;
	}

	public Integer getSourceHeight() {
		return sourceHeight;
	}

	public void setSourceHeight(Integer sourceHeight) {
		this.sourceHeight = sourceHeight;
	}

	public Integer getMiddleWidth() {
		return middleWidth;
	}

	public void setMiddleWidth(Integer middleWidth) {
		this.middleWidth = middleWidth;
	}

	public Integer getMiddleHeight() {
		return middleHeight;
	}

	public void setMiddleHeight(Integer middleHeight) {
		this.middleHeight = middleHeight;
	}

	public Integer getMinWidth() {
		return minWidth;
	}

	public void setMinWidth(Integer minWidth) {
		this.minWidth = minWidth;
	}

	public Integer getMinHeight() {
		return minHeight;
	}

	public void setMinHeight(Integer minHeight) {
		this.minHeight = minHeight;
	}

	public Long getReplyUserId() {
		return replyUserId;
	}

	public void setReplyUserId(Long replyUserId) {
		this.replyUserId = replyUserId;
	}

	public String getReplyAliasName() {
		return replyAliasName;
	}

	public void setReplyAliasName(String replyAliasName) {
		this.replyAliasName = replyAliasName;
	}

	public Long getDestUserId() {
		return destUserId;
	}

	public void setDestUserId(Long destUserId) {
		this.destUserId = destUserId;
	}

	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getHeadIcon() {
		return headIcon;
	}

	public void setHeadIcon(String headIcon) {
		this.headIcon = headIcon;
	}

	public long getImgId() {
		return imgId;
	}

	public void setImgId(long imgId) {
		this.imgId = imgId;
	}

	public String getSourceImg() {
		return sourceImg;
	}

	public void setSourceImg(String sourceImg) {
		this.sourceImg = sourceImg;
	}

	public String getMinImg() {
		return minImg;
	}

	public void setMinImg(String minImg) {
		this.minImg = minImg;
	}

	public String getMiddleImg() {
		return middleImg;
	}

	public void setMiddleImg(String middleImg) {
		this.middleImg = middleImg;
	}

	public Integer getCdate() {
		return cdate;
	}

	public void setCdate(Integer cdate) {
		this.cdate = cdate;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Integer getMessageCategory() {
		return messageCategory;
	}

	public void setMessageCategory(Integer messageCategory) {
		this.messageCategory = messageCategory;
	}

	@Override
	public int compareTo(MessageModel o) {
		return this.cdate - o.cdate;
	}

}
