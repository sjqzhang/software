package com.meizu.mshow.domain.model;

import java.util.List;

import com.meizu.mshow.domain.pojo.TImgComment;
import com.meizu.mshow.domain.pojo.TImgLike;
import com.meizu.mshow.domain.pojo.TImgPicture;
import com.meizu.mshow.domain.pojo.TImgTag;

public class PictureInCacheModel {
	private TImgPicture picture;

	private List<TImgComment> comments;

	private List<TImgTag> tags;

	private List<TImgLike> likes;

	public TImgPicture getPicture() {
		return picture;
	}

	public void setPicture(TImgPicture picture) {
		this.picture = picture;
	}

	public List<TImgComment> getComments() {
		return comments;
	}

	public void setComments(List<TImgComment> comments) {
		this.comments = comments;
	}

	public List<TImgTag> getTags() {
		return tags;
	}

	public void setTags(List<TImgTag> tags) {
		this.tags = tags;
	}

	public List<TImgLike> getLikes() {
		return likes;
	}

	public void setLikes(List<TImgLike> likes) {
		this.likes = likes;
	}

}
