package com.meizu.mshow.timer;

import java.util.concurrent.ConcurrentLinkedQueue;

public class QueueLikeCommentTag {
	private static ConcurrentLinkedQueue instance = null;	
	//状态控制变量，当stop server时可将inactive设为不可用，即不能往队列里写数据
	private static boolean inactive = false;  

	public static ConcurrentLinkedQueue getInstance() {
		if (instance == null) {
			instance = new ConcurrentLinkedQueue();
		}
		
		return instance;
	}
	
	
	public static boolean isInactive() {
		return QueueLikeCommentTag.inactive;
	}

	public static void setInactive(boolean arg) {
		QueueLikeCommentTag.inactive = arg;
	}
	
}
