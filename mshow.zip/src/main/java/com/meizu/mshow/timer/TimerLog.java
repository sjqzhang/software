package com.meizu.mshow.timer;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.log4j.Logger;

import com.meizu.mshow.common.servlet.SystemContextListener;
import com.meizu.mshow.common.util.ServiceLocator;
import com.meizu.mshow.domain.model.UserMarkModel;
import com.meizu.mshow.domain.pojo.TImgViewlog;
import com.meizu.mshow.picture.dao.PictureDAO;
import com.meizu.mshow.user.dao.UserDAO;

/**
 * 用于处理Log类数据Queue的定时任务
 * 
 * @author LKC
 * 
 */
public class TimerLog extends AbstractTimer {
	private static final Logger logger = Logger.getLogger(SystemContextListener.class);

	private static TimerLog instance = null;
	// 该参数可调整为集中配置，更好的办法DB配置
	private static int PERIOD = 200;
	private static int DELAY = 0;

	private static int BATCH_SIZE = 100;

	public TimerLog(int delay, int period) {
		super(delay, period);
	}

	public static TimerLog getInstance() {
		if (instance == null) {
			instance = new TimerLog(DELAY, PERIOD);
		}
		return instance;
	}

	@Override
	public void initialize() {
		// 打印初始化log
		QueueLog.setInactive(false);
		logger.info("用于处理Log类数据Queue的定时任务，初始话ing。。。。。。");
	}

	@Override
	public void task() {
		try {
			ConcurrentLinkedQueue<Object> queue = QueueLog.getInstance();
			batchProcess(queue);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}

		// 建立DB log
	}

	/**
	 * 该方法在停web服务或消毁该timer时调用
	 */
	@Override
	public void destory() {
		try {
			// 设置让队列不可接收数据
			QueueLog.setInactive(true);
			ConcurrentLinkedQueue<Object> queue = QueueLog.getInstance();
			while (!queue.isEmpty()) {
				batchProcess(queue);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		// 打印销毁log
		logger.info("用于处理Log类数据Queue的定时任务，停止ing。。。。。。");
	}

	/**
	 * 批处理数据
	 */
	private void batchProcess(ConcurrentLinkedQueue<Object> queue) {
		int i = 0;
		List<TImgViewlog> viewList = new ArrayList<TImgViewlog>();
		List<UserMarkModel> markList = new ArrayList<UserMarkModel>();
		while (i < BATCH_SIZE && !queue.isEmpty()) {
			Object obj = queue.poll();
			if (obj instanceof TImgViewlog) {
				viewList.add((TImgViewlog) obj);
			} else if (obj instanceof UserMarkModel) {
				markList.add((UserMarkModel) obj);
			} else {
				// 如果找不多对应对象log下信息 obj.getClass()及obj.toString()
				logger.info("LogQueue 无法识别的对象    : " + obj.getClass() + "   :  " + obj.toString());
			}
			i++;
		}
		if (i > 0) {
			if (viewList.size() > 0) {
				PictureDAO dao = ServiceLocator.getPictureDAO();
				dao.createBatchViewLog(viewList);
			}
			if (markList.size() > 0) {
				UserDAO userDAO = ServiceLocator.getUserDAO();
				userDAO.createBatchUserMark(markList);
			}
		}
	}
}
