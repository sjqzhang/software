package com.meizu.mshow.timer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.log4j.Logger;

import com.meizu.mshow.common.util.ServiceLocator;
import com.meizu.mshow.domain.model.UnLikeModel;
import com.meizu.mshow.domain.pojo.TImgComment;
import com.meizu.mshow.domain.pojo.TImgLike;
import com.meizu.mshow.picture.cache.CacheService;
import com.meizu.mshow.picture.dao.PictureDAO;

/**
 * 用于处理喜欢、评论、标签类数据Queue的定时任务
 * 
 * @author LKC
 * 
 */
public class TimerLikeCommentTag extends AbstractTimer {
	private static final Logger logger = Logger.getLogger(TimerLikeCommentTag.class);

	private static TimerLikeCommentTag instance = null;
	// 该参数可调整为集中配置，更好的办法DB配置
	private static int PERIOD = 200;
	private static int DELAY = 0;
	// private static int SLEEP = 1000;

	private static int BATCH_SIZE = 100;

	public TimerLikeCommentTag(int delay, int period) {
		super(delay, period);
	}

	public static TimerLikeCommentTag getInstance() {
		if (instance == null) {
			instance = new TimerLikeCommentTag(DELAY, PERIOD);
		}
		return instance;
	}

	@Override
	public void initialize() {
		// 打印初始化log
		QueueLikeCommentTag.setInactive(false);
		logger.info("用于处理Log类数据Queue的定时任务，初始话ing。。。。。。");
	}

	@Override
	public void task() {
		try {
			ConcurrentLinkedQueue<Object> queue = QueueLikeCommentTag.getInstance();
			batchProcess(queue);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	/**
	 * 该方法在停web服务或消毁该timer时调用
	 */
	@Override
	public void destory() {
		// 设置让队列不可接收数据
		try {
			QueueLikeCommentTag.setInactive(true);
			ConcurrentLinkedQueue<Object> queue = QueueLikeCommentTag.getInstance();
			while (!queue.isEmpty()) {
				batchProcess(queue);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		// 打印销毁log
		logger.info("用于处理Log类数据Queue的定时任务，停止ing。。。。。。");
	}

	/**
	 * 批处理数据
	 */
	private void batchProcess(ConcurrentLinkedQueue<Object> queue) {
		int i = 0;
		List<TImgComment> commentList = new ArrayList<TImgComment>();
		List<TImgLike> likeList = null;
		HashMap<String, TImgLike> imgUserLikeMap = new HashMap<String, TImgLike>();
		HashMap<Long, Long> flushMap = new HashMap<Long, Long>();
		List<UnLikeModel> deLikieList = new ArrayList<UnLikeModel>();
		List<TImgComment> deCommentList = new ArrayList<TImgComment>();
		while (i < BATCH_SIZE && !queue.isEmpty()) {
			Object obj = queue.poll();
			if (obj instanceof TImgLike) {
				TImgLike like = (TImgLike) obj;
				imgUserLikeMap.put(like.getImgId() + "_" + like.getUserId(), like);
				if (!flushMap.containsKey(like.getImgId())) {
					flushMap.put(like.getImgId(), like.getImgId());
				}
			} else if (obj instanceof TImgComment) {
				TImgComment comment = (TImgComment) obj;
				if (comment.getCommentId() != null && comment.getCommentId() > 0) {
					deCommentList.add(comment);
				} else {
					commentList.add((TImgComment) obj);
				}
				if (!flushMap.containsKey(comment.getImgId())) {
					flushMap.put(comment.getImgId(), comment.getImgId());
				}
			} else if (obj instanceof UnLikeModel) {
				UnLikeModel unlike = (UnLikeModel) obj;
				String key = unlike.getImgId() + "_" + unlike.getUserId();
				if (imgUserLikeMap.containsKey(key))
					imgUserLikeMap.remove(key);
				else
					deLikieList.add(unlike);
				if (!flushMap.containsKey(unlike.getImgId())) {
					flushMap.put(unlike.getImgId(), unlike.getImgId());
				}
			} else {
				// 如果找不多对应对象log下信息 obj.getClass()及obj.toString()
				logger.info("DataQueue 无法识别的对象    : " + obj.getClass() + "   :  " + obj.toString());
			}
			i++;
		}
		if (i == 0)
			return;
		likeList = new ArrayList<TImgLike>(imgUserLikeMap.values());
		PictureDAO dao = ServiceLocator.getPictureDAO();
		CacheService cacheService = ServiceLocator.getCacheService();
		if (commentList.size() > 0) {
			try {
				dao.createBatchComment(commentList);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
		if (likeList.size() > 0) {
			try {
				dao.createBatchLike(likeList);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
		if (deLikieList.size() > 0) {
			try {
				dao.deleteBatchLike(deLikieList);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}

		if (deCommentList.size() > 0) {
			try {
				dao.deleteBatchComment(deCommentList);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
		// 调用清除redis imgIDList
		List<Long> imgIdList = new ArrayList<Long>(flushMap.values());
		cacheService.deleteBatchPictureInCacheModel(imgIdList);

	}
}
