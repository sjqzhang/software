package com.meizu.mshow.timer;

import java.util.Timer;
import java.util.TimerTask;

public class AsyncSimpleTask {

	
	public void start(){
		new Runnable() {
		    public void run() {}
		};		
		
	}		
	
}
