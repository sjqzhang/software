package com.meizu.mshow.timer;

import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;

public class JSONPasserSample {
	
	public static void main(String[] args) {
		JSONPasserSample sample = new JSONPasserSample();
		try{
			sample.testObject();     //当resultModel里是一个sample对象时
			sample.testListObject();//当resultModel里是一个sample对象的List集合对象时
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public void testObject() throws Exception {
		//这个TypeReference是关键，他决定你对象的结构
		TypeReference<ResultModel<A>> typeRef = new TypeReference<ResultModel<A>>() {
			ResultModel resultModel = new ResultModel();
		};
		ResultModel<A> vo = JSON.parseObject("{\"returnValue\":{\"id\":123}}",
				typeRef);

		System.out.println(vo.getReturnValue().getId());
	}

	public void testListObject() throws Exception {
		TypeReference<ResultModel<List<A>>> typeRef = new TypeReference<ResultModel<List<A>>>() {
		};

		ResultModel<List<A>> vo = JSON.parseObject(
				"{\"returnValue\":[{\"id\":123}]}", typeRef);

		System.out.println(vo.getReturnValue().get(0).getId());
	}

	public static class ResultModel<T> {//类是静态的，那是因为时内部内，拷出去后可以变成非静态的

		private T returnValue;

		public T getReturnValue() {
			return returnValue;
		}

		public void setReturnValue(T returnValue) {
			this.returnValue = returnValue;
		}
	}

	public static class A {//类是静态的，那是因为时内部内，拷出去后可以变成非静态的

		private int id;

		public int getId() {
			return id;
		}  

		public void setId(int id) {
			this.id = id;
		}

	}

}
