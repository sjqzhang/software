package com.meizu.mshow.timer;

import org.apache.log4j.Logger;

/**
 * 
 * @author LKC
 * 
 */
public class TimerSystem extends AbstractTimer {
	private Logger logger = Logger.getLogger(TimerSystem.class);
	private static TimerSystem instance = null;
	// 该参数可调整为集中配置，更好的办法DB配置
	private static int PERIOD = 60000;
	private static int DELAY = 0;

	public TimerSystem(int delay, int period) {
		super(delay, period);
	}

	public static TimerSystem getInstance() {
		if (instance == null) {
			instance = new TimerSystem(DELAY, PERIOD);
		}
		return instance;
	}

	@Override
	public void initialize() {

	}

	@Override
	public void task() {
		try {
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}

	}

	@Override
	public void destory() {

	}

}
