package com.meizu.mshow.timer;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.util.DateUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.common.util.ServiceLocator;
import com.meizu.mshow.domain.model.TimerModel;
import com.meizu.mshow.picture.business.TimerService;
import com.meizu.mshow.picture.cache.CacheService;

/**
 * 用于处理广场类缓存数据
 * 
 * @author LKC
 * 
 */
public class TimerPortal extends AbstractTimer {
	private Logger logger = Logger.getLogger(TimerPortal.class);

	private static TimerPortal instance = null;
	// 该参数可调整为集中配置，更好的办法DB配置,比缓存快10's
	private static int PERIOD = 290000;
	private static int DELAY = 0;
	// 求值的周期，倒推时间
	private static int HOT_COUNT_PERIOD = 7 * 24;
	private static int FAST_COUNT_PERIOD = 12;

	private static int HOT_LIMIT = 300;
	private static int FAST_LIMIT = 100;

	// 允许出现推荐类别的最大值
	private static int TOTAL_PRT = 300;

	// 速率放大系数
	private static int FAST_RISE_RATIO = 10;

	private List prtList = null;
	private HashSet checkRepeatSet = null;
	private List prtHotList = null;
	private List prtFastList = null;

	public TimerPortal(int delay, int period) {
		super(delay, period);
	}

	public static TimerPortal getInstance() {
		if (instance == null) {
			instance = new TimerPortal(DELAY, PERIOD);
		}
		return instance;
	}

	@Override
	public void initialize() {
		// 记下日志
	}

	@Override
	public void task() {
		try {
			logger.debug("---------@PORTAL TIMMER BEGIN:");
			this.prtList = new ArrayList();
			this.checkRepeatSet = new HashSet();
			this.prtHotList = new ArrayList();
			this.prtFastList = new ArrayList();
			buildPrt();
			buildHotInWeek();
			buildFastInHour();
			unitResult();
			this.prtList = null;
			this.checkRepeatSet = null;
			this.prtHotList = null;
			this.prtFastList = null;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	@Override
	public void destory() {
		// 记下日志
	}

	/**
	 * 获取单位时间内热度上升较快的 取最近1天的帖子，取表中联赞、评论、查看的count值进行计算
	 */
	private void buildFastInHour() {
		// 此处应该改成调用DAO
		TimerService timerService = ServiceLocator.getTimerService();
		QueryModel model = new QueryModel();
		// #{commentWeight},#{likeWeight},#{vewWeight},#{cdate},#{start},#{limit}
		Map map = model.getCondition(Map.class);
		map.put("commentWeight", BusinessConstants.SCORE_COMMENT_WEIGHT);
		map.put("likeWeight", BusinessConstants.SCORE_LIKE_WEIGHT);
		map.put("vewWeight", BusinessConstants.SCORE_VIEW_WEIGHT);
		int cdate = (int) (DateUtil.getNow().getTime() / 1000);
		map.put("cdate", cdate - FAST_COUNT_PERIOD * 60 * 60);// 2h
		map.put("start", 0);
		model.setLimit(FAST_LIMIT);
		List daoList = timerService.loadHotWithTime(model);
		for (int i = 0; i < daoList.size(); i++) {
			// 用set去重
			if (!checkRepeatSet.contains(daoList.get(i))) {
				prtHotList.add(daoList.get(i));
				checkRepeatSet.add(daoList.get(i));
			}
		}
	}

	/**
	 * 获取单位时间内热度较高的帖子 取最近1周得帖子，取表中联赞、评论、查看的count值进行计算
	 */
	private void buildHotInWeek() {
		TimerService timerService = ServiceLocator.getTimerService();
		QueryModel model = new QueryModel();
		// #{commentWeight},#{likeWeight},#{vewWeight},#{cdate},#{start},#{limit}
		Map map = model.getCondition(Map.class);
		map.put("commentWeight", BusinessConstants.SCORE_COMMENT_WEIGHT);
		map.put("likeWeight", BusinessConstants.SCORE_LIKE_WEIGHT);
		map.put("vewWeight", BusinessConstants.SCORE_VIEW_WEIGHT);
		int cdate = (int) (DateUtil.getNow().getTime() / 1000);
		map.put("cdate", cdate - HOT_COUNT_PERIOD * 60 * 60);// 7d
		model.setLimit(HOT_LIMIT);
		List daoList = timerService.loadHotWithTime(model);
		for (int i = 0; i < daoList.size(); i++) {
			// 用set去重
			if (!checkRepeatSet.contains(daoList.get(i))) {
				prtFastList.add(daoList.get(i));
				checkRepeatSet.add(daoList.get(i));
			}
		}
	}

	/**
	 * 取推荐表中运营推荐数据
	 */
	private void buildPrt() {
		TimerService timerService = ServiceLocator.getTimerService();
		QueryModel model = new QueryModel();
		// #{commentWeight},#{likeWeight},#{vewWeight},#{start},#{limit}
		Map map = model.getCondition(Map.class);
		map.put("commentWeight", BusinessConstants.SCORE_COMMENT_WEIGHT);
		map.put("likeWeight", BusinessConstants.SCORE_LIKE_WEIGHT);
		map.put("vewWeight", BusinessConstants.SCORE_VIEW_WEIGHT);
		model.setLimit(TOTAL_PRT);
		List daoList = timerService.loadPrt(model);
		for (int i = 0; i < daoList.size(); i++) {
			prtList.add(daoList.get(i));
			checkRepeatSet.add(prtList.add(daoList.get(i)));
		}
	}

	/**
	 * 拼装缓存所需的300条记录，同时将数据写入到Prt表
	 */
	private void unitResult() {
		// 这里调用归并排序
		List<TimerModel> mList = this.merge(prtHotList, prtFastList);
		// 将排序后的结果添加进来
		if (mList != null) {
			prtList.addAll(mList);
		}
		if (prtList != null && prtList.size() > this.TOTAL_PRT) {
			prtList = prtList.subList(0, TOTAL_PRT - 1);
		}

		// 这里调用写redis方法
		List<Long> imgIds = new ArrayList<Long>();
		for (Iterator<TimerModel> iter = prtList.iterator(); iter.hasNext();) {
			TimerModel model = iter.next();
			imgIds.add(model.getImgId());
		}
		if (imgIds.size() > 0) {
			CacheService cacheService = ServiceLocator.getCacheService();
			cacheService.createHot(imgIds);
		}
		TimerService timerService = ServiceLocator.getTimerService();
		timerService.createHot(mList);

	}

	private List<TimerModel> merge(List<TimerModel> list1, List<TimerModel> list2) {
		List<TimerModel> retList = new ArrayList<TimerModel>();
		int i1 = 0;
		int i2 = 0;
		if (list1 == null || list1.size() == 0)
			return list2;
		if (list2 == null || list2.size() == 0)
			return list1;
		TimerModel m1 = list1.get(i1);
		TimerModel m2 = list2.get(i2);
		while (i1 < list1.size() && i2 < list2.size()) {
			if (m1.getHotScore() >= m2.getHotScore() * FAST_RISE_RATIO) {
				retList.add(m1);
				i1++;
				if (i1 < list1.size())
					m1 = list1.get(i1);
			} else {
				retList.add(m2);
				i2++;
				if (i2 < list2.size())
					m2 = list2.get(i2);
			}
		}
		if (i1 < list1.size()) {
			for (int i = i1; i < list1.size(); i++) {
				m1 = list1.get(i);
				retList.add(m1);
			}
		}
		if (i2 < list2.size()) {
			for (int i = i2; i < list2.size(); i++) {
				m2 = list2.get(i);
				retList.add(m2);
			}
		}
		return retList;
	}
}
