package com.meizu.mshow.timer;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.log4j.Logger;

import com.meizu.mshow.common.util.ServiceLocator;
import com.meizu.mshow.domain.model.MessageModel;
import com.meizu.mshow.domain.model.UserMarkModel;
import com.meizu.mshow.user.dao.MessageDAO;
import com.meizu.mshow.user.dao.UserDAO;

/**
 * 用于处理Log类数据Queue的定时任务
 * 
 * @author LKC
 * 
 */
public class TimerFollow extends AbstractTimer {
	private static final Logger logger = Logger.getLogger(TimerFollow.class);

	private static TimerFollow instance = null;
	// 该参数可调整为集中配置，更好的办法DB配置
	private static int PERIOD = 200;
	private static int DELAY = 0;

	private static int BATCH_SIZE = 500;

	public TimerFollow(int delay, int period) {
		super(delay, period);
	}

	public static TimerFollow getInstance() {
		if (instance == null) {
			instance = new TimerFollow(DELAY, PERIOD);
		}
		return instance;
	}

	@Override
	public void initialize() {
		// 打印初始化log
		QueueLog.setInactive(false);
		logger.info("用于处理Follow类数据Queue的定时任务，初始话ing。。。。。。");
	}

	@Override
	public void task() {
		try {
			ConcurrentLinkedQueue<Object> queue = QueueFollow.getInstance();
			batchProcess(queue);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}

		// 建立DB log
	}

	/**
	 * 该方法在停web服务或消毁该timer时调用
	 */
	@Override
	public void destory() {
		try {
			// 设置让队列不可接收数据
			QueueLog.setInactive(true);
			ConcurrentLinkedQueue<Object> queue = QueueLog.getInstance();
			while (!queue.isEmpty()) {
				batchProcess(queue);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		// 打印销毁log
		logger.info("用于处理Log类数据Queue的定时任务，停止ing。。。。。。");
	}

	/**
	 * 批处理数据
	 */
	private void batchProcess(ConcurrentLinkedQueue<Object> queue) {
		int i = 0;
		List<MessageModel> msgList = new ArrayList<MessageModel>();
		List<UserMarkModel> markList = new ArrayList<UserMarkModel>();
		List<Long> deleteMsgList = new ArrayList<Long>();
		while (i < BATCH_SIZE && !queue.isEmpty()) {
			Object obj = queue.poll();
			if (obj instanceof MessageModel) {
				MessageModel model = (MessageModel) obj;
				if (model.getUserId() == null) {
					deleteMsgList.add(model.getMessageId());
				} else {
					msgList.add(model);
				}
			} else if (obj instanceof UserMarkModel) {
				markList.add((UserMarkModel) obj);
			} else {
				// 如果找不多对应对象log下信息 obj.getClass()及obj.toString()
				logger.info("LogQueue 无法识别的对象    : " + obj.getClass() + "   :  " + obj.toString());
			}
			i++;
		}
		if (i > 0) {
			if (msgList.size() > 0) {
				try {
					MessageDAO dao = ServiceLocator.getMessageDAO();
					dao.createBatchMessage(msgList);
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
				}
			}
			if (markList.size() > 0) {
				try {
					UserDAO userDAO = ServiceLocator.getUserDAO();
					userDAO.createBatchUserMark(markList);
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
				}
			}
			if (deleteMsgList.size() > 0) {
				try {
					MessageDAO dao = ServiceLocator.getMessageDAO();
					dao.deleteBatchMessage(deleteMsgList);
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
				}
			}
		}
	}
}
