package com.meizu.mshow.timer;

import java.util.Timer;
import java.util.TimerTask;

public abstract class AbstractTimer {
	public Timer timer = null;	
	public int delay = 0;
	public int period = 60 * 1000;
	
	public AbstractTimer(){
		
	}
	
	public AbstractTimer(int delay, int period){
		this.delay = delay;
		this.period = period;
	}
	
	public void start(){
		initialize();
		timer = new Timer();
		timer.schedule(new TimerTask() {
			public void run() {
				task();
			}
		}, this.delay, this.period);
	}
	
	public void start(int delay, int period){
		initialize();
		timer = new Timer();
		timer.schedule(new TimerTask() {
			public void run() {
				task();
			}
		}, delay, period);
	}
		
	public void destroyTimer() {
		destory();
		if (timer != null) {
			timer.cancel();
			timer = null;
		}
	}
	
	
	public abstract void initialize();
	
	public abstract void task();
	
	public abstract void destory();
}
