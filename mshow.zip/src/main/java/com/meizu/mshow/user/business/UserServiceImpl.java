package com.meizu.mshow.user.business;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.meizu.mshow.common.ApplicationConfig;
import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.cache.DBCache;
import com.meizu.mshow.common.cache.DBCacheOperation;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.exception.Error;
import com.meizu.mshow.common.exception.ErrorCode;
import com.meizu.mshow.common.util.CacheKeyUtil;
import com.meizu.mshow.common.util.DateUtil;
import com.meizu.mshow.common.util.ImageUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.SearchModel;
import com.meizu.mshow.domain.model.UserModel;
import com.meizu.mshow.domain.pojo.TImgTag;
import com.meizu.mshow.domain.pojo.TSysUser;
import com.meizu.mshow.picture.web.PictureAndroidController;
import com.meizu.mshow.user.dao.UserDAO;

@Service("userService")
public class UserServiceImpl implements UserService {

	private static final Logger logger = Logger.getLogger(PictureAndroidController.class);

	@Autowired
	@Qualifier("userDAO")
	private UserDAO userDAO;

	@Override
	public void createUser(UserModel userModel) {
		this.userDAO.createUser(userModel);
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_USER, key = "#p[0]", ttl = BusinessConstants.CACHE_CATEGORY_SHORT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public UserModel loadUserViaUserId(Long userId) {
		UserModel model = this.userDAO.loadUserViaUserId(userId);
		return model;
	}

	private void validateUser(TSysUser user) {

		// check user name length;
		if (user.getAliasName().length() > 45)
			throw new ApplicationException(ErrorCode.USER_ALIASNAME_TOOLONG);
		// check user name exsist;
		int userCount = this.userDAO.getUserCountViaAliasName(user.getAliasName(), user.getUserId());
		if (userCount > 0)
			throw new ApplicationException(ErrorCode.USER_ALIASNAME_HASTAKEN);

	}

	@Override
	// clear cache at dao method
	public void updateUser(UserModel userModel) {
		this.validateUser(userModel.getUser());
		this.userDAO.updateUser(userModel.getUser());
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_SEARCHUSER, key = "#p[0].condition", ttl = BusinessConstants.CACHE_CATEGORY_DEFAULT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public SearchModel searchUser(QueryModel keyword) {
		return this.userDAO.searchUser(keyword);
	}

	private void deleteHeadIcon(String iconPath, String uploadDir, String prefixName) {
		try {
			if (iconPath != null) {
				String originPath = iconPath.replace(prefixName, uploadDir);
				File f1 = new File(originPath);
				if (f1.exists())
					f1.delete();
			}
		} catch (Exception e) {
			logger.warn("delete" + iconPath + " fail!", e);
		}
	}

	@Override
	public void updateUserHeadIcon(MultipartFile headIcon, UserModel umodel) {
		String uploadDir = ApplicationConfig.getInstance().getProperty(BusinessConstants.SYS_UPLOAD_DIR);
		String prefixName = ApplicationConfig.getInstance().getProperty(BusinessConstants.SYS_BASE_URL);
		// 清除头像
		if (headIcon == null) {
			if (umodel.getUser().getHeadIcon() != null) {
				this.deleteHeadIcon(umodel.getUser().getHeadIcon(), uploadDir, prefixName);
				this.userDAO.updateUserHeadIcon(null, umodel.getUser().getUserId());
			}
			return;
		}
		// 更新头像
		Date date = DateUtil.getNow();
		String fileName = UUID.randomUUID().toString();
		String extName = ".jpg";
		if (headIcon.getOriginalFilename().lastIndexOf(".") > 0)
			extName = headIcon.getOriginalFilename().substring(headIcon.getOriginalFilename().lastIndexOf("."));
		fileName = fileName + extName;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		SimpleDateFormat f = new SimpleDateFormat("yyyy" + BusinessConstants.FILE_SEPARATOR + "MM" + BusinessConstants.FILE_SEPARATOR + "dd" + BusinessConstants.FILE_SEPARATOR + "kk");
		String p = f.format(date.getTime());
		StringBuffer path = new StringBuffer().append(BusinessConstants.ICON_SEPARATOR).append(BusinessConstants.FILE_SEPARATOR).append(p).append(BusinessConstants.FILE_SEPARATOR).append(fileName);
		int read = -1;
		long total = 0;
		byte[] copyBuffer = new byte[BusinessConstants.BUF_SIZE];
		long totalSize = 0;
		try {
			BufferedOutputStream os = null;
			BufferedInputStream in = null;
			File file = new File(uploadDir + path);
			if (!file.getParentFile().exists())
				file.getParentFile().mkdirs();
			try {
				os = new BufferedOutputStream(new FileOutputStream(file, true));
				in = new BufferedInputStream(headIcon.getInputStream());
				while (true) {
					read = in.read(copyBuffer, 0, copyBuffer.length);
					if (read == -1) {
						break;
					}
					totalSize += read;
					os.write(copyBuffer, 0, read);
					total += read;
				}
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				throw e;
			} finally {
				try {
					if (headIcon.getInputStream() != null) {
						headIcon.getInputStream().close();
					}
					if (os != null) {
						os.flush();
						os.close();
					}
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
					throw e;
				} finally {
					os = null;
				}
			}
			ImageUtil image = ImageUtil.getInstance(uploadDir + path);
			image.resizeByWidth(BusinessConstants.IMAGE_ZIP_ICON_WIDTH);
			image.saveAs(uploadDir + path);
		} catch (Exception e) {
			throw new ApplicationException(Error.FILE_WRITE_ERROR);
		}
		this.deleteHeadIcon(umodel.getUser().getHeadIcon(), uploadDir, prefixName);
		this.userDAO.updateUserHeadIcon(prefixName + path, umodel.getUser().getUserId());
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_USER, key = "#p[0].userId", op = DBCacheOperation.DELETE)
	public void updateUserLocation(TSysUser user) {
		this.userDAO.updateUserLocation(user);

	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_PINEDTAG, key = "#p[0].condition", ttl = BusinessConstants.CACHE_CATEGORY_SHORT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public List<TImgTag> loadUserPinedTags(QueryModel queryModel) {
		return this.userDAO.loadUserPinedTags(queryModel);
	}
}