package com.meizu.mshow.user.web;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.scribe.builder.ServiceBuilder;
import org.scribe.builder.api.SinaWeiboApi20;
import org.scribe.model.OAuthRequest;
import org.scribe.model.Response;
import org.scribe.model.Token;
import org.scribe.model.Verb;
import org.scribe.model.Verifier;
import org.scribe.oauth.OAuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meizu.mshow.common.ApplicationConfig;
import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.base.BaseController;
import com.meizu.mshow.common.base.BaseResultModel;
import com.meizu.mshow.common.security.SecurityUtil;
import com.meizu.mshow.common.util.Base64KeyManager;
import com.meizu.mshow.common.util.RSACoder;
import com.meizu.mshow.common.util.StringUtil;
import com.meizu.mshow.domain.model.UserModel;
import com.meizu.mshow.domain.pojo.TBsArea;
import com.meizu.mshow.domain.pojo.TSysUser;
import com.meizu.mshow.oauth.util.TencentWeiboApi2;
import com.meizu.mshow.system.business.SystemService;
import com.meizu.mshow.user.business.UserService;

@Controller
@RequestMapping(value = "/android")
public class UserAuthAndroidController extends BaseController {
	private static final Logger logger = Logger.getLogger(UserController.class);

	private static final Token EMPTY_TOKEN = null;

	@Autowired
	@Qualifier("userService")
	private UserService userService;

	@Autowired
	@Qualifier("systemService")
	private SystemService systemService;

	private String getRedirectUrl(HttpServletRequest request) {
		String useruri = request.getParameter("useruri");
		if (useruri == null || useruri.equals("")) {
			String refrenceUrl = request.getHeader("Referer");
			if (refrenceUrl != null && !refrenceUrl.equals("")) {
				useruri = refrenceUrl;
			} else {
				useruri = this.getBasePath(request);
			}
		}
		return useruri;
	}

	@RequestMapping(value = "/oauth/sina")
	public @ResponseBody
	BaseResultModel loginViaSina(HttpServletRequest request, HttpServletResponse response) throws NoSuchAlgorithmException, KeyManagementException, IOException {
		SecurityUtil.trustAllCert();
		ApplicationConfig applicationConfig = ApplicationConfig.getInstance();
		String apiKey = applicationConfig.getProperty("sina.apikey");
		String apiSecret = applicationConfig.getProperty("sina.apisecret");
		OAuthService service = new ServiceBuilder().provider(SinaWeiboApi20.class).apiKey(apiKey).apiSecret(apiSecret).callback(applicationConfig.getProperty("sina.accesstoken.callback")).build();
		Verifier verifier = new Verifier(request.getParameter("code"));
		Token accessToken = service.getAccessToken(EMPTY_TOKEN, verifier);
		OAuthRequest orequest = new OAuthRequest(Verb.GET, BusinessConstants.SINA_PROTECTED_RESOURCE_URL);
		service.signRequest(accessToken, orequest);
		Response oresponse = orequest.send();
		HashMap map = JSON.parseObject(oresponse.getBody(), HashMap.class);
		String unitUserId = (Long) map.get("uid") + "";

		// loadUserViaUnitUserId
		// if the user is null , create a user with sina data
		if ((unitUserId) == null) {
			OAuthRequest orequest2 = new OAuthRequest(Verb.GET, BusinessConstants.SINA_PROTECTED_USER_URL);
			orequest2.addQuerystringParameter("uid", unitUserId);
			service.signRequest(accessToken, orequest2);
			Response oresponse2 = orequest2.send();
			System.out.println(oresponse2.getCode());
			System.out.println(oresponse2.getBody());
			// create user;
		}

		String userId = "";
		// init session here {}&& return
		SecurityUtil.login(request, null);
		return new BaseResultModel();
	}

	@RequestMapping(value = "/oauth/flyme")
	public @ResponseBody
	BaseResultModel loginViaFlyme(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String token = request.getParameter("token");
		BaseResultModel model = new BaseResultModel();
		if (token != null && !token.equals("")) {
			Base64KeyManager base64KeyManager = (Base64KeyManager) WebApplicationContextUtils.getWebApplicationContext(request.getSession().getServletContext()).getBean("Base64KeyManager");
			String strJsonUser = RSACoder.decryptWithRSA_AES(token, base64KeyManager.getPublicKey());
			JSONObject jsonObject = JSONObject.parseObject(strJsonUser);
			UserModel userModel = new UserModel();
			TSysUser user = new TSysUser();
			user.setUserId(jsonObject.getLong("uid"));
			user.setUserName(jsonObject.getString("flyme"));
			user.setEmail(jsonObject.getString("email"));
			user.setCdate((int) (jsonObject.getLong("date") / 1000));
			user.setLastLogin(jsonObject.getInteger("last_login_time"));
			user.setIp(this.getRemoteIp(request));
			StringUtil.setCity(user.getIp(), user);
			if (user.getCity() != null && !user.getCity().equals("")) {
				TBsArea area = this.systemService.loadTBsAreaViaCityName(user.getCity());
				if (area != null) {
					user.setLng(area.getLng());
					user.setLat(area.getLat());
				}
			}
			user.setAliasName(jsonObject.getString("name"));
			user.setVest(BusinessConstants.VEST_FALSE);
			user.setStatus(BusinessConstants.USER_STATUS_DEFAULT);
			userModel.setUser(user);
			SecurityUtil.login(request, userModel);
			model.setReturnValue(user);
			if (logger.isDebugEnabled()) {
				logger.debug(strJsonUser);
			}
		}
		return model;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/oauth/tencent")
	public @ResponseBody
	BaseResultModel loginViaTencent(HttpServletRequest request, HttpServletResponse response) throws NoSuchAlgorithmException, KeyManagementException, IOException {
		SecurityUtil.trustAllCert();
		ApplicationConfig applicationConfig = ApplicationConfig.getInstance();
		String apiKey = applicationConfig.getProperty("tencent.apikey");
		String apiSecret = applicationConfig.getProperty("tencent.apisecret");
		OAuthService service = new ServiceBuilder().provider(TencentWeiboApi2.class).apiKey(apiKey).apiSecret(apiSecret).callback(applicationConfig.getProperty("tencent.accesstoken.callback")).build();
		Verifier verifier = new Verifier(request.getParameter("code"));
		Token accessToken = service.getAccessToken(EMPTY_TOKEN, verifier);
		OAuthRequest orequest = new OAuthRequest(Verb.GET, BusinessConstants.TENCENT_PROTECTED_RESOURCE_URL);
		service.signRequest(accessToken, orequest);
		Response oresponse = orequest.send();
		Pattern responseBodyPattern = Pattern.compile("\\{\\S{1,}[^\\]]");
		Matcher matcher = responseBodyPattern.matcher(oresponse.getBody());
		if (matcher.find()) {
			HashMap map = JSON.parseObject(matcher.group(0), HashMap.class);
			String unitUserId = map.get("openid") + "";
			OAuthRequest orequest2 = new OAuthRequest(Verb.GET, BusinessConstants.TENCENT_PROTECTED_USER_URL);
			orequest2.addQuerystringParameter("openid", unitUserId);
			orequest2.addQuerystringParameter("oauth_consumer_key", apiKey);
			orequest2.addQuerystringParameter("client_id", apiKey);
			service.signRequest(accessToken, orequest2);
			Response oresponse2 = orequest2.send();
			System.out.println(oresponse2.getCode());
			System.out.println(oresponse2.getBody());
			HashMap userOrigin = JSON.parseObject(oresponse2.getBody(), HashMap.class);
			System.out.println(userOrigin.get("data"));
			if (userOrigin.get("data") != null && !userOrigin.get("data").toString().equals("")) {
				HashMap userHashMap = JSON.parseObject(userOrigin.get("data").toString(), HashMap.class);
				System.out.println(userHashMap.get("openid"));
				System.out.println(userHashMap.get("name"));
				System.out.println(userHashMap.get("nick"));
			}
			// create user;
		}

		// loadUserViaUnitUserId
		// if the user is null , create a user with sina data
		String userId = "";
		// init session here {}&& return
		SecurityUtil.login(request, null);
		return new BaseResultModel();
	}

	@RequestMapping(value = "/oauth/logout")
	public @ResponseBody
	BaseResultModel logout(HttpServletRequest request, HttpServletResponse response) throws RuntimeException, NoSuchAlgorithmException, KeyManagementException, IOException {
		SecurityUtil.logout(request);
		return new BaseResultModel();
	}

}
