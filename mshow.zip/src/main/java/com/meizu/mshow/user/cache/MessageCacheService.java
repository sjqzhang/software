package com.meizu.mshow.user.cache;

import java.util.List;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.MessageModel;

public interface MessageCacheService {

	// 获取一个新的消息ID
	public long getNewMessageId();

	// 创建一个消息
	public void createMessage(MessageModel model);

	// 更新用户的消息数
	public long increaseNewMessageCount(Long userId);

	// 取某用户的消息列表
	public List<MessageModel> loadMessageList(QueryModel model);

	// 重置消息数
	public void resetNewMeesageCount(Long userId);

	// 删除消息
	public void deleteMessage(Long userId, Long messageId);

	// 加载未读消息数
	public int loadNewMessageCount(Long userId);

	// 加载消息总数
	public int loadUserMessageTotalCount(long userId);

	// 删除过多的消息
	public void truncateMessageOverMax(long userId);
	// 初始化消息
	// public void createMessageBox(Long userId, List<MessageModel> list);

}