package com.meizu.mshow.user.business;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.UserMarkModel;
import com.meizu.mshow.domain.pojo.TSysUser;
import com.meizu.mshow.timer.QueueFollow;
import com.meizu.mshow.user.cache.UserMarkCacheService;
import com.meizu.mshow.user.dao.UserDAO;

@Service("userMarkService")
public class UserMarkServiceImpl implements UserMarkService {
	private static final Logger logger = Logger.getLogger(UserMarkServiceImpl.class);
	@Autowired
	@Qualifier("userMarkCacheService")
	private UserMarkCacheService userMarkCacheService;

	@Autowired
	@Qualifier("userDAO")
	private UserDAO userDAO;

	@Override
	public void createUserMark(TSysUser user, UserMarkModel markModel) {
		long markId = this.userMarkCacheService.getUserMarkId();
		markModel.setMarkId(markId);
		this.userMarkCacheService.createUserMark(markModel);
		this.userMarkCacheService.createUserFollow(user, markModel.getDestUserId());
		this.userMarkCacheService.truncateOverMax(markModel.getUserId());
		if (!QueueFollow.isInactive()) {
			QueueFollow.getInstance().add(markModel);
		} else {
			userDAO.createUserMark(markModel);
		}
	}

	@Override
	public List<UserMarkModel> loadUserMarkList(QueryModel queryModel) {
		return this.userMarkCacheService.loadUserMarkList(queryModel);
	}

	@Override
	public int loadUserHotCount(long userId) {
		return this.userMarkCacheService.loadUserHotCount(userId);
	}

	@Override
	public List<TSysUser> loadFollowedUser(QueryModel queryModel) {
		return this.userMarkCacheService.loadFollowedUser(queryModel);
	}

}