package com.meizu.mshow.user.web;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.meizu.mshow.common.base.BaseController;
import com.meizu.mshow.common.base.BaseResultModel;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.security.SecurityAnnotation;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.MessageModel;
import com.meizu.mshow.user.business.MessageService;

@RequestMapping(value = "/android")
@Controller
public class MessageAndroidController extends BaseController {

	private static final Logger logger = Logger.getLogger(MessageAndroidController.class);

	@Autowired
	@Qualifier("messageService")
	private MessageService messageService;

	@RequestMapping(value = "/user/msgcount")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel loadUserMessageCount(HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(0);
		try {
			Integer count = this.messageService.loadNewMessageCount(this.getUserId(request));
			model.setReturnValue(count);
		} catch (RuntimeException e) {
			logger.error(e.getMessage(), e);
		}
		return model;
	}

	@RequestMapping(value = "/message/delete")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel deleteMessage(@RequestParam("messageId") Long messageId, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		this.messageService.deleteMessage(this.getUserId(request), messageId);
		return model;
	}

	@RequestMapping(value = "/user/showmsg")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel loadUserMessage(HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		QueryModel queryModel = this.loadQueryModel(request);
		queryModel.getCondition(Map.class).put("userId", this.getUserId(request));
		String cdate = request.getParameter("cdate");
		String posId = request.getParameter("posId");
		if (cdate != null && !cdate.equals(""))
			queryModel.getCondition(Map.class).put("cdate", cdate);
		if (posId != null)
			queryModel.getCondition(Map.class).put("posId", posId);
		List<MessageModel> list = this.messageService.loadMessageList(queryModel);
		model.setReturnValue(list);
		return model;
	}
}