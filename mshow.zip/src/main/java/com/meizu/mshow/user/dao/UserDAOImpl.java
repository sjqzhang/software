package com.meizu.mshow.user.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.base.BaseDao;
import com.meizu.mshow.common.cache.DBCache;
import com.meizu.mshow.common.cache.DBCacheOperation;
import com.meizu.mshow.common.util.CacheKeyUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.SearchModel;
import com.meizu.mshow.domain.model.UserMarkModel;
import com.meizu.mshow.domain.model.UserModel;
import com.meizu.mshow.domain.pojo.TImgTag;
import com.meizu.mshow.domain.pojo.TSysUnitmap;
import com.meizu.mshow.domain.pojo.TSysUnituser;
import com.meizu.mshow.domain.pojo.TSysUser;

@Repository("userDAO")
public class UserDAOImpl extends BaseDao implements UserDAO {

	Logger logger = Logger.getLogger(UserDAOImpl.class);

	@Override
	public void createUser(UserModel userModel) {
		if (userModel.getUser() != null)
			this.getSqlSession().insert("TSysUser.createUserWithFragment", userModel.getUser());
		if (userModel.getUnitUser() != null && userModel.getUnitUser().size() > 0) {
			for (Iterator<TSysUnituser> iter = userModel.getUnitUser().iterator(); iter.hasNext();) {
				TSysUnituser tu = iter.next();
				this.getSqlSession().insert("TSysUnituser.createUserWithFragment", tu);
				TSysUnitmap tm = new TSysUnitmap();
				tm.setUserId(userModel.getUser().getUserId());
				tm.setUnitUserId(tu.getUnituserId());
				tm.setStatus(BusinessConstants.DEFAULT);
				this.getSqlSession().insert("TSysUnitmap.createUserWithFragment", tm);
			}
		}
	}

	@Override
	public void deleteUserViaUserId(Long userId) {
		HashMap<String, Long> map = new HashMap<String, Long>();
		map.put("userId", userId);
		this.getSqlSession().delete("deleteUserViaUserId", map);
	}

	@Override
	public UserModel loadUserViaUserId(Long userId) {
		HashMap<String, Long> map = new HashMap<String, Long>();
		map.put("userId", userId);
		UserModel retModel = null;
		TSysUser user = this.getSqlSession().selectOne("TSysUser.loadUserViaUserId", map);
		if (user != null) {
			retModel = new UserModel();
			retModel.setUser(user);
		}
		return retModel;
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_USER, key = "#p[0].userId", op = DBCacheOperation.DELETE)
	public void updateUser(TSysUser user) {
		this.getSqlSession().update("TSysUser.updateUserWithFragment", user);

	}

	@Override
	public SearchModel searchUser(QueryModel query) {

		SearchModel searchModel = new SearchModel();
		searchModel.setKeyWord(query.getCondition(Map.class).get("keyWord").toString());
		List<Object> list = this.getSqlSession().selectList("TSysUser.searchUser", query.getCondition(Map.class));
		searchModel.setList(list);
		searchModel.setType(0);
		return searchModel;

	}

	@Override
	public HashMap<String, Object> loadUserById(Long userId) {
		return getSqlSession().selectOne("TSysUser.loadUserById", userId);
	}

	@Override
	public void createUserMark(UserMarkModel model) {
		// add mark
		SqlSession sqlSession = this.getSqlSession();

		HashMap map = new HashMap();
		map.put("userId", model.getUserId());
		map.put("destUserId", model.getDestUserId());
		List<UserMarkModel> deleteList = new ArrayList<UserMarkModel>();
		List<UserMarkModel> tmpList = sqlSession.selectList("TSysMark.loadUserMarkWithBothUserId", map);
		if (tmpList != null && tmpList.size() > 0) {
			for (UserMarkModel m : tmpList)
				deleteList.add(m);
		}
		if (deleteList != null && deleteList.size() > 0) {
			sqlSession.delete("TSysMark.deleteUserMarkViaMarkId", deleteList);
			sqlSession.flushStatements();
		}
		sqlSession.insert("TSysMark.insertTSysMark", model);
		UserMarkModel m = sqlSession.selectOne("TSysMark.loadTheLimitMark", map);
		sqlSession.flushStatements();
		if (m != null && m.getMarkId() != null) {
			map.put("markId", m.getMarkId());
			sqlSession.selectOne("TSysMark.deleteMarkOverLimit", map);
		}

	}

	public void createBatchUserMark(List<UserMarkModel> olist) {
		// batch操作用batchsqlsession
		SqlSession sqlSession = this.getBatchSqlSession();
		// 目标用户的热度
		HashMap<Long, Integer> destUserCount = new HashMap<Long, Integer>();
		// 去重后的待添加map;
		HashMap<String, UserMarkModel> originMap = new HashMap<String, UserMarkModel>();
		// 待删除的List
		List<UserMarkModel> deleteList = new ArrayList<UserMarkModel>();
		// 去重复
		Collections.reverse(olist);
		for (UserMarkModel m : olist) {
			String key = m.getUserId() + "_" + m.getDestUserId();
			boolean needCheck = false;
			if (!originMap.containsKey(key)) {
				HashMap map = new HashMap();
				map.put("userId", m.getUserId());
				map.put("destUserId", m.getDestUserId());
				List<UserMarkModel> tmpList = sqlSession.selectList("TSysMark.loadUserMarkWithBothUserId", map);
				if (tmpList != null && tmpList.size() > 0) {
					for (UserMarkModel model : tmpList)
						deleteList.add(model);
				}
				originMap.put(key, m);
			}
		}
		// // deleteList
		if (deleteList != null && deleteList.size() > 0) {
			sqlSession.delete("TSysMark.deleteUserMarkViaMarkId", deleteList);
			sqlSession.flushStatements();
		}
		// addList
		List<UserMarkModel> l = new ArrayList<UserMarkModel>(originMap.values());
		if (originMap != null && originMap.values().size() > 0) {
			HashMap map1 = new HashMap();
			map1.put("list", l);
			sqlSession.insert("TSysMark.insertBatchTSysMark", map1);
			sqlSession.flushStatements();
		}
		// over truncate
		for (UserMarkModel model : l) {
			HashMap map = new HashMap();
			map.put("userId", model.getUserId());
			UserMarkModel m = sqlSession.selectOne("TSysMark.loadTheLimitMark", map);
			if (m != null && m.getMarkId() != null) {
				map.put("markId", m.getMarkId());
				sqlSession.selectOne("TSysMark.deleteMarkOverLimit", map);
				sqlSession.flushStatements();
			}
		}
	}

	@Override
	public int getUserCountViaAliasName(String aliasName, Long userId) {
		HashMap map = new HashMap();
		map.put("aliasName", aliasName);
		map.put("userId", userId);
		Integer count = this.getSqlSession().selectOne("TSysUser.getUserCountViaAliasName", map);
		return count;
	}

	@Override
	public void updateUserHeadIcon(String headIcon, Long userId) {
		HashMap map = new HashMap();
		map.put("headIcon", headIcon);
		map.put("userId", userId);
		Integer count = this.getSqlSession().update("TSysUser.updateUserHeadIcon", map);

	}

	@Override
	public void updateUserLocation(TSysUser user) {
		this.getSqlSession().update("TSysUser.updateUserLocation", user);
	}

	@Override
	public List<TImgTag> loadUserPinedTags(QueryModel queryModel) {
		List<TImgTag> list = this.getSqlSession().selectList("TSysUser.loadUserPinedTags", queryModel.getCondition());
		return list;
	}

}