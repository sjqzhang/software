package com.meizu.mshow.user.business;

import java.util.List;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.UserMarkModel;
import com.meizu.mshow.domain.pojo.TSysUser;

public interface UserMarkService {
	// 粉丝，足迹
	public void createUserMark(TSysUser user, UserMarkModel markModel);

	public List<UserMarkModel> loadUserMarkList(QueryModel queryModel);

	public int loadUserHotCount(long userId);

	public List<TSysUser> loadFollowedUser(QueryModel queryModel);
}