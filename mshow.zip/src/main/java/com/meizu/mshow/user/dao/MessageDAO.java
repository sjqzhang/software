package com.meizu.mshow.user.dao;

import java.util.List;

import com.meizu.mshow.domain.model.MessageModel;

public interface MessageDAO {

	public void createBatchMessage(List<MessageModel> msgList);

	public void createMessage(MessageModel model);

	public void deleteMessage(Long messageId);

	public void deleteBatchMessage(List<Long> messageIds);
}