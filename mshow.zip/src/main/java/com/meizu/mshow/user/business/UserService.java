package com.meizu.mshow.user.business;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.SearchModel;
import com.meizu.mshow.domain.model.UserModel;
import com.meizu.mshow.domain.pojo.TImgTag;
import com.meizu.mshow.domain.pojo.TSysUser;

public interface UserService {
	// 创建用户
	public void createUser(UserModel userModel);

	// 修改用户
	public void updateUser(UserModel userModel);

	// 通过用户Id查用户
	public UserModel loadUserViaUserId(Long userId);

	// 查询用户
	public SearchModel searchUser(QueryModel keyword);

	// 修改头像
	public void updateUserHeadIcon(MultipartFile multipartFile, UserModel userModel);

	// 更新位置
	public void updateUserLocation(TSysUser user);

	// 加载用户贴过的标签
	public List<TImgTag> loadUserPinedTags(QueryModel queryModel);

}