package com.meizu.mshow.user.dao;

import java.util.HashMap;
import java.util.List;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.SearchModel;
import com.meizu.mshow.domain.model.UserMarkModel;
import com.meizu.mshow.domain.model.UserModel;
import com.meizu.mshow.domain.pojo.TImgTag;
import com.meizu.mshow.domain.pojo.TSysUser;

public interface UserDAO {
	public void createUser(UserModel userModel);

	public void updateUser(TSysUser user);

	public void deleteUserViaUserId(Long userId);

	public UserModel loadUserViaUserId(Long userId);

	public SearchModel searchUser(QueryModel keyword);

	/**
	 * 
	 * <b>创建人：</b>张军强<br/>
	 * getUserById<br/>
	 * <b>方法描述：按用户Ｉｄ查用户信息</b> <br/>
	 * 
	 * @param userId
	 * @return
	 * @throws RuntimeException
	 *             HashMap<String,Object>
	 * @exception
	 * @since 1.0.0
	 */
	public HashMap<String, Object> loadUserById(Long userId);

	public void createUserMark(UserMarkModel model);

	// 批量添加足迹
	public void createBatchUserMark(List<UserMarkModel> list);

	public int getUserCountViaAliasName(String aliasName, Long userId);

	// 更新头像
	public void updateUserHeadIcon(String string, Long userId);

	public void updateUserLocation(TSysUser user);

	// 加载用户贴过的标签
	public List<TImgTag> loadUserPinedTags(QueryModel queryModel);

}