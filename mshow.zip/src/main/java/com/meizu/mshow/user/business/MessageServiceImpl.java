package com.meizu.mshow.user.business;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.MessageModel;
import com.meizu.mshow.timer.QueueFollow;
import com.meizu.mshow.user.cache.MessageCacheService;
import com.meizu.mshow.user.dao.MessageDAO;

@Service("messageService")
public class MessageServiceImpl implements MessageService {

	private static final Logger logger = Logger.getLogger(MessageServiceImpl.class);
	@Autowired
	@Qualifier("messageCacheService")
	private MessageCacheService messageCacheService;

	@Autowired
	@Qualifier("messageDAO")
	private MessageDAO messageDAO;

	@Override
	public void createMessage(MessageModel model) {
		Long messageId = this.messageCacheService.getNewMessageId();
		model.setMessageId(messageId);
		this.messageCacheService.createMessage(model);
		this.messageCacheService.increaseNewMessageCount(model.getDestUserId());
		this.messageCacheService.truncateMessageOverMax(model.getDestUserId());
		if (!QueueFollow.isInactive()) {
			QueueFollow.getInstance().add(model);
		} else {
			messageDAO.createMessage(model);
		}
	}

	@Override
	public List<MessageModel> loadMessageList(QueryModel model) {
		List<MessageModel> list = this.messageCacheService.loadMessageList(model);
		Long userId = Long.parseLong(model.getCondition(Map.class).get("userId").toString());
		this.messageCacheService.resetNewMeesageCount(userId);
		return list;
	}

	@Override
	public void deleteMessage(Long userId, Long messageId) {
		this.messageCacheService.deleteMessage(userId, messageId);
		if (!QueueFollow.isInactive()) {
			MessageModel model = new MessageModel();
			// Duplicate entry '844' for key 'PRIMARY'.目前还不清楚产生的原因。
			model.setUserId(null);
			model.setMessageId(messageId);
			QueueFollow.getInstance().add(model);
		} else {
			messageDAO.deleteMessage(messageId);
		}
	}

	@Override
	public int loadNewMessageCount(Long userId) {
		int count = this.messageCacheService.loadNewMessageCount(userId);
		return count;
	}

	@Override
	public Integer loadUserMessageTotalCount(long userId) {
		int count = this.messageCacheService.loadUserMessageTotalCount(userId);
		return count;
	}
}