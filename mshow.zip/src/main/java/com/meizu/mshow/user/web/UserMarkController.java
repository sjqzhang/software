package com.meizu.mshow.user.web;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.meizu.mshow.common.base.BaseController;
import com.meizu.mshow.common.base.BaseResultModel;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.security.SecurityAnnotation;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.UserMarkModel;
import com.meizu.mshow.user.business.UserMarkService;
import com.meizu.mshow.user.business.UserService;

@RequestMapping(value = "/browser")
@Controller
public class UserMarkController extends BaseController {
	@Autowired
	@Qualifier("userMarkService")
	private UserMarkService userMarkService;

	@Autowired
	@Qualifier("userService")
	private UserService userService;

	@RequestMapping(value = "/user/showmark")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel loadUserMarkList(HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		QueryModel queryModel = this.loadQueryModel(request);
		queryModel.getCondition(Map.class).put("userId", this.getUserId(request));
		List<UserMarkModel> list = this.userMarkService.loadUserMarkList(queryModel);
		model.setReturnValue(list);
		return model;
	}

	@RequestMapping(value = "/user/hotcount")
	public @ResponseBody
	BaseResultModel loadUserHotCount(@RequestParam("userId") Long userId, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		this.userMarkService.loadUserHotCount(userId);
		return model;
	}

	@RequestMapping(value = "/user/followed")
	public @ResponseBody
	BaseResultModel loadUserFollowed(@RequestParam("userId") Long userId, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		QueryModel queryModel = this.loadQueryModel(request);
		queryModel.getCondition(Map.class).put("userId", userId);
		String cdate = request.getParameter("cdate");
		if (cdate != null && !cdate.equals(""))
			queryModel.getCondition(Map.class).put("cdate", cdate);
		List list = this.userMarkService.loadFollowedUser(queryModel);
		model.setReturnValue(list);
		return model;
	}
}