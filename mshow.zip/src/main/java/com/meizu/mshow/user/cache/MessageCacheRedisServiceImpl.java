package com.meizu.mshow.user.cache;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.alibaba.fastjson.JSONObject;
import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.cache.RedisUtil;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.exception.ErrorCode;
import com.meizu.mshow.common.util.CacheKeyUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.MessageModel;

@Repository("messageCacheService")
public class MessageCacheRedisServiceImpl implements MessageCacheService {

	private static final Logger logger = Logger.getLogger(MessageCacheRedisServiceImpl.class);

	@Override
	public long getNewMessageId() {
		RedisUtil ru = new RedisUtil();
		long id = ru.increase(CacheKeyUtil.getMessageIdKey());
		return id;
	}

	@Override
	public void createMessage(MessageModel model) {
		RedisUtil ru = new RedisUtil();
		// create entity
		String json = JSONObject.toJSONString(model);
		ru.setString(CacheKeyUtil.getMessageKey(model.getMessageId()), json);
		// add to box
		String userMessageBoxKey = CacheKeyUtil.getUserMessageBoxKey(model.getDestUserId());
		ru.zadd(userMessageBoxKey, model.getMessageId() * 1.0, model.getMessageId() + "", -1);
	}

	@Override
	public long increaseNewMessageCount(Long userId) {
		RedisUtil ru = new RedisUtil();
		return ru.increase(CacheKeyUtil.getUserMessageCountKey(userId));
	}

	@Override
	public List<MessageModel> loadMessageList(QueryModel model) {
		List<MessageModel> retList = null;
		try {
			RedisUtil ru = new RedisUtil();
			Map map = model.getCondition(Map.class);
			Long userId = Long.parseLong(map.get("userId").toString());
			long posId = Long.MAX_VALUE;
			if (map.containsKey("posId")) {
				posId = Long.parseLong(map.get("posId").toString());
			}
			Set<String> keylist = null;
			List<String> keys = null;
			if (model.getPageForward() != null && model.getPageForward().equalsIgnoreCase(model.ORDER_BY_DESC)) {
				keylist = ru.zrevrangebyscore(CacheKeyUtil.getUserMessageBoxKey(userId), model.getStart(), model.getLimit(), posId - 0.01, 0);
				keys = new ArrayList<String>(keylist);

			} else if (model.getPageForward() != null && model.getPageForward().equalsIgnoreCase(model.ORDER_BY_ASC)) {
				if (!map.containsKey("posId")) {
					posId = 0;
				}
				keylist = ru.zrangebyscore(CacheKeyUtil.getUserMessageBoxKey(userId), model.getStart(), model.getLimit(), Double.MAX_VALUE, posId + 0.01);
				keys = new ArrayList<String>(keylist);
			}
			if (keylist.size() > 0) {
				List<String> list = ru.batchGetString(keys, CacheKeyUtil.MESSAGE);
				retList = new ArrayList<MessageModel>();
				int i = 0;
				Long messageId = -1L;
				for (Iterator<String> iter = list.iterator(); iter.hasNext(); i++) {
					messageId = Long.parseLong(keys.get(i).toString());
					String json = iter.next();
					MessageModel messageModel = null;
					if (json != null && !json.equals("")) {
						try {
							messageModel = JSONObject.parseObject(json, MessageModel.class);
						} catch (Exception e) {
							messageModel = new MessageModel();
							logger.warn("parse message error:" + messageId);
						}
					} else {
						messageModel = new MessageModel();
						messageModel.setMessageId(messageId);
					}
					retList.add(messageModel);
				}
			}
		} catch (Exception e) {
			logger.warn(e.getMessage(), e);
		}
		return retList;
	}

	@Override
	public void resetNewMeesageCount(Long userId) {
		RedisUtil ru = new RedisUtil();
		ru.setString(CacheKeyUtil.getUserMessageCountKey(userId), "0");
	}

	@Override
	public void deleteMessage(Long userId, Long messageId) {
		RedisUtil ru = new RedisUtil();
		String memebers[] = new String[] { messageId + "" };
		String json = ru.getString(CacheKeyUtil.getMessageKey(messageId));
		if (json != null && !json.equals("")) {
			MessageModel model = JSONObject.parseObject(json, MessageModel.class);
			if (model.getDestUserId().longValue() == userId.longValue()) {
				ru.zrem(CacheKeyUtil.getUserMessageBoxKey(userId), memebers);
				ru.expire(CacheKeyUtil.getMessageKey(messageId), 0);
			} else {
				throw new ApplicationException(ErrorCode.USER_MESSAGE_ILLEAGAL);
			}
		}
	}

	@Override
	public int loadNewMessageCount(Long userId) {
		RedisUtil ru = new RedisUtil();
		String strCount = ru.getString(CacheKeyUtil.getUserMessageCountKey(userId));
		int count = 0;
		if (strCount != null && !strCount.equals("")) {
			count = Integer.parseInt(strCount);
		}
		return count;
	}

	@Override
	public int loadUserMessageTotalCount(long userId) {
		RedisUtil ru = new RedisUtil();
		int count = (int) ru.zcount(CacheKeyUtil.getUserMessageBoxKey(userId), 0, Double.MAX_VALUE);
		return count;
	}

	@Override
	public void truncateMessageOverMax(long userId) {
		RedisUtil ru = new RedisUtil();
		Set<String> keylist = null;
		int count = (int) ru.zcount(CacheKeyUtil.getUserMessageBoxKey(userId), 0, Double.MAX_VALUE);
		List<String> members = new ArrayList<String>();
		if (count > BusinessConstants.MESSAGE_MAX_COUNT) {
			keylist = ru.zrevrangebyscore(CacheKeyUtil.getUserMessageBoxKey(userId), 0, count, Double.MAX_VALUE, 0.0);
			List<String> list = new ArrayList<String>(keylist);
			for (int i = count - 1; i >= BusinessConstants.MESSAGE_MAX_COUNT; i--) {
				long messageId = Long.parseLong(list.get(i));
				members.add(messageId + "");
				ru.expire(CacheKeyUtil.getMessageKey(messageId), 0);
			}
			ru.zrem(CacheKeyUtil.getUserMessageBoxKey(userId), members.toArray(new String[0]));
		}

	}
}
