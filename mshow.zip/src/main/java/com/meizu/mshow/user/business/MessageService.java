package com.meizu.mshow.user.business;

import java.util.List;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.MessageModel;

public interface MessageService {
	// 创建一个消息
	public void createMessage(MessageModel model);

	// 取某用户的消息列表
	public List<MessageModel> loadMessageList(QueryModel model);

	// 删除消息
	public void deleteMessage(Long userId, Long messageId);

	// 加载消息数
	public int loadNewMessageCount(Long userId);

	// 加载消息总数
	public Integer loadUserMessageTotalCount(long userId);
}