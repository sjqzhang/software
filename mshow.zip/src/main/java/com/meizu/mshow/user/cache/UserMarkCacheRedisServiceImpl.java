package com.meizu.mshow.user.cache;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.alibaba.fastjson.JSONObject;
import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.cache.RedisUtil;
import com.meizu.mshow.common.util.CacheKeyUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.UserMarkModel;
import com.meizu.mshow.domain.pojo.TSysUser;

@Repository("userMarkCacheService")
public class UserMarkCacheRedisServiceImpl implements UserMarkCacheService {
	private static final Logger logger = Logger.getLogger(UserMarkCacheRedisServiceImpl.class);

	@Override
	public long getUserMarkId() {

		RedisUtil ru = new RedisUtil();
		long id = ru.increase(CacheKeyUtil.getUserMarkIdKey());
		return id;
	}

	@Override
	public void createUserMark(UserMarkModel userMark) {
		RedisUtil ru = new RedisUtil();
		String json = JSONObject.toJSONString(userMark);
		ru.setString(CacheKeyUtil.getUserMarkKey(userMark.getUserId(), userMark.getDestUserId()), json);

		String userMarkSetKey = CacheKeyUtil.getUserMarkSetKey(userMark.getUserId());
		ru.zadd(userMarkSetKey, userMark.getMarkId() * 1.0, userMark.getDestUserId() + "", -1);

	}

	@Override
	public void createUserFollow(TSysUser user, long userId) {
		RedisUtil ru = new RedisUtil();
		String json = JSONObject.toJSONString(user);
		ru.setString(CacheKeyUtil.getUserFollowKey(userId, user.getUserId()), json);

		String userFollowSetKey = CacheKeyUtil.getUserFollowSetKey(userId);
		ru.zadd(userFollowSetKey, user.getCdate(), user.getUserId() + "", -1);

	}

	@Override
	public void truncateOverMax(long userId) {
		RedisUtil ru = new RedisUtil();
		Set<String> keylist = null;
		int count = (int) ru.zcount(CacheKeyUtil.getUserMarkSetKey(userId), 0, Double.MAX_VALUE);
		List<String> members = new ArrayList<String>();
		if (count > BusinessConstants.MARK_MAX_COUNT) {
			keylist = ru.zrevrangebyscore(CacheKeyUtil.getUserMarkSetKey(userId), 0, count, Double.MAX_VALUE, 0.0);
			List<String> list = new ArrayList<String>(keylist);
			for (int i = count - 1; i >= BusinessConstants.MARK_MAX_COUNT; i--) {
				long destUserId = Long.parseLong(list.get(i));
				members.add(destUserId + "");
				String json = ru.getString(CacheKeyUtil.getUserMarkKey(userId, destUserId));
				UserMarkModel model = JSONObject.parseObject(json, UserMarkModel.class);
				String[] temp = { userId + "" };
				ru.zrem(CacheKeyUtil.getUserFollowSetKey(model.getDestUserId()), temp);
				ru.expire(CacheKeyUtil.getUserFollowKey(destUserId, userId), 0);
				ru.expire(CacheKeyUtil.getUserMarkKey(userId, destUserId), 0);
			}
			ru.zrem(CacheKeyUtil.getUserMarkSetKey(userId), members.toArray(new String[0]));

		}

	}

	@Override
	public List<UserMarkModel> loadUserMarkList(QueryModel model) {
		List<UserMarkModel> retList = null;
		try {
			RedisUtil ru = new RedisUtil();
			Map map = model.getCondition(Map.class);
			Long userId = Long.parseLong(map.get("userId").toString());
			long posId = Long.MAX_VALUE;
			if (map.containsKey("posId")) {
				posId = Long.parseLong(map.get("posId").toString());
			}
			Set<String> keylist = null;
			List<String> keys = null;
			keylist = ru.zrevrangebyscore(CacheKeyUtil.getUserMarkSetKey(userId), 0, model.getLimit() - 1, posId, 0);
			keys = new ArrayList<String>();
			for (String destUserId : keylist) {
				Long lngDestUserId = Long.parseLong(destUserId);
				keys.add(CacheKeyUtil.getUserMarkKey(userId, lngDestUserId));
			}
			if (keylist.size() > 0) {
				List<String> list = ru.batchGetString(keys);
				retList = new ArrayList<UserMarkModel>();
				int i = 0;
				Long markId = -1L;
				for (Iterator<String> iter = list.iterator(); iter.hasNext(); i++) {
					markId = Long.parseLong(keylist.toArray()[i].toString());
					String json = iter.next();
					UserMarkModel userMarkModel = null;
					if (json != null && !json.equals("")) {
						try {
							userMarkModel = JSONObject.parseObject(json, UserMarkModel.class);
						} catch (Exception e) {
							userMarkModel = new UserMarkModel();
							logger.warn("parse message error:" + markId);
						}
					} else {
						userMarkModel = new UserMarkModel();
						userMarkModel.setMarkId(markId);
					}
					retList.add(userMarkModel);
				}
			}
		} catch (Exception e) {
			logger.warn(e.getMessage(), e);
		}
		return retList;
	}

	@Override
	public int loadUserHotCount(long userId) {
		RedisUtil ru = new RedisUtil();
		int count = (int) ru.zcount(CacheKeyUtil.getUserFollowSetKey(userId), 0, Double.MAX_VALUE);
		return count;
	}

	@Override
	public List<TSysUser> loadFollowedUser(QueryModel model) {
		List<TSysUser> retList = null;
		try {
			RedisUtil ru = new RedisUtil();
			Map map = model.getCondition(Map.class);
			Long userId = Long.parseLong(map.get("userId").toString());
			long cdate = Long.MAX_VALUE;
			if (map.containsKey("cdate")) {
				cdate = Long.parseLong(map.get("cdate").toString());
			}
			Set<String> keylist = null;
			List<String> keys = new ArrayList<String>();

			if (model.getPageForward() != null && model.getPageForward().equalsIgnoreCase(model.ORDER_BY_DESC)) {
				keylist = ru.zrevrangebyscore(CacheKeyUtil.getUserFollowSetKey(userId), model.getStart(), model.getLimit(), cdate - 0.01, 0);

			} else if (model.getPageForward() != null && model.getPageForward().equalsIgnoreCase(model.ORDER_BY_ASC)) {
				if (!map.containsKey("cdate")) {
					cdate = 0;
				}
				keylist = ru.zrangebyscore(CacheKeyUtil.getUserFollowSetKey(userId), model.getStart(), model.getLimit(), Double.MAX_VALUE, cdate + 0.01);
			}

			List<Long> tmpIds = new ArrayList<Long>();
			for (String followUserId : keylist) {
				long sourceUserId = Long.parseLong(followUserId);
				tmpIds.add(sourceUserId);
				keys.add(CacheKeyUtil.getUserFollowKey(userId, sourceUserId));
			}
			if (keylist.size() > 0) {
				List<String> list = ru.batchGetString(keys);
				retList = new ArrayList<TSysUser>();
				int i = 0;
				for (Iterator<String> iter = list.iterator(); iter.hasNext(); i++) {
					String json = iter.next();
					TSysUser user = null;
					if (json != null && !json.equals("")) {
						try {
							user = JSONObject.parseObject(json, TSysUser.class);
						} catch (Exception e) {
							user = new TSysUser();
							user.setUserId(tmpIds.get(i));
						}
					} else {
						user = new TSysUser();
						user.setUserId(tmpIds.get(i));
					}
					retList.add(user);
				}
			}
		} catch (Exception e) {
			logger.warn(e.getMessage(), e);
		}
		return retList;
	}
}
