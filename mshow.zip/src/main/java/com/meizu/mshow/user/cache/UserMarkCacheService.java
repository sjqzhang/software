package com.meizu.mshow.user.cache;

import java.util.List;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.UserMarkModel;
import com.meizu.mshow.domain.pojo.TSysUser;

public interface UserMarkCacheService {
	// 生成一个id,从redis计数器里取
	public long getUserMarkId();

	// 创建一个足迹
	public void createUserMark(UserMarkModel userMark);

	// 创建一个userId的粉丝
	public void createUserFollow(TSysUser user, long userId);

	public void truncateOverMax(long userId);

	// 取用户足迹
	public List<UserMarkModel> loadUserMarkList(QueryModel queryModel);

	// 热度
	public int loadUserHotCount(long userId);

	// 取用户的关注用户列表
	public List<TSysUser> loadFollowedUser(QueryModel queryModel);
}