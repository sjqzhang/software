package com.meizu.mshow.user.web;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.meizu.mshow.common.base.BaseController;
import com.meizu.mshow.common.base.BaseResultModel;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.exception.Error;
import com.meizu.mshow.common.security.SecurityAnnotation;
import com.meizu.mshow.common.util.BadWordsUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.common.util.StringUtil;
import com.meizu.mshow.domain.form.UserForm;
import com.meizu.mshow.domain.model.UserModel;
import com.meizu.mshow.system.business.SystemService;
import com.meizu.mshow.user.business.UserMarkService;
import com.meizu.mshow.user.business.UserService;

@RequestMapping(value = "/android")
@Controller
public class UserAndroidController extends BaseController {

	private static final Logger logger = Logger.getLogger(UserAndroidController.class);

	@Autowired
	@Qualifier("userService")
	private UserService userService;

	@Autowired
	@Qualifier("systemService")
	private SystemService systemService;

	@Autowired
	@Qualifier("userMarkService")
	private UserMarkService userMarkService;

	@RequestMapping(value = "/user/view")
	public @ResponseBody
	BaseResultModel loadUserViaUserId(@RequestParam("userId") Long userId, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		UserModel user = this.userService.loadUserViaUserId(userId);
		BaseResultModel model = new BaseResultModel();
		int hotCount = userMarkService.loadUserHotCount(userId);
		user.getUser().setHotCount(hotCount);
		model.setReturnValue(user);
		return model;
	}

	@RequestMapping(value = "/user/self")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel loadUserViaSelf(HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		UserModel user = this.userService.loadUserViaUserId(this.getUserId(request));
		BaseResultModel model = new BaseResultModel();
		int hotCount = userMarkService.loadUserHotCount(this.getUserId(request));
		user.getUser().setHotCount(hotCount);
		model.setReturnValue(user);
		return model;
	}

	@RequestMapping(value = "/user/modify")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel modifyUser(@ModelAttribute("userForm") UserForm userForm, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		UserModel model = this.userService.loadUserViaUserId(this.getUserId(request));
		if (userForm.getComment() != null && !userForm.getComment().trim().equals("")) {
			userForm.setComment(BadWordsUtil.replaceBadwords(userForm.getComment()));
		}
		model.getUser().setComment(userForm.getComment());
		model.getUser().setAliasName(userForm.getAliasName());
		if (StringUtil.illegalChar(userForm.getComment())) {
			throw new ApplicationException(Error.SECURITY_ILLEGALCHAR);
		}
		this.userService.updateUser(model);
		BaseResultModel m = new BaseResultModel();
		return m;
	}

	@RequestMapping(value = "/user/headicon")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel modifyUserHeadIcon(HttpServletRequest hrequest, HttpServletResponse response) throws ApplicationException, IOException {
		String reset = hrequest.getParameter("reset");
		UserModel umodel = this.userService.loadUserViaUserId(this.getUserId(hrequest));
		if (reset != null) {
			this.userService.updateUserHeadIcon(null, umodel);
		} else {
			MultipartHttpServletRequest request = (MultipartHttpServletRequest) hrequest;
			List<MultipartFile> files = request.getFiles("file");
			if (files.size() > 0) {
				this.userService.updateUserHeadIcon(files.get(0), umodel);
			}
		}
		BaseResultModel model = new BaseResultModel();
		return model;
	}

	@RequestMapping(value = "/user/tomodifyuser")
	public String toModify(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return "/web/user/user.html";
	}

	@RequestMapping(value = "/user/pinedtags")
	public @ResponseBody
	BaseResultModel loadUserPinedTags(@RequestParam("userId") Long userId, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		QueryModel queryModel = this.loadQueryModel(request);
		queryModel.getCondition(Map.class).put("userId", userId);
		List list = this.userService.loadUserPinedTags(queryModel);
		model.setReturnValue(list);
		return model;
	}

}