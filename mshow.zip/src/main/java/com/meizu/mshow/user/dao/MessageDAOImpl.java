package com.meizu.mshow.user.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.meizu.mshow.common.base.BaseDao;
import com.meizu.mshow.domain.model.MessageModel;

@Repository("messageDAO")
public class MessageDAOImpl extends BaseDao implements MessageDAO {

	Logger logger = Logger.getLogger(MessageDAOImpl.class);

	@Override
	public void createBatchMessage(List<MessageModel> msgList) {
		SqlSession sqlSession = this.getSqlSession();
		HashMap map = new HashMap();
		map.put("list", msgList);
		sqlSession.insert("TSysMessage.createBatchMessage", map);
	}

	@Override
	public void createMessage(MessageModel model) {
		SqlSession sqlSession = this.getSqlSession();
		sqlSession.insert("TSysMessage.createMessage", model);
	}

	@Override
	public void deleteMessage(Long messageId) {
		SqlSession sqlSession = this.getSqlSession();
		HashMap map = new HashMap();
		map.put("messageId", messageId);
		sqlSession.delete("TSysMessage.deleteMessageViaMessageId", map);
	}

	@Override
	public void deleteBatchMessage(List<Long> messageIds) {
		SqlSession sqlSession = this.getSqlSession();
		HashMap map = new HashMap();
		map.put("list", messageIds);
		sqlSession.delete("TSysMessage.deleteBatchMessage", map);

	}

}