package com.meizu.mshow.picture.business;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONObject;
import com.meizu.mshow.common.ApplicationConfig;
import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.cache.DBCache;
import com.meizu.mshow.common.cache.DBCacheOperation;
import com.meizu.mshow.common.cache.RedisUtil;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.exception.Error;
import com.meizu.mshow.common.util.BeanUtils;
import com.meizu.mshow.common.util.CacheKeyUtil;
import com.meizu.mshow.common.util.ImageUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.form.TImgBreakpoint;
import com.meizu.mshow.domain.model.CompressPictureModel;
import com.meizu.mshow.domain.model.PictureInCacheModel;
import com.meizu.mshow.domain.model.PictureModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;
import com.meizu.mshow.domain.model.SearchModel;
import com.meizu.mshow.domain.model.UnLikeModel;
import com.meizu.mshow.domain.pojo.TImgComment;
import com.meizu.mshow.domain.pojo.TImgComplain;
import com.meizu.mshow.domain.pojo.TImgLike;
import com.meizu.mshow.domain.pojo.TImgPicture;
import com.meizu.mshow.domain.pojo.TImgTag;
import com.meizu.mshow.domain.pojo.TImgViewlog;
import com.meizu.mshow.picture.cache.CacheService;
import com.meizu.mshow.picture.dao.PictureDAO;
import com.meizu.mshow.timer.QueueLikeCommentTag;
import com.meizu.mshow.timer.QueueLog;

@Service("pictureService")
public class PictureServiceImpl implements PictureService {

	Logger logger = Logger.getLogger(PictureServiceImpl.class);

	@Autowired
	@Qualifier("pictureDAO")
	private PictureDAO pictureDAO;

	@Autowired
	private CacheService cacheService;

	@Override
	public TImgPicture loadPictureViaImgId(Long imgId) {
		PictureInCacheModel picture = this.cacheService.loadPictureInCacheModelViaImgId(imgId);
		if (picture != null && picture.getPicture() != null) {
			return picture.getPicture();
		} else {
			TImgPicture p = this.pictureDAO.loadPictureViaImgId(imgId);
			if (p != null)
				this.cacheService.createPictureInCacheModel(imgId);
			return p;
		}
	}

	@Override
	public void upload(MultipartFile imgFile, PictureModel model, int client) throws ApplicationException {
		CompressPictureModel pm = new CompressPictureModel();
		switch (client) {
		case BusinessConstants.CLIENT_CATEGORY_WEB:
			this.writeFile(imgFile, model, pm);
			this.createWebUpload(model);
			break;
		case BusinessConstants.CLIENT_CATEGORY_PHONE:
			this.writeFile(imgFile, model, pm);
			this.createWebUpload(model);
			break;
		default:
			break;
		}
		if (pm.getPicture() != null) {
			String json = JSONObject.toJSONString(pm);
			RedisUtil.rpush(CacheKeyUtil.getCompressionKey(), json);
		}
	}

	private void createWebUpload(PictureModel model) {
		this.pictureDAO.createPictureModel(model);

	}

	private void writeFile(MultipartFile imgFile, PictureModel model, CompressPictureModel pm) throws ApplicationException {
		TImgPicture picture = model.getPicture();
		String fileName = UUID.randomUUID().toString();
		String extName = ".jpg";
		if (imgFile.getOriginalFilename().lastIndexOf(".") > 0)
			extName = imgFile.getOriginalFilename().substring(imgFile.getOriginalFilename().lastIndexOf("."));
		fileName = fileName + extName;
		String sourceImg = picture.getSourceImg() + "s_" + fileName;
		String middleImg = picture.getMiddleImg() + "mid_" + fileName;
		String minImg = picture.getMinImg() + "min_" + fileName;
		String uploadDir = ApplicationConfig.getInstance().getProperty(BusinessConstants.SYS_UPLOAD_DIR);
		String prefixName = ApplicationConfig.getInstance().getProperty(BusinessConstants.SYS_BASE_URL);
		pm.setDatePath(model.getPicture().getSourceImg());
		pm.setFileName(fileName);

		int read = -1;
		long total = 0;
		byte[] copyBuffer = new byte[BusinessConstants.BUF_SIZE];
		long totalSize = 0;
		try {
			BufferedOutputStream os = null;
			BufferedInputStream in = null;
			File file = new File(uploadDir + sourceImg);
			if (!file.getParentFile().exists())
				file.getParentFile().mkdirs();
			try {
				os = new BufferedOutputStream(new FileOutputStream(file, true));
				in = new BufferedInputStream(imgFile.getInputStream());
				while (true) {
					read = in.read(copyBuffer, 0, copyBuffer.length);
					if (read == -1) {
						break;
					}
					totalSize += read;
					os.write(copyBuffer, 0, read);
					total += read;
				}
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				throw e;
			} finally {
				try {
					if (in != null) {
						in.close();
					}
					if (os != null) {
						os.flush();
						os.close();
					}
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
					throw e;
				} finally {
					in = null;
					os = null;
				}
			}
		} catch (Exception e) {
			throw new ApplicationException(Error.FILE_WRITE_ERROR, null, e);
		}
		picture.setFileSize(total);
		long count = RedisUtil.lcount(CacheKeyUtil.getCompressionKey());
		ImageUtil image = ImageUtil.getInstance(uploadDir + sourceImg);

		if (count >= BusinessConstants.MAX_COMPRESS_SIZE) {
			try {
				picture.setSourceHeight(image.getHeight());
				picture.setSourceWidth(image.getWidth());
				image.resizeForMiddle(BusinessConstants.IMAGE_ZIP_MIDDLE_WIDTH);
				image.saveAs(uploadDir + middleImg);
				picture.setMiddleHeight(image.getHeight());
				picture.setMiddleWidth(image.getWidth());
				image.resizeForSamll(BusinessConstants.IMAGE_ZIP_SMALL_HEIGHT);
				image.saveAs(uploadDir + minImg);
				picture.setMinHeight(image.getHeight());
				picture.setMinWidth(image.getWidth());
				picture.setSourceImg(prefixName + sourceImg);
				picture.setMiddleImg(prefixName + middleImg);
				picture.setMinImg(prefixName + minImg);
			} catch (Exception e) {
				throw new ApplicationException(Error.PICTURE_COMPRESS_FAIL);
			}
		} else {
			picture.setSourceHeight(image.getHeight());
			picture.setSourceWidth(image.getWidth());
			picture.setMiddleHeight(image.getHeight());
			picture.setMiddleWidth(image.getWidth());
			picture.setMinHeight(image.getHeight());
			picture.setMinWidth(image.getWidth());
			picture.setSourceImg(prefixName + sourceImg);
			picture.setMiddleImg(prefixName + sourceImg);
			picture.setMinImg(prefixName + sourceImg);
			pm.setPicture(picture);
		}
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_USERLIKE, key = "#p[0].imgId,#p[0].userId", op = DBCacheOperation.DELETE)
	public void createLike(TImgLike like) {
		if (!QueueLikeCommentTag.isInactive()) {
			QueueLikeCommentTag.getInstance().add(like);
		} else {
			this.pictureDAO.createLike(like);
			this.cacheService.deletePictureInCacheModel(like.getImgId());
		}
	}

	@Override
	public void createComment(TImgComment comment) {
		if (!QueueLikeCommentTag.isInactive()) {
			QueueLikeCommentTag.getInstance().add(comment);
		} else {
			this.pictureDAO.createComment(comment);
			this.cacheService.deletePictureInCacheModel(comment.getImgId());
		}
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_COMMENT, key = "#p[0].condition", ttl = BusinessConstants.CACHE_CATEGORY_SHORT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public List<TImgComment> loadCommentList(QueryModel model) {
		List<TImgComment> retList = this.cacheService.loadCommentList(model);
		if (retList == null || retList.size() == 0)
			retList = this.pictureDAO.loadCommentList(model);
		return retList;
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_SEARCH, key = "#p[0].condition", ttl = BusinessConstants.CACHE_CATEGORY_DEFAULT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public SearchModel searchPicture(QueryModel keyword) {
		return this.pictureDAO.searchPicture(keyword);
	}

	public List<TImgPicture> searchPic(QueryModel keyword) {
		List<Object> list = this.pictureDAO.searchPicture(keyword).getList();
		return BeanUtils.map2Bean(list, TImgPicture.class);
	}

	@DBCache(keyPrefix = CacheKeyUtil.P_SEARCHTAG, key = "#p[0].condition", ttl = BusinessConstants.CACHE_CATEGORY_DEFAULT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public SearchModel searchTag(QueryModel keyword) {
		return this.pictureDAO.searchTag(keyword);
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_USERPOST, key = "#p[0].condition", ttl = BusinessConstants.CACHE_CATEGORY_SHORT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public List<PicturePlazaModel> loadPictureByUserId(QueryModel model) {
		List<PicturePlazaModel> retList = this.pictureDAO.loadPictureByUserId(model);
		loadCommentList(retList);
		return retList;
	}

	private void loadCommentList(List<PicturePlazaModel> list) {
		if (list != null & list.size() > 0) {
			List<Long> tmpImgIds = new ArrayList<Long>();
			for (Iterator<PicturePlazaModel> iter = list.iterator(); iter.hasNext();) {
				tmpImgIds.add(iter.next().getImgId());
			}
			QueryModel model = new QueryModel();
			model.getCondition(Map.class).put("imgIds", tmpImgIds);
			model.setLimit(BusinessConstants.PAGE_PLAZA_LIMIT);
			List<TImgComment> comments = this.pictureDAO.loadCommentListViaImgIds(model);
			HashMap<Long, List<TImgComment>> hcomments = new HashMap<Long, List<TImgComment>>();
			for (Iterator<TImgComment> iter = comments.iterator(); iter.hasNext();) {
				TImgComment comment = iter.next();
				List<TImgComment> lcomments = hcomments.get(comment.getImgId());
				if (lcomments == null) {
					lcomments = new ArrayList<TImgComment>();
					hcomments.put(comment.getImgId(), lcomments);
				}
				if (lcomments.size() < BusinessConstants.PAGE_PLAZA_LIMIT)
					lcomments.add(comment);

			}
			for (Iterator<PicturePlazaModel> iter = list.iterator(); iter.hasNext();) {
				PicturePlazaModel picture = iter.next();
				picture.setComments(hcomments.get(picture.getImgId()));
			}
		}
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_HOT_TAG, key = "#p[0].condition", ttl = BusinessConstants.CACHE_CATEGORY_SHORT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public List<TImgTag> loadTagList(QueryModel model) {
		return this.pictureDAO.loadTagList(model);
	}

	@Override
	public void deletePictureViaImgId(Long imgId) {
		this.pictureDAO.deletePictureViaImgId(imgId);
		this.cacheService.deletePictureInCacheModel(imgId);
	}

	@Override
	public TImgComplain loadComplainViaImgIdAndUserId(Long imgId, Long userId) {
		return this.pictureDAO.loadComplainViaImgIdAndUserId(imgId, userId);
	}

	@Override
	public void createComplain(TImgComplain complain) {
		this.pictureDAO.createComplain(complain);

	}

	@Override
	public List<TImgLike> loadLikeListViaImgId(QueryModel queryModel) {
		return this.pictureDAO.loadLikeListViaImgId(queryModel);
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_IMG_TAG, key = "#p[0].condition", ttl = BusinessConstants.CACHE_CATEGORY_SHORT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public List<TImgTag> loadTagsViaImgId(QueryModel queryModel) {
		return this.pictureDAO.loadTagsViaImgId(queryModel);

	}

	@Override
	public void createViewLog(TImgViewlog log) {
		if (!QueueLog.isInactive()) {
			QueueLog.getInstance().add(log);
		} else {
			this.pictureDAO.createViewLog(log);
		}
	}

	@Override
	public void createTagForImage(TImgTag tag) {
		TImgTag tImgTag = this.pictureDAO.loadTagViaTagName(tag.getTagName());
		if (tImgTag != null) {
			Long tagId = tImgTag.getTagId();
			tag.setTagId(tagId);
		}
		this.pictureDAO.createTagForImage(tag);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.picture.business.PictureService#createBreakpoint(com.
	 * meizu.mshow.domain.form.TImgBreakpoint)
	 */

	@Override
	public void createBreakpoint(TImgBreakpoint breakpoint) {
		this.pictureDAO.createBreakpoint(breakpoint);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.picture.business.PictureService#loadPhotoForMap(com.meizu
	 * .mshow.common.util.QueryModel)
	 */

	@Override
	@DBCache(keyPrefix = "map_", key = "{#p[0].condition}", ttl = 3600)
	public List<HashMap> loadPhotoForMap(QueryModel query) {
		return this.pictureDAO.loadPhotoForMap(query);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.picture.business.PictureService#loadPhotoForMapHot(com
	 * .meizu.mshow.common.util.QueryModel)
	 */

	@Override
	public List<HashMap> loadPhotoForMapHot(QueryModel query) {
		return this.pictureDAO.loadPhotoForMapHot(query);
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_USERLIKE, key = "#p[0].condition", ttl = BusinessConstants.CACHE_CATEGORY_SHORT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public List<PicturePlazaModel> loadLikePictureByUserId(QueryModel model) {
		List<PicturePlazaModel> retList = this.pictureDAO.loadLikePictureByUserId(model);
		loadCommentList(retList);
		return retList;
	}

	@Override
	public boolean validateTagName(String tagName) {
		String regEx = "^[0-9a-zA-Z\\u4e00-\\u9fa5]{1,20}+$";
		Pattern p = Pattern.compile(regEx);
		Matcher m = p.matcher(tagName);
		return m.find();
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_USERLIKE, key = "#p[0],#p[1]", op = DBCacheOperation.SELECT)
	public TImgLike loadLikeViaImgIdAndUserId(long imgId, long userId) {
		TImgLike like = this.pictureDAO.loadLikeViaImgIdAndUserId(imgId, userId);
		return like;
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_USERLIKE, key = "#p[0],#p[1]", op = DBCacheOperation.DELETE)
	public void deleteLikeViaImgIdAndUserId(Long imgId, long userId) {
		if (!QueueLikeCommentTag.isInactive()) {
			UnLikeModel like = new UnLikeModel();
			like.setImgId(imgId);
			like.setUserId(userId);
			QueueLikeCommentTag.getInstance().add(like);
		} else {
			this.cacheService.deletePictureInCacheModel(imgId);
			this.pictureDAO.deleteLikeViaImgIdAndUserId(imgId, userId);
		}
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_COMMENT, key = "#p[0]", ttl = BusinessConstants.CACHE_CATEGORY_SHORT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public TImgComment loadCommentViaCommentId(Long commentId) {
		return this.pictureDAO.loadCommentViaCommentId(commentId);
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_COMMENT, key = "#p[0]", op = DBCacheOperation.DELETE)
	public void deleteComment(TImgComment comment) {
		if (!QueueLikeCommentTag.isInactive()) {
			QueueLikeCommentTag.getInstance().add(comment);
		} else {
			this.pictureDAO.deleteComment(comment);
		}
	}

}