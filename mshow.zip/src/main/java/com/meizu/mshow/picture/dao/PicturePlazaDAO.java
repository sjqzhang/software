package com.meizu.mshow.picture.dao;

import java.util.List;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;

public interface PicturePlazaDAO {
	//
	public List<PicturePlazaModel> loadHot(QueryModel queryModel);

	public List<PicturePlazaModel> loadNew(QueryModel queryModel);

	public List<PicturePlazaModel> loadTagImage(QueryModel queryModel);

	public List<PicturePlazaModel> loadImgViaCity(QueryModel queryModel);

}