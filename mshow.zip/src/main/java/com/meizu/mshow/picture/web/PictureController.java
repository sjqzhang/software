package com.meizu.mshow.picture.web;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.base.BaseController;
import com.meizu.mshow.common.base.BaseResultModel;
import com.meizu.mshow.common.cache.RedisUtil;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.exception.Error;
import com.meizu.mshow.common.exception.ErrorCode;
import com.meizu.mshow.common.security.SecurityAnnotation;
import com.meizu.mshow.common.util.BadWordsUtil;
import com.meizu.mshow.common.util.CacheKeyUtil;
import com.meizu.mshow.common.util.DateUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.common.util.StringUtil;
import com.meizu.mshow.domain.form.CommentForm;
import com.meizu.mshow.domain.form.LikeForm;
import com.meizu.mshow.domain.form.PreUpload;
import com.meizu.mshow.domain.form.TImgBreakpoint;
import com.meizu.mshow.domain.form.UploadForm;
import com.meizu.mshow.domain.model.MessageModel;
import com.meizu.mshow.domain.model.PictureModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;
import com.meizu.mshow.domain.model.UserMarkModel;
import com.meizu.mshow.domain.model.UserModel;
import com.meizu.mshow.domain.pojo.TBsArea;
import com.meizu.mshow.domain.pojo.TImgComment;
import com.meizu.mshow.domain.pojo.TImgComplain;
import com.meizu.mshow.domain.pojo.TImgLike;
import com.meizu.mshow.domain.pojo.TImgPicture;
import com.meizu.mshow.domain.pojo.TImgTag;
import com.meizu.mshow.domain.pojo.TImgViewlog;
import com.meizu.mshow.domain.pojo.TSysUser;
import com.meizu.mshow.picture.business.PictureService;
import com.meizu.mshow.system.business.SystemService;
import com.meizu.mshow.user.business.MessageService;
import com.meizu.mshow.user.business.UserMarkService;
import com.meizu.mshow.user.business.UserService;

@Controller
@RequestMapping(value = "/browser")
public class PictureController extends BaseController {

	private static final Logger logger = Logger.getLogger(PictureController.class);

	@Autowired
	@Qualifier("userMarkService")
	private UserMarkService userMarkService;

	@Autowired
	@Qualifier("pictureService")
	private PictureService pictureService;

	@Autowired
	@Qualifier("userService")
	private UserService userService;

	@Autowired
	@Qualifier("systemService")
	private SystemService systemService;

	@Autowired
	@Qualifier("messageService")
	private MessageService messageService;

	@RequestMapping(value = "/photo/view")
	public @ResponseBody
	BaseResultModel viewPhoto(@RequestParam("imgId") Long imgId, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		TImgPicture picture = this.pictureService.loadPictureViaImgId(imgId);
		if (picture == null) {
			throw new ApplicationException(Error.PICTURE_NOT_EXIST, null, false);
		}
		if (this.getUserId(request) != -1 && this.getUserId(request) != picture.getUserId().longValue()) {
			try {
				TImgViewlog log = new TImgViewlog();
				log.setCdate((int) (DateUtil.getNow().getTime() / 1000));
				log.setImgId(imgId);
				log.setUserId(this.getUserId(request));
				log.setCookieId("");
				this.pictureService.createViewLog(log);
			} catch (Exception e) {
				// 错了就错了，不影响图片的加载
				logger.error(e.getMessage(), e);
			}
		}
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(picture);
		return model;
	}

	@RequestMapping(value = "/photo/increaselikes")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel addLike(@ModelAttribute("likeForm") LikeForm likeForm, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		// 当前用户
		UserModel userModel = this.userService.loadUserViaUserId(this.getUserId(request));
		TSysUser user = userModel.getUser();
		RedisUtil ru = new RedisUtil();
		TImgPicture picture = this.pictureService.loadPictureViaImgId(likeForm.getImgId());
		if (picture == null) {
			throw new ApplicationException(Error.PICTURE_NOT_EXIST);
		}
		if (picture.getUserId().longValue() == user.getUserId()) {
			throw new ApplicationException(Error.PICTURE_SELF_LIKE);
		}
		if (ru.getString(CacheKeyUtil.getRepeatLikeKey(user.getUserId(), likeForm.getImgId())) != null) {
			throw new ApplicationException(Error.PICTURE_LIKE_REPEAT, null, false);
		}
		TImgLike isLiked = this.pictureService.loadLikeViaImgIdAndUserId(likeForm.getImgId(), user.getUserId());
		if (isLiked == null || isLiked.getStatus() == BusinessConstants.LIKE_STATUS_CANCEL) {
			TImgLike like = new TImgLike();
			like.setIp(this.getRemoteIp(request));
			if (likeForm.getLat() == null && likeForm.getLng() == null) {
				BeanUtils.copyProperties(likeForm, like);
			} else {
				StringUtil.setCity(like.getIp(), like);
				if (like.getCity() != null && !like.getCity().equals("")) {
					TBsArea area = this.systemService.loadTBsAreaViaCityName(like.getCity());
					if (area != null) {
						like.setLng(area.getLng());
						like.setLat(area.getLat());
					}
				}
			}
			like.setCdate((int) (DateUtil.getNow().getTime() / 1000));
			like.setStatus(BusinessConstants.LIKE_STATUS_NORMAL);
			like.setUserId(user.getUserId());
			like.setImgId(likeForm.getImgId());
			this.pictureService.createLike(like);
			try {
				ru.setString(CacheKeyUtil.getRepeatLikeKey(user.getUserId(), likeForm.getImgId()), "-1", BusinessConstants.CACHE_CATEGORY_MINI_EXPIRES_SECOND);
			} catch (Exception e) {
				logger.warn(e.getMessage(), e);
			}
			UserModel destUserModel = this.userService.loadUserViaUserId(picture.getUserId());
			TSysUser destUser = destUserModel.getUser();
			try {
				UserMarkModel markModel = new UserMarkModel();
				markModel.setCategory(BusinessConstants.MARK_CATEGORY_LIKE);
				markModel.setUserId(user.getUserId());
				markModel.setDestUserId(destUser.getUserId());
				markModel.setAliasName(destUser.getAliasName());
				markModel.setHeadIcon(destUser.getHeadIcon());
				markModel.setImgId(likeForm.getImgId());
				markModel.setCdate(like.getCdate());
				this.userMarkService.createUserMark(user, markModel);
			} catch (Exception e) {
				logger.warn(e.getMessage(), e);
			}
			try {
				MessageModel messageModel = new MessageModel();
				messageModel.setAliasName(user.getAliasName());
				messageModel.setCdate(like.getCdate());
				messageModel.setHeadIcon(user.getHeadIcon());
				messageModel.setImgId(like.getImgId());
				messageModel.setMessageCategory(BusinessConstants.MESSAGE_CATEGORY_LIKE);
				messageModel.setMiddleImg(picture.getMiddleImg());
				messageModel.setMinImg(picture.getMinImg());
				messageModel.setSourceImg(picture.getSourceImg());
				messageModel.setDestUserId(picture.getUserId());
				messageModel.setUserId(user.getUserId());
				messageModel.setMinWidth(picture.getMinWidth());
				messageModel.setMinHeight(picture.getMinHeight());
				this.messageService.createMessage(messageModel);
			} catch (Exception e) {
				logger.warn(e.getMessage(), e);
			}
			model.setReturnValue(picture.getLikeCount() + 1);
		}
		return model;
	}

	@RequestMapping(value = "/photo/deletelike")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel deleteLike(@ModelAttribute("likeForm") LikeForm likeForm, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		TImgLike like = this.pictureService.loadLikeViaImgIdAndUserId(likeForm.getImgId(), this.getUserId(request));
		if (like != null && like.getStatus() == BusinessConstants.LIKE_STATUS_NORMAL) {
			this.pictureService.deleteLikeViaImgIdAndUserId(likeForm.getImgId(), this.getUserId(request));
		}
		model.setReturnValue(0);
		return model;
	}

	@RequestMapping(value = "/comments/create")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel addComment(@ModelAttribute("commentForm") CommentForm commentForm, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		String commentMD5 = StringUtil.calcMD5(this.getUserId(request) + commentForm.getImgId() + commentForm.getComment());
		RedisUtil ru = new RedisUtil();
		if (commentForm.getComment() == null || commentForm.getComment().trim().equals("")) {
			throw new ApplicationException(Error.PICTURE_COMMENT_EMPTY, null, false);
		}
		if (commentForm.getComment().trim().length() > BusinessConstants.COMMNENT_MAX_LENGTH) {
			throw new ApplicationException(Error.PICTURE_COMMENT_TOOLONG, null, false);
		}
		if (StringUtil.illegalChar(commentForm.getComment().trim())) {
			throw new ApplicationException(Error.SECURITY_ILLEGALCHAR);
		}
		if (ru.getString(CacheKeyUtil.getRepeatCommentKey(commentMD5)) != null) {
			throw new ApplicationException(Error.PICTURE_COMMENT_REPEAT, null, false);
		}
		TImgPicture picture = this.pictureService.loadPictureViaImgId(commentForm.getImgId());
		if (picture == null) {
			throw new ApplicationException(Error.PICTURE_NOT_EXIST, null, false);
		}
		UserModel userModel = this.userService.loadUserViaUserId(this.getUserId(request));
		TSysUser user = userModel.getUser();
		if ((user.getStatus() & BusinessConstants.USER_STATUS_COMMENT) != BusinessConstants.USER_STATUS_COMMENT) {
			// 木有评论的权限
			throw new ApplicationException(ErrorCode.USER_SECURIY_NOCOMMENT, null, false);
		}
		commentForm.setComment(BadWordsUtil.replaceBadwords(commentForm.getComment()));
		TImgComment comment = new TImgComment();
		BeanUtils.copyProperties(commentForm, comment);
		String ip = this.getRemoteIp(request);
		if (commentForm.getLat() == null || commentForm.getLng() == null) {
			StringUtil.setCity(ip, comment);
			if (comment.getCity() != null && !comment.getCity().equals("")) {
				TBsArea area = this.systemService.loadTBsAreaViaCityName(comment.getCity());
				if (area != null) {
					comment.setLng(area.getLng());
					comment.setLat(area.getLat());
				}
			}
		}
		comment.setRemark(commentForm.getComment());
		comment.setIp(ip);
		comment.setCdate((int) (DateUtil.getNow().getTime() / 1000));
		comment.setStatus(BusinessConstants.COMMENT_STATUS_NEW);
		comment.setUserId(user.getUserId());
		this.pictureService.createComment(comment);
		try {
			ru.setString(CacheKeyUtil.getRepeatCommentKey(commentMD5), commentMD5, BusinessConstants.CACHE_CATEGORY_SHORT_EXPIRES_SECOND);
		} catch (Exception e) {
			logger.warn(e.getMessage(), e);
		}
		// 给足迹
		if (picture.getUserId().longValue() != this.getUserId(request)) {
			UserModel destUserModel = this.userService.loadUserViaUserId(picture.getUserId());
			TSysUser destUser = destUserModel.getUser();
			try {
				UserMarkModel markModel = new UserMarkModel();
				markModel.setCategory(BusinessConstants.MARK_CATEGORY_COMMENT);
				markModel.setUserId(user.getUserId());
				markModel.setDestUserId(destUser.getUserId());
				markModel.setAliasName(destUser.getAliasName());
				markModel.setHeadIcon(destUser.getHeadIcon());
				markModel.setImgId(comment.getImgId());
				markModel.setCdate(comment.getCdate());
				this.userMarkService.createUserMark(user, markModel);
			} catch (Exception e) {
				logger.warn(e.getMessage(), e);
			}
		}
		try {
			MessageModel messageModel = new MessageModel();
			messageModel.setAliasName(user.getAliasName());
			messageModel.setCdate(comment.getCdate());
			messageModel.setComment(comment.getRemark());
			messageModel.setHeadIcon(user.getHeadIcon());
			messageModel.setImgId(comment.getImgId());
			messageModel.setMiddleImg(picture.getMiddleImg());
			messageModel.setMinImg(picture.getMinImg());
			messageModel.setSourceImg(picture.getSourceImg());
			messageModel.setUserId(user.getUserId());
			messageModel.setReplyUserId(commentForm.getReplyUserId());
			messageModel.setMinWidth(picture.getMinWidth());
			messageModel.setMinHeight(picture.getMinHeight());
			if (commentForm.getReplyUserId() != null && commentForm.getReplyUserId().longValue() > 0) {
				UserModel tempModel = this.userService.loadUserViaUserId(commentForm.getReplyUserId());
				messageModel.setReplyAliasName(tempModel.getUser().getAliasName());
			}
			// 给回复人消息,条件不是回复自己，不是回复作者
			if (commentForm.getReplyUserId() != null && commentForm.getReplyUserId().longValue() > 0 && commentForm.getReplyUserId().longValue() != this.getUserId(request) && commentForm.getReplyUserId().longValue() != picture.getUserId().longValue()) {
				messageModel.setDestUserId(commentForm.getReplyUserId());
				messageModel.setMessageCategory(BusinessConstants.MESSAGE_CATEGORY_REPLY);
				this.messageService.createMessage(messageModel);
			}
			// 给发图人消息
			if (picture.getUserId().longValue() != this.getUserId(request)) {
				messageModel.setDestUserId(picture.getUserId());
				messageModel.setMessageCategory(BusinessConstants.MESSAGE_CATEGORY_COMMENT);
				this.messageService.createMessage(messageModel);
			}
		} catch (Exception e) {
			logger.warn(e.getMessage(), e);
		}

		BaseResultModel model = new BaseResultModel();
		return model;
	}

	@RequestMapping(value = "/comments/delete")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel deleteComment(@RequestParam("commentId") Long commentId, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		TImgComment comment = this.pictureService.loadCommentViaCommentId(commentId);
		if (comment != null && comment.getUserId() == this.getUserId(request)) {
			this.pictureService.deleteComment(comment);
		}
		BaseResultModel model = new BaseResultModel();
		return model;
	}

	@RequestMapping(value = "/comments/list")
	public @ResponseBody
	BaseResultModel loadCommentList(@RequestParam("imgId") Long imgId, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		QueryModel queryModel = this.loadQueryModel(request);
		TImgPicture pictureModel = this.pictureService.loadPictureViaImgId(imgId);
		if (pictureModel == null) {
			throw new ApplicationException(Error.PICTURE_NOT_EXIST, null, false);
		}
		queryModel.getCondition(Map.class).put("imgId", imgId);
		String posId = request.getParameter("posId");
		if (request.getParameter("posId") != null && !posId.equals(""))
			queryModel.getCondition(Map.class).put("posId", posId);
		List<TImgComment> list = this.pictureService.loadCommentList(queryModel);
		queryModel.setResult(list);
		model.setReturnValue(list);
		return model;
	}

	@RequestMapping(value = "/photo/precheck")
	public @ResponseBody
	BaseResultModel photoPrecheck(HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		return null;
	}

	@RequestMapping(value = "/photo/preupload")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel preUpload(@ModelAttribute("preUpload") PreUpload preUpload, HttpServletRequest hrequest, HttpServletResponse response) throws ApplicationException, IOException {
		MultipartHttpServletRequest request = (MultipartHttpServletRequest) hrequest;
		List<MultipartFile> files = request.getFiles("file");
		if (files.size() > 0) {
			CommonsMultipartFile com = (CommonsMultipartFile) (files.get(0));
			DiskFileItem it = (DiskFileItem) com.getFileItem();
			TImgBreakpoint tp = new TImgBreakpoint();
			tp.setCdate(new Date().getTime() / 1000);
			tp.setFileSize(it.getSize());
			tp.setFileName(it.getName());
			tp.setUserId(this.getUserId(request));
			tp.setTmpPath(it.getStoreLocation().getAbsolutePath());
			tp.setStatus(0);
			tp.setFingerprint(preUpload.getFingerprint());
			pictureService.createBreakpoint(tp);
		}
		return new BaseResultModel();
	}

	@RequestMapping(value = "/photo/post")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel upload(@ModelAttribute("uploadForm") UploadForm uploadForm, HttpServletRequest hrequest, HttpServletResponse response) throws ApplicationException, IOException {
		MultipartHttpServletRequest request = (MultipartHttpServletRequest) hrequest;
		List<MultipartFile> files = request.getFiles("file");
		UserModel userModel = this.userService.loadUserViaUserId(this.getUserId(request));
		TSysUser user = userModel.getUser();
		if ((user.getStatus() & BusinessConstants.USER_STATUS_UPLOAD) != BusinessConstants.USER_STATUS_UPLOAD) {
			// 木有上传的权限
			throw new ApplicationException(ErrorCode.USER_SECURIY_NOPOST, null, false);
		}
		if (StringUtil.illegalChar(uploadForm.getDesc())) {
			throw new ApplicationException(Error.SECURITY_ILLEGALCHAR);
		}
		if ((uploadForm.getDesc() != null && uploadForm.getDesc().length() > BusinessConstants.UPLOAD_DESC_MAX_LENGTH)) {
			// 描述太长
			throw new ApplicationException(ErrorCode.PICTURE_DESC_TOOLONG, null, false);
		}
		if (files.size() > 0) {
			PictureModel model = new PictureModel();
			TImgPicture picture = new TImgPicture();
			BeanUtils.copyProperties(uploadForm, picture);
			picture.setIp(this.getRemoteIp(request));
			if (uploadForm.getLat() == null || uploadForm.getLng() == null) {
				StringUtil.setCity(picture.getIp(), picture);
				if (picture.getCity() != null && !picture.getCity().equals("")) {
					TBsArea area = this.systemService.loadTBsAreaViaCityName(picture.getCity());
					if (area != null) {
						picture.setLng(area.getLng());
						picture.setLat(area.getLat());
					}
				}
			}
			picture.setUserId(this.getUserId(request));
			if (BadWordsUtil.containBadWords(uploadForm.getDesc())) {
				picture.setStatus(BusinessConstants.PICTURE_STATUS_AUDITING);
			} else {
				picture.setStatus(BusinessConstants.PICTURE_STATUS_NEW);
			}
			Date cdate = DateUtil.getNow();
			picture.setCdate(cdate.getTime() / 1000);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(cdate);
			SimpleDateFormat f = new SimpleDateFormat("yyyy" + BusinessConstants.FILE_SEPARATOR + "MM" + BusinessConstants.FILE_SEPARATOR + "dd" + BusinessConstants.FILE_SEPARATOR + "kk" + BusinessConstants.FILE_SEPARATOR + "mm");
			String p = f.format(cdate);
			StringBuffer path = new StringBuffer().append(p).append(BusinessConstants.FILE_SEPARATOR);
			picture.setSourceImg(path.toString());
			picture.setMiddleImg(path.toString());
			picture.setMinImg(path.toString());
			picture.setUserId(this.getUserId(request));
			picture.setFilterName(uploadForm.getFilterName());
			List<TImgTag> tagList = null;
			HashMap<String, String> mapName = new HashMap<String, String>();
			if (uploadForm.getTag() != null && uploadForm.getTag().length > 0) {
				tagList = new ArrayList<TImgTag>();
				for (int i = 0; i < uploadForm.getTag().length; i++) {
					if (this.pictureService.validateTagName(uploadForm.getTag()[i]) && !mapName.containsKey(uploadForm.getTag()[i])) {
						mapName.put(uploadForm.getTag()[i], uploadForm.getTag()[i]);
						TImgTag tag = new TImgTag();
						tag.setTagName(uploadForm.getTag()[i]);
						tag.setUserId(this.getUserId(request));
						tag.setStatus(BusinessConstants.TAG_STATUS_DEFAULT);
						tagList.add(tag);
					}
				}
			}
			HashMap<Long, Long> mapId = new HashMap<Long, Long>();
			if (uploadForm.getTagId() != null && uploadForm.getTagId().length > 0) {
				if (tagList == null)
					tagList = new ArrayList<TImgTag>();
				for (int i = 0; i < uploadForm.getTagId().length && !mapId.containsKey(uploadForm.getTagId()[i]); i++) {
					mapId.put(uploadForm.getTagId()[i], uploadForm.getTagId()[i]);
					TImgTag tag = new TImgTag();
					tag.setTagId(uploadForm.getTagId()[i]);
					tagList.add(tag);
				}
			}
			model.setPicture(picture);
			model.setTags(tagList);
			MultipartFile file = files.get(0);
			pictureService.upload(file, model, BusinessConstants.CLIENT_CATEGORY_WEB);
		}
		return new BaseResultModel();
	}

	@RequestMapping(value = "/tag/recommand")
	public @ResponseBody
	BaseResultModel loadRecommandTag(HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		QueryModel queryModel = this.loadQueryModel(request);
		queryModel.getCondition(Map.class).put("condition", BusinessConstants.TAG_STATUS_RECOMMAND);
		List<TImgTag> list = this.pictureService.loadTagList(queryModel);
		model.setReturnValue(list);
		return model;
	}

	@RequestMapping(value = "/photo/delete")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel delete(@RequestParam("imgId") Long imgId, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		TImgPicture pictureModel = this.pictureService.loadPictureViaImgId(imgId);
		if (pictureModel != null && pictureModel.getUserId() == this.getUserId(request)) {
			this.pictureService.deletePictureViaImgId(imgId);
		} else {
			throw new ApplicationException(Error.SECURITY_FAIL, null, false);
		}
		return model;
	}

	@RequestMapping(value = "/system/complain")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel complain(@RequestParam("imgId") Long imgId, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		TImgComplain complain = this.pictureService.loadComplainViaImgIdAndUserId(imgId, this.getUserId(request));
		if (complain == null) {
			TImgComplain complain2 = new TImgComplain();
			Date cdate = DateUtil.getNow();
			complain2.setCdate((int) (cdate.getTime() / 1000));
			complain2.setImgId(imgId);
			complain2.setUserId(this.getUserId(request));
			complain2.setStatus(BusinessConstants.COMPLAIN_STATUS_NEW);
			this.pictureService.createComplain(complain2);
		} else {
			throw new ApplicationException(Error.PICTURE_HAS_COMPLAINED);
		}
		return model;
	}

	@RequestMapping(value = "/photo/showpost")
	public @ResponseBody
	BaseResultModel loadPost(@RequestParam("userId") Long userId, HttpServletRequest request, HttpServletResponse response) {
		QueryModel queryModel = this.loadQueryModel(request);
		// 谁的主页
		UserModel userModel = this.userService.loadUserViaUserId(userId);
		if (userModel == null)
			throw new ApplicationException(ErrorCode.USER_NOT_EXIST, null, false);
		TSysUser user = userModel.getUser();
		queryModel.getCondition(Map.class).put("userId", userId);
		String posId = request.getParameter("posId");
		if (request.getParameter("posId") != null && !posId.equals(""))
			queryModel.getCondition(Map.class).put("posId", posId);
		List<PicturePlazaModel> list = this.pictureService.loadPictureByUserId(queryModel);
		if (this.getUserId(request) > 0) {
			for (PicturePlazaModel model : list) {
				TImgLike like = this.pictureService.loadLikeViaImgIdAndUserId(model.getImgId(), this.getUserId(request));
				if (like != null && like.getStatus() == BusinessConstants.LIKE_STATUS_NORMAL)
					model.setLikeStatus(1);
			}
		}
		int cdate = (int) (DateUtil.getNow().getTime() / 1000);
		boolean canVisit = true;
		RedisUtil ru = new RedisUtil();
		String keyMD5 = StringUtil.calcMD5(this.getUserId(request) + "|" + user.getUserId());
		if (ru.getString(keyMD5) != null) {
			canVisit = false;
		}
		if (canVisit && this.getUserId(request) != -1 && this.getUserId(request) != userId.longValue()) {
			// 5分钟以内不作重复访问
			ru.setString(keyMD5, keyMD5, BusinessConstants.CACHE_CATEGORY_DEFAULT_EXPIRES_SECOND);
			try {
				UserMarkModel markModel = new UserMarkModel();
				markModel.setCategory(BusinessConstants.MESSAGE_CATEGORY_VIEW);
				markModel.setUserId(this.getUserId(request));
				markModel.setDestUserId(userId);
				markModel.setImgId(null);
				markModel.setCdate(cdate);
				markModel.setAliasName(user.getAliasName());
				markModel.setHeadIcon(user.getHeadIcon());
				if (this.getUserId(request) != userModel.getUser().getUserId()) {
					UserModel um = this.userService.loadUserViaUserId(this.getUserId(request));
					this.userMarkService.createUserMark(um.getUser(), markModel);
				}
				ru.setString(keyMD5, keyMD5, BusinessConstants.CACHE_CATEGORY_DEFAULT_EXPIRES_SECOND);
			} catch (Exception e) {
				logger.warn(e.getMessage(), e);
			}
		}
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(list);
		return model;
	}

	@RequestMapping(value = "/photo/selfpost")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel loadSelfPost(HttpServletRequest request, HttpServletResponse response) {
		QueryModel queryModel = this.loadQueryModel(request);
		queryModel.getCondition(Map.class).put("userId", this.getUserId(request));
		String posId = request.getParameter("posId");
		if (request.getParameter("posId") != null && !posId.equals(""))
			queryModel.getCondition(Map.class).put("posId", posId);
		List<PicturePlazaModel> list = this.pictureService.loadPictureByUserId(queryModel);
		if (this.getUserId(request) > 0) {
			for (PicturePlazaModel model : list) {
				TImgLike like = this.pictureService.loadLikeViaImgIdAndUserId(model.getImgId(), this.getUserId(request));
				if (like != null && like.getStatus() == BusinessConstants.LIKE_STATUS_NORMAL)
					model.setLikeStatus(1);
			}
		}
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(list);
		return model;
	}

	@RequestMapping(value = "/photo/showlike")
	public @ResponseBody
	BaseResultModel loadLike(@RequestParam("userId") Long userId, HttpServletRequest request, HttpServletResponse response) {
		QueryModel queryModel = this.loadQueryModel(request);
		queryModel.getCondition(Map.class).put("userId", userId);
		String posId = request.getParameter("posId");
		if (request.getParameter("posId") != null && !posId.equals(""))
			queryModel.getCondition(Map.class).put("posId", posId);
		List<PicturePlazaModel> list = this.pictureService.loadLikePictureByUserId(queryModel);
		if (this.getUserId(request) > 0) {
			for (PicturePlazaModel model : list) {
				TImgLike like = this.pictureService.loadLikeViaImgIdAndUserId(model.getImgId(), this.getUserId(request));
				if (like != null && like.getStatus() == BusinessConstants.LIKE_STATUS_NORMAL)
					model.setLikeStatus(1);
			}
		}
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(list);
		return model;
	}

	@RequestMapping(value = "/photo/selflike")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel loadSelfLike(HttpServletRequest request, HttpServletResponse response) {
		QueryModel queryModel = this.loadQueryModel(request);
		queryModel.getCondition(Map.class).put("userId", this.getUserId(request));
		String posId = request.getParameter("posId");
		if (request.getParameter("posId") != null && !posId.equals(""))
			queryModel.getCondition(Map.class).put("posId", posId);
		List<PicturePlazaModel> list = this.pictureService.loadLikePictureByUserId(queryModel);
		if (this.getUserId(request) > 0) {
			for (PicturePlazaModel model : list) {
				TImgLike like = this.pictureService.loadLikeViaImgIdAndUserId(model.getImgId(), this.getUserId(request));
				if (like != null && like.getStatus() == BusinessConstants.LIKE_STATUS_NORMAL)
					model.setLikeStatus(1);
			}
		}
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(list);
		return model;
	}

	@RequestMapping(value = "/photo/likeusers")
	public @ResponseBody
	BaseResultModel loadLikeUser(@RequestParam("imgId") Long imgId, HttpServletRequest request, HttpServletResponse response) {
		QueryModel queryModel = this.loadQueryModel(request);
		queryModel.getCondition(Map.class).put("imgId", imgId);
		List<TImgLike> list = this.pictureService.loadLikeListViaImgId(queryModel);
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(list);
		return model;
	}

	@RequestMapping(value = "/photo/tags")
	public @ResponseBody
	BaseResultModel loadTag(@RequestParam("imgId") Long imgId, HttpServletRequest request, HttpServletResponse response) {
		QueryModel queryModel = this.loadQueryModel(request);
		queryModel.getCondition(Map.class).put("imgId", imgId);
		List<TImgTag> list = this.pictureService.loadTagsViaImgId(queryModel);
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(list);
		return model;
	}

	@RequestMapping(value = "/photo/pintag")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel addTag(@RequestParam("imgId") Long imgId, @RequestParam("tagName") String tagName, HttpServletRequest request, HttpServletResponse response) {
		TImgPicture picture = this.pictureService.loadPictureViaImgId(imgId);
		if (picture == null) {
			throw new ApplicationException(Error.PICTURE_NOT_EXIST, null, false);
		}
		if (!this.pictureService.validateTagName(tagName)) {
			throw new ApplicationException(Error.TAG_NAME_LLEGAL, null, false);
		}
		TImgTag tag = new TImgTag();
		tag.setUserId(this.getUserId(request));
		tag.setTagName(tagName);
		tag.setImgId(imgId);
		this.pictureService.createTagForImage(tag);
		BaseResultModel model = new BaseResultModel();
		return model;
	}

	@RequestMapping(value = "/photo/liked")
	@SecurityAnnotation
	public @ResponseBody
	BaseResultModel isLiked(@RequestParam("imgId") Long imgId, HttpServletRequest request, HttpServletResponse response) {
		TImgPicture picture = this.pictureService.loadPictureViaImgId(imgId);
		if (picture == null) {
			throw new ApplicationException(Error.PICTURE_NOT_EXIST, null, false);
		}
		BaseResultModel model = new BaseResultModel();
		TImgLike like = this.pictureService.loadLikeViaImgIdAndUserId(imgId, this.getUserId(request));
		if (like != null && like.getStatus() == BusinessConstants.LIKE_STATUS_NORMAL)
			model.setReturnValue(1);
		else
			model.setReturnValue(0);
		return model;
	}

	@RequestMapping(value = "/photo/mapview")
	public @ResponseBody
	BaseResultModel loadPhotoForMap(HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		QueryModel query = loadQueryModel(request);
		model.setReturnValue(this.pictureService.loadPhotoForMap(query));
		return model;
	}

	@RequestMapping(value = "/photo/maphot")
	public @ResponseBody
	BaseResultModel loadPhotoForMapHot(HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		QueryModel query = loadQueryModel(request);
		model.setReturnValue(this.pictureService.loadPhotoForMapHot(query));
		return model;
	}

}