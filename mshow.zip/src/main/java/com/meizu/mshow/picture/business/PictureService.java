package com.meizu.mshow.picture.business;

import java.util.HashMap;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.form.TImgBreakpoint;
import com.meizu.mshow.domain.model.PictureModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;
import com.meizu.mshow.domain.model.SearchModel;
import com.meizu.mshow.domain.pojo.TImgComment;
import com.meizu.mshow.domain.pojo.TImgComplain;
import com.meizu.mshow.domain.pojo.TImgLike;
import com.meizu.mshow.domain.pojo.TImgPicture;
import com.meizu.mshow.domain.pojo.TImgTag;
import com.meizu.mshow.domain.pojo.TImgViewlog;

public interface PictureService {
	public boolean validateTagName(String s);

	// 通过图片id查图片信息
	public TImgPicture loadPictureViaImgId(Long pictureId);

	// 上传
	public void upload(MultipartFile imgFile, PictureModel model, int client) throws ApplicationException;

	// 添加赞
	public void createLike(TImgLike like);

	// 添加评论
	public void createComment(TImgComment comment);

	// 分页查询评论
	public List<TImgComment> loadCommentList(QueryModel model);

	/**
	 * 
	 * searchPicture<br/>
	 * 方法描述：按关健字搜索图片 <br/>
	 * 
	 * @param keyword
	 * @return
	 * @throws RuntimeException
	 *             SearchModel
	 * @exception
	 * @since 1.0.0
	 */
	public SearchModel searchPicture(QueryModel keyword);

	/**
	 * 
	 * searchTag<br/>
	 * 方法描述：按关健字搜索标签 <br/>
	 * 
	 * @param keyword
	 * @return
	 * @throws RuntimeException
	 *             SearchModel
	 * @exception
	 * @since 1.0.0
	 */
	public SearchModel searchTag(QueryModel keyword);

	/**
	 * 
	 * loadPictureByUserId<br/>
	 * 方法描述：我发的图片 <br/>
	 * 
	 * @param model
	 * @return
	 * @throws RuntimeException
	 *             List<TImgPicture>
	 * @exception
	 * @since 1.0.0
	 */
	public List<PicturePlazaModel> loadPictureByUserId(QueryModel model);

	// 取推荐的tag,供用户选择
	public List<TImgTag> loadTagList(QueryModel model);

	// 根据图片id删除图片
	public void deletePictureViaImgId(Long imgId);

	// 根据图片id根据举报
	public TImgComplain loadComplainViaImgIdAndUserId(Long imgId, Long userId);

	// 创建投诉
	public void createComplain(TImgComplain complain);

	// 加载喜欢该图片的用户
	public List<TImgLike> loadLikeListViaImgId(QueryModel queryModel);

	// 加载该图片的TAG
	public List<TImgTag> loadTagsViaImgId(QueryModel queryModel);

	// 添加浏览日志
	public void createViewLog(TImgViewlog log);

	// 为图片贴标签
	public void createTagForImage(TImgTag tag);

	// 断点上传
	public void createBreakpoint(TImgBreakpoint breakpoint);

	/**
	 * <b>创建人：</b>张军强<br/>
	 * loadPhotoForMap<br/>
	 * <b>方法描述：</b> <br/>
	 * 
	 * @param query
	 *            void
	 * @exception
	 * @since 1.0.0
	 */

	public List<HashMap> loadPhotoForMap(QueryModel query);

	/**
	 * <b>创建人：</b>张军强<br/>
	 * loadPhotoForMapHot<br/>
	 * <b>方法描述：</b> <br/>
	 * 
	 * @param query
	 * @return Object
	 * @exception
	 * @since 1.0.0
	 */

	public List<HashMap> loadPhotoForMapHot(QueryModel query);

	public List<PicturePlazaModel> loadLikePictureByUserId(QueryModel model);

	// 加载用户对该图是否喜欢过
	public TImgLike loadLikeViaImgIdAndUserId(long imgId, long userId);

	// 取消喜欢
	public void deleteLikeViaImgIdAndUserId(Long imgId, long userId);

	// 通过commentId查看comment
	public TImgComment loadCommentViaCommentId(Long commentId);

	// 按id删除评论
	public void deleteComment(TImgComment comment);

	// 按关健字查图片
	public List<TImgPicture> searchPic(QueryModel keyword);

}
