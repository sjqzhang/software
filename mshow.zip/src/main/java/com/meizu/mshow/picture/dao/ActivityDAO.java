package com.meizu.mshow.picture.dao;

import java.util.List;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;
import com.meizu.mshow.domain.pojo.TImgActivity;

public interface ActivityDAO {
	public TImgActivity loadActivityViaActivityId(Long activityId);

	public List<TImgActivity> loadActivityList(QueryModel model);

	public List<PicturePlazaModel> loadPictureViaAcitivity(QueryModel model);
}