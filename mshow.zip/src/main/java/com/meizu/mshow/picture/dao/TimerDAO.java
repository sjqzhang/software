package com.meizu.mshow.picture.dao;

import java.util.List;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.TimerModel;

public interface TimerDAO {
	// #{commentWeight},#{likeWeight},#{vewWeight},#{start},#{limit}
	public List<TimerModel> loadPrt(QueryModel queryModel);

	// #{commentWeight},#{likeWeight},#{vewWeight},#{cdate},#{start},#{limit}
	public List<TimerModel> loadHotWithTime(QueryModel queryModel);

	// #{commentWeight},#{likeWeight},#{vewWeight},#{cdate},#{start},#{limit},#{{tagId}
	public List<TimerModel> loadTagHotImage(QueryModel queryModel);

	// #{commentWeight},#{likeWeight},#{vewWeight},#{cdate},#{start},#{limit},#{{tagId}
	public List<TimerModel> loadTagNewImage(QueryModel queryModel);

	public void createHot(List<TimerModel> list);
}
