package com.meizu.mshow.picture.business;

import java.util.List;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;

public interface PicturePlazaService {
	// 热
	public List<PicturePlazaModel> loadHot(QueryModel model);

	// 新
	public List<PicturePlazaModel> loadNew(QueryModel queryModel);

	// 取标签下的图
	public List<PicturePlazaModel> loadTagImage(QueryModel queryModel);

	// 取标签下的图
	public List<PicturePlazaModel> loadImgViaCity(QueryModel queryModel);
}