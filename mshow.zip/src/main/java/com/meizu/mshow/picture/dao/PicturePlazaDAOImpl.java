package com.meizu.mshow.picture.dao;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.meizu.mshow.common.base.BaseDao;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;

@Repository("picturePlazaDAO")
public class PicturePlazaDAOImpl extends BaseDao implements PicturePlazaDAO {

	private Logger logger = Logger.getLogger(PicturePlazaDAOImpl.class);

	@Override
	//
	public List<PicturePlazaModel> loadHot(QueryModel model) {
		SqlSession sqlSession = this.getSqlSession();
		List<PicturePlazaModel> list = sqlSession.selectList("TImgPrt.loadHot", model.getCondition());
		return list;
	}

	private int getHotCount() {
		Integer count = this.getSqlSession().selectOne("TImgPrt.getHotCount");
		return count;
	}

	@Override
	public List<PicturePlazaModel> loadNew(QueryModel model) {
		SqlSession sqlSession = this.getSqlSession();
		List<PicturePlazaModel> list = null;
		if (model.getPageForward().equalsIgnoreCase(QueryModel.ORDER_BY_ASC)) {
			list = sqlSession.selectList("TImgPrt.loadNewASC", model.getCondition());
			Collections.reverse(list);
		} else {
			list = sqlSession.selectList("TImgPrt.loadNew", model.getCondition());
		}
		return list;
	}

	private int getNewCount() {
		Integer count = this.getSqlSession().selectOne("TImgPrt.getNewCount");
		return count;
	}

	@Override
	public List<PicturePlazaModel> loadTagImage(QueryModel model) {
		SqlSession sqlSession = this.getSqlSession();
		List<PicturePlazaModel> list = null;
		if (model.getPageForward().equalsIgnoreCase(QueryModel.ORDER_BY_ASC)) {
			list = sqlSession.selectList("TImgTagmap.loadTagImageASC", model.getCondition());
			Collections.reverse(list);
		} else {
			list = sqlSession.selectList("TImgTagmap.loadTagImage", model.getCondition());
		}
		return list;
	}

	private int getTagImageCount(QueryModel model) {
		Integer count = this.getSqlSession().selectOne("TImgTagmap.getTagImageCount", model.getCondition());
		return count;
	}

	@Override
	public List<PicturePlazaModel> loadImgViaCity(QueryModel queryModel) {
		SqlSession sqlSession = this.getSqlSession();
		List<PicturePlazaModel> list = null;
		if (queryModel.getCondition(Map.class).get("posId") != null) {
			list = sqlSession.selectList("TImgPrt.loadImgViaCityASC", queryModel.getCondition());
			Collections.reverse(list);
		} else {
			list = sqlSession.selectList("TImgPrt.loadImgViaCity", queryModel.getCondition());
		}
		return list;
	}
}