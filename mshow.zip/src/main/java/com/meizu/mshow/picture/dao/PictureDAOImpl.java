package com.meizu.mshow.picture.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.base.BaseDao;
import com.meizu.mshow.common.cache.DBCache;
import com.meizu.mshow.common.cache.DBCacheOperation;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.exception.Error;
import com.meizu.mshow.common.util.CacheKeyUtil;
import com.meizu.mshow.common.util.DateUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.form.TImgBreakpoint;
import com.meizu.mshow.domain.model.PictureModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;
import com.meizu.mshow.domain.model.SearchModel;
import com.meizu.mshow.domain.model.UnLikeModel;
import com.meizu.mshow.domain.pojo.TImgComment;
import com.meizu.mshow.domain.pojo.TImgComplain;
import com.meizu.mshow.domain.pojo.TImgLike;
import com.meizu.mshow.domain.pojo.TImgPicture;
import com.meizu.mshow.domain.pojo.TImgTag;
import com.meizu.mshow.domain.pojo.TImgTagmap;
import com.meizu.mshow.domain.pojo.TImgViewlog;

@Repository("pictureDAO")
public class PictureDAOImpl extends BaseDao implements PictureDAO {

	private Logger logger = Logger.getLogger(PictureDAOImpl.class);

	@Override
	public TImgPicture loadPictureViaImgId(Long imgId) {

		TImgPicture picture = this.getSqlSession().selectOne("TImgPicture.loadPictureViaImgId", imgId);
		return picture;
	}

	@Override
	public List<TImgPicture> loadPictureViaImgIds(List<Long> imgIds) {
		List<TImgPicture> picture = this.getSqlSession().selectList("TImgPicture.loadPictureViaImgIds", imgIds);
		return picture;
	}

	@Override
	public List<TImgComment> loadCommentList(QueryModel model) {
		List<TImgComment> list = null;
		if (model.getPageForward().equalsIgnoreCase(QueryModel.ORDER_BY_ASC)) {
			list = this.getSqlSession().selectList("TImgComment.loadCommentListASC", model.getCondition(Map.class));
			Collections.reverse(list);
		} else {
			list = this.getSqlSession().selectList("TImgComment.loadCommentList", model.getCondition(Map.class));
		}

		return list;
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_COMMENTLIST, key = "#p[0].condition", ttl = BusinessConstants.CACHE_CATEGORY_SHORT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public List<TImgComment> loadCommentListViaImgIds(QueryModel model) {
		List<TImgComment> picture = this.getSqlSession().selectList("TImgComment.loadCommentListViaImgIds", model.getCondition(Map.class));
		return picture;
	}

	private int getCommentCount(QueryModel model) {
		Long pictureId = (Long) model.getCondition(Map.class).get("imgId");
		Integer count = this.getSqlSession().selectOne("TImgComment.getCommentCount", pictureId);
		return count;
	}

	private void createPictureTagAndMap(PictureModel model) {
		List<TImgTag> tags = model.getTags();
		if (tags != null && tags.size() > 0) {
			List<Map<String, Long>> tagUpdateCount = new ArrayList<Map<String, Long>>();
			HashMap<Long, TImgTagmap> saveMapRelationShipMap = new HashMap<Long, TImgTagmap>();
			int count = 0;
			for (TImgTag tag : tags) {
				if (tag.getTagId() == null || tag.getTagId() <= 0) {
					TImgTag tmpTag = this.loadTagViaTagName(tag.getTagName());
					if (tmpTag != null) {// 这个name已经存在了
						tag.setTagId(tmpTag.getTagId());
					} else {
						tag.setCdate(model.getPicture().getCdate());
						tag.setImgCount(0);
						tag.setStatus(BusinessConstants.TAG_STATUS_ACTIVE);
						this.getSqlSession().insert("TImgTag.insertTImgTag", tag);
					}
				}
				if (!saveMapRelationShipMap.containsKey(tag.getTagId())) {
					count++;
					HashMap<String, Long> tagCount = new HashMap<String, Long>();
					tagCount.put("tagId", tag.getTagId());
					tagCount.put("count", 1L);
					tagUpdateCount.add(tagCount);
					TImgTagmap tagmap = new TImgTagmap();
					TImgPicture p = model.getPicture();
					tagmap.setImgId(p.getImgId());
					tagmap.setTagId(tag.getTagId());
					tagmap.setCity(p.getCity());
					tagmap.setContinent(p.getContinent());
					tagmap.setCountry(p.getCountry());
					tagmap.setDistrict(p.getDistrict());
					tagmap.setIp(p.getIp());
					tagmap.setLat(p.getLat());
					tagmap.setLng(p.getLng());
					tagmap.setProvince(p.getProvince());
					tagmap.setStreet(p.getStreet());
					tagmap.setStreetNumber(p.getStreetNumber());
					tagmap.setUserId(p.getUserId());
					saveMapRelationShipMap.put(tag.getTagId(), tagmap);
				}
				if (count >= BusinessConstants.TAG_MAX_SIZE)
					break;
			}
			Map map1 = new HashMap();
			map1.put("list", saveMapRelationShipMap.values());
			if (saveMapRelationShipMap.size() > 0)
				this.getSqlSession().insert("TImgTagmap.insertTImgTagmap", map1);
			// update count
			Map map = new HashMap();
			map.put("tagIds", tagUpdateCount);
			if (tagUpdateCount.size() > 0)
				this.getSqlSession().update("TImgTag.updateTagImgCount", map);
		}
	}

	@Override
	public void createPictureModel(PictureModel model) {
		SqlSession sqlSession = this.getSqlSession();
		TImgPicture p = model.getPicture();
		sqlSession.insert("TImgPicture.insertPicture", p);
		try {
			HashMap<String, Object> m = new HashMap<String, Object>();
			m.put("userId", p.getUserId());
			m.put("count", 1);
			sqlSession.update("TSysUser.updateImgCount", m);
			this.createPictureTagAndMap(model);
			if (p.getActivityId() != null && p.getActivityId() > 0) {
				HashMap<String, Long> map = new HashMap<String, Long>();
				map.put("activityId", p.getActivityId());
				map.put("count", 1L);
				sqlSession.update("TImgActivity.updateActivityImgCount", map);
			}
		} catch (Exception e) {
			// 图片上传成功，tag没成功，不能让用户重新上传
			logger.error(e.getMessage(), e);
		}
	}

	@Override
	public void createLike(TImgLike like) {
		SqlSession sqlSession = this.getSqlSession();
		HashMap<String, Long> map = new HashMap<String, Long>();
		map.put("userId", like.getUserId());
		map.put("imgId", like.getImgId());
		TImgLike tlike = this.getSqlSession().selectOne("TImgLike.loadLikeViaImgIdAndUserId", map);
		if (tlike != null && tlike.getStatus() == BusinessConstants.LIKE_STATUS_NORMAL) {
			throw new ApplicationException(Error.PICTURE_HAS_LIKED);
		}
		HashMap imap = new HashMap();
		imap.put("imgId", like.getImgId());
		imap.put("count", 1);
		sqlSession.update("TImgPicture.updateLikeCount", imap);
		HashMap umap = new HashMap();
		umap.put("userId", like.getUserId());
		umap.put("count", 1);
		sqlSession.update("TSysUser.updateLikeCount", umap);
		if (tlike != null && tlike.getStatus() == BusinessConstants.LIKE_STATUS_CANCEL) {
			HashMap updatemap = new HashMap();
			updatemap.put("imgId", like.getImgId());
			updatemap.put("userId", like.getUserId());
			updatemap.put("status", BusinessConstants.LIKE_STATUS_NORMAL);
			sqlSession.update("TImgLike.updateLikeViaImgIdAndUserId", updatemap);
		} else {
			sqlSession.insert("TImgLike.insertLike", like);
		}
		TImgPicture picture = sqlSession.selectOne("TImgPicture.loadPictureViaImgId", like.getImgId());
	}

	@Override
	public void createBatchLike(List<TImgLike> likes) {
		// batch操作用batchsqlsession
		SqlSession sqlSession = this.getBatchSqlSession();
		List<TImgLike> addList = new ArrayList<TImgLike>();
		List<TImgLike> updateList = new ArrayList<TImgLike>();
		HashMap<Long, Integer> userLikeCount = new HashMap<Long, Integer>();
		HashMap<Long, Integer> imgLikeCount = new HashMap<Long, Integer>();
		// 穷举出那些已赞过的记录并剔除出去，同时统计各个图片，各个用户的赞数
		for (Iterator<TImgLike> iter = likes.iterator(); iter.hasNext();) {
			TImgLike like = iter.next();
			HashMap<String, Long> map = new HashMap<String, Long>();
			map.put("userId", like.getUserId());
			map.put("imgId", like.getImgId());
			TImgLike tlike = this.getSqlSession().selectOne("TImgLike.loadLikeViaImgIdAndUserId", map);
			if (tlike != null && tlike.getStatus() == BusinessConstants.LIKE_STATUS_NORMAL) {
				continue;
			} else if (tlike != null && tlike.getStatus() == BusinessConstants.LIKE_STATUS_CANCEL) {
				updateList.add(tlike);
			} else {
				addList.add(like);
			}
			if (userLikeCount.containsKey(like.getUserId())) {
				userLikeCount.put(like.getUserId(), userLikeCount.get(like.getUserId()) + 1);
			} else {
				userLikeCount.put(like.getUserId(), 1);
			}
			if (imgLikeCount.containsKey(like.getImgId())) {
				imgLikeCount.put(like.getImgId(), imgLikeCount.get(like.getImgId()) + 1);
			} else {
				imgLikeCount.put(like.getImgId(), 1);
			}
		}
		if (addList != null && addList.size() > 0) {
			HashMap paramMap = new HashMap();
			paramMap.put("list", addList);
			sqlSession.insert("TImgLike.insertBatchLike", paramMap);
		}
		if (updateList != null && updateList.size() > 0) {
			HashMap paramMap = new HashMap();
			paramMap.put("updatelist", updateList);
			paramMap.put("status", BusinessConstants.LIKE_STATUS_NORMAL);
			sqlSession.update("TImgLike.updateBatchLike", paramMap);
		}
		// 更新各个用户的赞数
		for (Iterator<Long> iter = userLikeCount.keySet().iterator(); iter.hasNext();) {
			Long userId = iter.next();
			int count = userLikeCount.get(userId);
			HashMap map = new HashMap();
			map.put("userId", userId);
			map.put("count", count);
			sqlSession.update("TSysUser.updateLikeCount", map);
		}
		// 更新各个图片的赞数
		for (Iterator<Long> iter = imgLikeCount.keySet().iterator(); iter.hasNext();) {
			Long imgId = iter.next();
			int count = imgLikeCount.get(imgId);
			HashMap map = new HashMap();
			map.put("imgId", imgId);
			map.put("count", count);
			sqlSession.update("TImgPicture.updateLikeCount", map);
		}
	}

	@Override
	public void createComment(TImgComment comment) {
		SqlSession sqlSession = this.getSqlSession();
		HashMap imap = new HashMap();
		imap.put("imgId", comment.getImgId());
		imap.put("count", 1);
		sqlSession.update("TImgPicture.updateCommentCount", imap);
		HashMap umap = new HashMap();
		umap.put("userId", comment.getUserId());
		umap.put("count", 1);
		sqlSession.update("TSysUser.updateCommentCount", umap);
		sqlSession.insert("TImgComment.insertComment", comment);
	}

	@Override
	public void createBatchComment(List<TImgComment> comments) {
		// batch操作用batchsqlsession
		SqlSession sqlSession = this.getBatchSqlSession();
		List<TImgComment> list = new ArrayList<TImgComment>();
		HashMap<Long, Integer> usrCommentCount = new HashMap<Long, Integer>();
		HashMap<Long, Integer> imgCommentCount = new HashMap<Long, Integer>();
		// 统计各个图片，各个用户的评论数
		for (Iterator<TImgComment> iter = comments.iterator(); iter.hasNext();) {
			TImgComment comment = iter.next();
			if (usrCommentCount.containsKey(comment.getUserId())) {
				usrCommentCount.put(comment.getUserId(), usrCommentCount.get(comment.getUserId()) + 1);
			} else {
				usrCommentCount.put(comment.getUserId(), 1);
			}
			if (imgCommentCount.containsKey(comment.getImgId())) {
				imgCommentCount.put(comment.getImgId(), imgCommentCount.get(comment.getImgId()) + 1);
			} else {
				imgCommentCount.put(comment.getImgId(), 1);
			}
		}
		if (comments != null && comments.size() > 0) {
			HashMap paramMap = new HashMap();
			paramMap.put("list", comments);
			sqlSession.insert("TImgComment.insertBatchComment", paramMap);
		}
		// 更新各个用户的评论数
		for (Iterator<Long> iter = usrCommentCount.keySet().iterator(); iter.hasNext();) {
			Long userId = iter.next();
			int count = usrCommentCount.get(userId);
			HashMap map = new HashMap();
			map.put("userId", userId);
			map.put("count", count);
			sqlSession.update("TSysUser.updateCommentCount", map);
		}
		// 更新各个图片的评论数
		for (Iterator<Long> iter = imgCommentCount.keySet().iterator(); iter.hasNext();) {
			Long imgId = iter.next();
			int count = imgCommentCount.get(imgId);
			HashMap map = new HashMap();
			map.put("imgId", imgId);
			map.put("count", count);
			sqlSession.update("TImgPicture.updateCommentCount", map);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.picture.dao.PictureDAO#searchPicture(java.lang.String)
	 */

	@Override
	public SearchModel searchPicture(QueryModel query) {

		// HashMap<String, Object> param = new HashMap<String, Object>(1);
		// param.put("keyWord", keyword);
		List<Object> list = this.getSqlSession().selectList("TImgPicture.searchPicture", query.getCondition());
		SearchModel searchModel = new SearchModel();
		searchModel.setKeyWord(query.getCondition(Map.class).get("keyWord").toString());
		searchModel.setList(list);
		searchModel.setType(1);
		return searchModel;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.meizu.mshow.picture.dao.PictureDAO#searchTag(java.lang.String)
	 */

	@Override
	public SearchModel searchTag(QueryModel keyword) {

		List<Object> list = this.getSqlSession().selectList("TImgPicture.searchTag", keyword.getCondition());
		SearchModel searchModel = new SearchModel();
		searchModel.setKeyWord(keyword.getCondition(Map.class).get("keyWord").toString());
		searchModel.setList(list);
		searchModel.setType(2);
		return searchModel;

		// List<Long> imgId = loadImageIdByKeyWord(keyword);
		// keyword.getCondition(Map.class).put("list", imgId);
		// List<Object> list = loadImageInfoById(keyword);
		// SearchModel searchModel = new SearchModel();
		// searchModel.setKeyWord(keyword.getCondition(Map.class).get("keyWord").toString());
		// searchModel.setList(list);
		// searchModel.setType(2);
		// return searchModel;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.picture.dao.PictureDAO#loadPictureByUserId(com.meizu.
	 * mshow.common.util.QueryModel)
	 */

	@Override
	public List<PicturePlazaModel> loadPictureByUserId(QueryModel model) {

		SqlSession sqlSession = this.getSqlSession();
		List<PicturePlazaModel> list = null;
		if (model.getPageForward() != null && model.getPageForward().equalsIgnoreCase(QueryModel.ORDER_BY_ASC)) {
			list = this.getSqlSession().selectList("TImgPicture.loadPictureByUserIdASC", model.getCondition());
			Collections.reverse(list);

		} else {
			list = this.getSqlSession().selectList("TImgPicture.loadPictureByUserId", model.getCondition());
		}
		return list;

	}

	@Override
	public List<PicturePlazaModel> loadLikePictureByUserId(QueryModel model) {

		SqlSession sqlSession = this.getSqlSession();
		List<PicturePlazaModel> list = null;
		if (model.getPageForward() != null && model.getPageForward().equalsIgnoreCase(QueryModel.ORDER_BY_ASC)) {
			list = this.getSqlSession().selectList("TImgPicture.loadPictureByLikeASC", model.getCondition());
			Collections.reverse(list);

		} else {
			list = this.getSqlSession().selectList("TImgPicture.loadPictureByLike", model.getCondition());
		}
		return list;

	}

	private List megerList(List list1, List list2) {
		if (list1 == null || list1.size() == 0)
			return list2;
		else if (list2 == null || list2.size() == 0)
			return list1;
		else {
			List list = new ArrayList();
			list.addAll(list1);
			list.addAll(list2);
			return list;
		}
	}

	@Override
	public List<TImgTag> loadTagList(QueryModel model) {
		SqlSession sqlSession = this.getSqlSession();
		return sqlSession.selectList("TImgTag.loadTagList", model.getCondition());
	}

	@Override
	public List<TImgTag> loadTagsViaImgIds(QueryModel model) {
		SqlSession sqlSession = this.getSqlSession();
		return sqlSession.selectList("TImgTag.loadTagsViaImgIds", model.getCondition());
	}

	@Override
	public void deletePictureViaImgId(Long imgId) {
		SqlSession sqlSession = this.getSqlSession();
		TImgPicture p = this.loadPictureViaImgId(imgId);
		if (p != null) {
			HashMap map = new HashMap();
			map.put("imgId", imgId);
			map.put("status", BusinessConstants.PICTURE_STATUS_DESTORY);
			sqlSession.update("TImgPicture.deletePictureViaImgId", map);
			HashMap imap = new HashMap();
			imap.put("imgId", imgId);
			imap.put("count", -1);
			sqlSession.update("TImgTag.updateDeTagImgCount", imap);
			HashMap umap = new HashMap();
			umap.put("userId", p.getUserId());
			umap.put("count", -1);
			sqlSession.update("TSysUser.updateImgCount", umap);
			if (p.getActivityId() != null && p.getActivityId() > 0) {
				HashMap umap2 = new HashMap();
				umap2.put("activityId", p.getActivityId());
				umap2.put("count", -1);
				sqlSession.update("TImgActivity.updateImgCount", umap2);
			}
		}
	}

	@Override
	public TImgComplain loadComplainViaImgIdAndUserId(Long imgId, Long userId) {
		SqlSession sqlSession = this.getSqlSession();
		TImgComplain complain = new TImgComplain();
		complain.setUserId(userId);
		complain.setImgId(imgId);
		return sqlSession.selectOne("TImgComplain.loadComplainViaImgIdAndUserId", complain);
	}

	@Override
	public void createComplain(TImgComplain complain) {
		SqlSession sqlSession = this.getSqlSession();
		sqlSession.insert("TImgComplain.insertComplain", complain);

	}

	public int loadUserLikePictureCount(QueryModel model) {
		return (Integer) this.getSqlSession().selectOne("TImgPicture.loadUserLikePictureCount", model.getCondition());
	}

	@Override
	public List<TImgLike> loadLikeListViaImgId(QueryModel queryModel) {
		SqlSession sqlSession = this.getSqlSession();
		return sqlSession.selectList("TImgLike.loadLikeListViaImgId", queryModel.getCondition());
	}

	@Override
	public List<TImgLike> loadLikeListViaImgIds(QueryModel model) {
		SqlSession sqlSession = this.getSqlSession();
		return sqlSession.selectList("TImgLike.loadLikeListViaImgIds", model.getCondition());
	}

	@Override
	public List<TImgTag> loadTagsViaImgId(QueryModel queryModel) {
		SqlSession sqlSession = this.getSqlSession();
		return sqlSession.selectList("TImgTag.loadTagsViaImgId", queryModel.getCondition());
	}

	@Override
	public void createViewLog(TImgViewlog log) {
		SqlSession sqlSession = this.getSqlSession();
		HashMap map = new HashMap();
		map.put("imgId", log.getImgId());
		map.put("count", 1);
		sqlSession.update("TImgPicture.updatePhotoViewCount", map);
		sqlSession.update("TImgViewLog.insertViewlog", log);
	}

	@Override
	public void createBatchViewLog(List<TImgViewlog> logs) {
		SqlSession sqlSession = this.getBatchSqlSession();
		HashMap<Long, Integer> imgViewCount = new HashMap<Long, Integer>();
		for (Iterator<TImgViewlog> iter = logs.iterator(); iter.hasNext();) {
			TImgViewlog comment = iter.next();
			if (imgViewCount.containsKey(comment.getImgId())) {
				imgViewCount.put(comment.getImgId(), imgViewCount.get(comment.getImgId()) + 1);
			} else {
				imgViewCount.put(comment.getImgId(), 1);
			}
		}
		if (logs != null && logs.size() > 0) {
			HashMap paramMap = new HashMap();
			paramMap.put("list", logs);
			sqlSession.insert("TImgViewlog.insertBatchViewLog", paramMap);
		}
		// 更新各个图片的浏览数
		for (Iterator<Long> iter = imgViewCount.keySet().iterator(); iter.hasNext();) {
			Long imgId = iter.next();
			int count = imgViewCount.get(imgId);
			HashMap map = new HashMap();
			map.put("imgId", imgId);
			map.put("count", count);
			sqlSession.update("TImgPicture.updatePhotoViewCount", map);
		}

	}

	public List<Long> loadImageIdByKeyWord(QueryModel query) {
		return getSqlSession().selectList("TImgPicture.loadImageIdByKeyWord", query.getCondition());
	}

	public List<Object> loadImageInfoById(QueryModel query) {
		return (List<Object>) getSqlSession().selectList("TImgPicture.loadImageInfoById", query.getCondition());
	}

	@Override
	public void createTagForImage(TImgTag tag) {
		SqlSession sqlSession = this.getSqlSession();
		// 标签数少于6
		Integer tagCount = sqlSession.selectOne("TImgTagmap.getImageTagCount", tag);
		if (tagCount >= BusinessConstants.TAG_MAX_SIZE) {
			throw new ApplicationException(Error.TAG_MAX_SIZE);
		}
		// 找查是否有该tagName，有的话以该id保存，没有则先创建，再添加关系
		HashMap map = new HashMap();
		map.put("tagName", tag.getTagName());
		Long tagId = tag.getTagId();
		if (tag.getTagId() == null || tag.getTagId() <= 0) {
			TImgTag tmpTag = this.loadTagViaTagName(tag.getTagName());
			if (tmpTag != null && tmpTag.getTagId() > 0)
				tagId = tmpTag.getTagId();
			else {
				TImgTag tag2 = new TImgTag();
				tag2.setCdate(DateUtil.getNow().getTime() / 1000);
				tag2.setStatus(BusinessConstants.TAG_STATUS_ACTIVE);
				tag2.setTagName(tag.getTagName());
				tag2.setUserId(tag.getUserId());
				sqlSession.insert("TImgTag.insertTImgTag", tag2);
				tagId = tag2.getTagId();
			}
		}
		List<TImgTagmap> tmpMapList = new ArrayList<TImgTagmap>();
		TImgTagmap tmap = new TImgTagmap();
		tmap.setImgId(tag.getImgId());
		tmap.setTagId(tagId);
		tmpMapList.add(tmap);
		map.put("list", tmpMapList);
		// 已存在该tag
		Integer count = sqlSession.selectOne("TImgTagmap.getImageTagIdCount", tmap);
		if (count == 0) {
			sqlSession.insert("TImgTagmap.insertTImgTagmap", map);
			HashMap<String, Long> mapCount = new HashMap<String, Long>();
			mapCount.put("tagId", tagId);
			mapCount.put("count", 1L);
			List list = new ArrayList();
			Map tmpMap = new HashMap();
			list.add(mapCount);// 重用批量
			tmpMap.put("tagIds", list);
			this.getSqlSession().update("TImgTag.updateTagImgCount", tmpMap);

		}
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_TAGNAME, key = "#p[0]", op = DBCacheOperation.SELECT, ttl = BusinessConstants.CACHE_CATEGORY_SHORT_EXPIRES_SECOND)
	public TImgTag loadTagViaTagName(String tagName) {
		HashMap map = new HashMap();
		map.put("tagName", tagName);
		List<TImgTag> list = this.getSqlSession().selectList("TImgTag.loadTagViaTagName", map);
		if (list.size() > 0)
			return list.get(0);
		return null;
	}

	@Override
	public List<TImgTag> loadHotTagsViaTagIds(List<Long> tagIds) {
		SqlSession sqlSession = this.getSqlSession();
		List<TImgTag> list = sqlSession.selectList("TImgTag.loadTagsViaImgId", tagIds);
		return list;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.picture.dao.PictureDAO#createBreakpoint(com.meizu.mshow
	 * .domain.form.TImgBreakpoint)
	 */

	@Override
	public void createBreakpoint(TImgBreakpoint breakpoint) {
		this.getSqlSession().insert("TImgBreakpoint.insertBreakpoint", breakpoint);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.picture.dao.PictureDAO#loadPhotoForMap(com.meizu.mshow
	 * .common.util.QueryModel)
	 */

	@Override
	public List<HashMap> loadPhotoForMap(QueryModel query) {
		return this.getSqlSession().selectList("TImgPicture.loadPhotoForMap", query.getCondition());

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.picture.dao.PictureDAO#loadPhotoForMapHot(com.meizu.mshow
	 * .common.util.QueryModel)
	 */

	@Override
	public List<HashMap> loadPhotoForMapHot(QueryModel query) {
		return this.getSqlSession().selectList("TImgPicture.loadPhotoForMapHot", query.getCondition());
	}

	public static void main(String args[]) {
		List<TestDto> list = new ArrayList<TestDto>();
		for (int i = 0; i < 10; i++) {
			TestDto t1 = new TestDto();
			t1.setCdate(1000 + i);
			t1.setName("abc" + i);
			list.add(t1);
		}
		for (int i = 60; i > 50; i--) {
			TestDto t1 = new TestDto();
			t1.setCdate(1000 + i);
			t1.setName("f" + i);
			list.add(t1);
		}
		for (TestDto d : list) {
			System.out.print(d.getName() + d.getCdate() + " ");
		}
		System.out.println();
		Collections.sort(list);
		for (TestDto d : list) {
			System.out.print(d.getName() + d.getCdate() + " ");
		}
		System.out.println();
		Collections.reverse(list);
		for (TestDto d : list) {
			System.out.print(d.getName() + d.getCdate() + " ");
		}
	}

	@Override
	public TImgLike loadLikeViaImgIdAndUserId(long imgId, long userId) {
		HashMap map = new HashMap();
		map.put("imgId", imgId);
		map.put("userId", userId);
		TImgLike like = this.getSqlSession().selectOne("TImgLike.loadLikeViaImgIdAndUserId", map);
		if (like != null && like.getStatus() == BusinessConstants.LIKE_STATUS_CANCEL)
			return null;
		return like;
	}

	@Override
	public void deleteLikeViaImgIdAndUserId(Long imgId, long userId) {
		SqlSession sqlSession = this.getSqlSession();
		HashMap map = new HashMap();
		map.put("imgId", imgId);
		map.put("userId", userId);
		map.put("status", BusinessConstants.LIKE_STATUS_CANCEL);
		sqlSession.update("TImgLike.updateLikeViaImgIdAndUserId", map);
		HashMap imap = new HashMap();
		imap.put("imgId", imgId);
		imap.put("count", -1);
		sqlSession.update("TImgPicture.updateLikeCount", imap);
		HashMap umap = new HashMap();
		umap.put("userId", userId);
		umap.put("count", -1);
		sqlSession.update("TSysUser.updateLikeCount", umap);
	}

	@Override
	public void deleteBatchLike(List<UnLikeModel> likeList) {
		// batch操作用batchsqlsession
		SqlSession sqlSession = this.getBatchSqlSession();
		HashMap likeMap = new HashMap<Long, TImgLike>();
		HashMap<Long, Integer> userLikeCount = new HashMap<Long, Integer>();
		HashMap<Long, Integer> imgLikeCount = new HashMap<Long, Integer>();
		for (Iterator<UnLikeModel> iter = likeList.iterator(); iter.hasNext();) {
			UnLikeModel like = iter.next();
			TImgLike tlike = this.loadLikeViaImgIdAndUserId(like.getImgId(), like.getUserId());
			if (tlike == null || likeMap.containsKey(like.getLikeId()))
				continue;
			else {
				likeMap.put(like.getLikeId(), tlike);
			}
			if (userLikeCount.containsKey(like.getUserId())) {
				userLikeCount.put(like.getUserId(), userLikeCount.get(like.getUserId()) - 1);
			} else {
				userLikeCount.put(like.getUserId(), -1);
			}
			if (imgLikeCount.containsKey(like.getImgId())) {
				imgLikeCount.put(like.getImgId(), imgLikeCount.get(like.getImgId()) - 1);
			} else {
				imgLikeCount.put(like.getImgId(), -1);
			}
		}
		if (likeMap.values().size() > 0) {
			HashMap map = new HashMap();
			map.put("updatelist", likeMap.values());
			map.put("status", BusinessConstants.LIKE_STATUS_CANCEL);
			sqlSession.update("TImgLike.updateBatchLike", map);
		}
		// 更新各个用户的赞数
		for (Iterator<Long> iter = userLikeCount.keySet().iterator(); iter.hasNext();) {
			Long userId = iter.next();
			int count = userLikeCount.get(userId);
			HashMap map = new HashMap();
			map.put("userId", userId);
			map.put("count", count);
			sqlSession.update("TSysUser.updateLikeCount", map);
		}
		// 更新各个图片的赞数
		for (Iterator<Long> iter = imgLikeCount.keySet().iterator(); iter.hasNext();) {
			Long imgId = iter.next();
			int count = imgLikeCount.get(imgId);
			HashMap map = new HashMap();
			map.put("imgId", imgId);
			map.put("count", count);
			sqlSession.update("TImgPicture.updateLikeCount", map);
		}

	}

	@Override
	public TImgComment loadCommentViaCommentId(Long commentId) {
		HashMap map = new HashMap();
		map.put("commentId", commentId);
		TImgComment comment = this.getSqlSession().selectOne("TImgComment.loadCommentViaCommentId", map);
		return comment;
	}

	@Override
	public void deleteComment(TImgComment comment) {
		// 评论-1；
		// 图片评论数-1
		// 用户评论数-1
		SqlSession sqlSession = this.getSqlSession();
		HashMap imap = new HashMap();
		imap.put("imgId", comment.getImgId());
		imap.put("count", -1);
		sqlSession.update("TImgPicture.updateCommentCount", imap);
		HashMap umap = new HashMap();
		umap.put("userId", comment.getUserId());
		umap.put("count", -1);
		sqlSession.update("TSysUser.updateCommentCount", umap);
		HashMap cmap = new HashMap();
		umap.put("commentId", comment.getCommentId());
		sqlSession.insert("TImgComment.updateCommentStatus", cmap);
	}

	@Override
	public void deleteBatchComment(List<TImgComment> deLikieList) {
		// batch操作用batchsqlsession
		SqlSession sqlSession = this.getBatchSqlSession();
		HashMap commentMap = new HashMap<Long, TImgLike>();
		HashMap<Long, Integer> userCommentCount = new HashMap<Long, Integer>();
		HashMap<Long, Integer> imgCommentCount = new HashMap<Long, Integer>();
		for (Iterator<TImgComment> iter = deLikieList.iterator(); iter.hasNext();) {
			TImgComment comment = iter.next();
			commentMap.put(comment.getCommentId(), comment);
			if (userCommentCount.containsKey(comment.getUserId())) {
				userCommentCount.put(comment.getUserId(), userCommentCount.get(comment.getUserId()) - 1);
			} else {
				userCommentCount.put(comment.getUserId(), -1);
			}
			if (imgCommentCount.containsKey(comment.getImgId())) {
				imgCommentCount.put(comment.getImgId(), imgCommentCount.get(comment.getImgId()) - 1);
			} else {
				imgCommentCount.put(comment.getImgId(), -1);
			}
		}
		if (commentMap.values().size() > 0) {
			HashMap map = new HashMap();
			map.put("updatelist", commentMap.values());
			map.put("status", BusinessConstants.COMMENT_STATUS_DELETED);
			sqlSession.update("TImgComment.updateBatchCommentStatus", map);
		}
		// 更新各个用户的赞数
		for (Iterator<Long> iter = userCommentCount.keySet().iterator(); iter.hasNext();) {
			Long userId = iter.next();
			int count = userCommentCount.get(userId);
			HashMap map = new HashMap();
			map.put("userId", userId);
			map.put("count", count);
			sqlSession.update("TSysUser.updateCommentCount", map);
		}
		// 更新各个图片的赞数
		for (Iterator<Long> iter = imgCommentCount.keySet().iterator(); iter.hasNext();) {
			Long imgId = iter.next();
			int count = imgCommentCount.get(imgId);
			HashMap map = new HashMap();
			map.put("imgId", imgId);
			map.put("count", count);
			sqlSession.update("TImgPicture.updateCommentCount", map);
		}

	}

}

class TestDto implements Comparable<TestDto> {

	private int cdate;
	private String name;

	public int getCdate() {
		return cdate;
	}

	public void setCdate(int cdate) {
		this.cdate = cdate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int compareTo(TestDto o) {
		return this.cdate - o.cdate;
	}
}