package com.meizu.mshow.picture.business;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.TimerModel;
import com.meizu.mshow.picture.dao.TimerDAO;

@Repository("timerService")
public class TimerServiceImpl implements TimerService {
	private Logger logger = Logger.getLogger(TimerServiceImpl.class);

	@Autowired
	@Qualifier("timerDAO")
	private TimerDAO timerDAO;

	@Override
	public List<TimerModel> loadPrt(QueryModel queryModel) {
		List<TimerModel> list = timerDAO.loadPrt(queryModel);
		return list;
	}

	@Override
	public List<TimerModel> loadHotWithTime(QueryModel queryModel) {
		List<TimerModel> list = timerDAO.loadHotWithTime(queryModel);
		return list;
	}

	@Override
	public List<TimerModel> loadTagHotImage(QueryModel queryModel) {
		List<TimerModel> list = timerDAO.loadTagHotImage(queryModel);
		return list;
	}

	@Override
	public List<TimerModel> loadTagNewImage(QueryModel queryModel) {
		List<TimerModel> list = timerDAO.loadTagNewImage(queryModel);
		return list;
	}

	@Override
	public void createHot(List<TimerModel> list) {
		this.timerDAO.createHot(list);

	}
}
