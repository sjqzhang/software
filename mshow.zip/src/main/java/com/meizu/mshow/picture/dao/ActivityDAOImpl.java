package com.meizu.mshow.picture.dao;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.meizu.mshow.common.base.BaseDao;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;
import com.meizu.mshow.domain.pojo.TImgActivity;

@Repository("activityDAO")
public class ActivityDAOImpl extends BaseDao implements ActivityDAO {

	private Logger logger = Logger.getLogger(ActivityDAOImpl.class);

	@Override
	public TImgActivity loadActivityViaActivityId(Long activityId) {
		TImgActivity activity = this.getSqlSession().selectOne("TImgActivity.loadActivityViaActivityId", activityId);
		return activity;
	}

	@Override
	public List<TImgActivity> loadActivityList(QueryModel model) {
		List<TImgActivity> list = null;
		if (model.getPageForward().equalsIgnoreCase(QueryModel.ORDER_BY_ASC)) {
			list = this.getSqlSession().selectList("TImgActivity.loadActivityListASC", model.getCondition(Map.class));
			Collections.reverse(list);
		} else {
			list = this.getSqlSession().selectList("TImgActivity.loadActivityList", model.getCondition(Map.class));
		}

		return list;
	}

	@Override
	public List<PicturePlazaModel> loadPictureViaAcitivity(QueryModel model) {
		List<PicturePlazaModel> list = null;
		if (model.getPageForward().equalsIgnoreCase(QueryModel.ORDER_BY_ASC)) {
			list = this.getSqlSession().selectList("TImgActivity.loadPictureViaAcitivityASC", model.getCondition(Map.class));
			Collections.reverse(list);
		} else {
			list = this.getSqlSession().selectList("TImgActivity.loadPictureViaAcitivity", model.getCondition(Map.class));
		}

		return list;
	}

}
