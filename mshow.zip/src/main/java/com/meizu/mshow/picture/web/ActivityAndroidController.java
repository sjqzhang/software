package com.meizu.mshow.picture.web;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.meizu.mshow.common.base.BaseController;
import com.meizu.mshow.common.base.BaseResultModel;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.util.DateUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.pojo.TImgActivity;
import com.meizu.mshow.picture.business.ActivityService;

@Controller
@RequestMapping(value = "/android")
public class ActivityAndroidController extends BaseController {

	private static final Logger logger = Logger.getLogger(ActivityAndroidController.class);

	@Autowired
	@Qualifier("activityService")
	private ActivityService activityService;

	@RequestMapping(value = "/activity/view")
	public @ResponseBody
	BaseResultModel loadAcitvityViaActivityId(@RequestParam("activityId") Long activityId, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel model = new BaseResultModel();
		TImgActivity activity = this.activityService.loadActivityViaActivityId(activityId);
		model.setReturnValue(activity);
		return model;
	}

	@RequestMapping(value = "/activity/list")
	public @ResponseBody
	BaseResultModel loadAcitvityList(HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		QueryModel queryModel = this.loadQueryModel(request);
		BaseResultModel model = new BaseResultModel();
		if (request.getParameter("startTime") != null) {
			String tmpStrDate = request.getParameter("startTime");
			try {
				Date tmpDate = DateUtil.getDate(tmpStrDate);
				Integer intDate = (int) (tmpDate.getTime() / 1000);
				queryModel.getCondition(Map.class).put("startTime", intDate);
			} catch (Exception e) {
				logger.warn(e.getMessage() + ": [" + tmpStrDate + "]", e);
			}
		}
		if (request.getParameter("endTime") != null) {
			String tmpStrDate = request.getParameter("endTime");
			try {
				Date tmpDate = DateUtil.getDate(tmpStrDate);
				Integer intDate = (int) (tmpDate.getTime() / 1000);
				queryModel.getCondition(Map.class).put("endTime", intDate);
			} catch (Exception e) {
				logger.warn(e.getMessage() + ": [" + tmpStrDate + "]", e);
			}
		}
		String posId = request.getParameter("posId");
		if (request.getParameter("posId") != null && !posId.equals(""))
			queryModel.getCondition(Map.class).put("posId", posId);
		List<TImgActivity> list = this.activityService.loadActivityList(queryModel);
		model.setReturnValue(list);
		return model;
	}

}