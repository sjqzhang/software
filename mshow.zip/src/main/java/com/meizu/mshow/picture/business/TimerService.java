package com.meizu.mshow.picture.business;

import java.util.List;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.TimerModel;

public interface TimerService {
	// #{commentWeight},#{likeWeight},#{vewWeight},#{start},#{limit}
	public List loadPrt(QueryModel queryModel);

	// #{commentWeight},#{likeWeight},#{vewWeight},#{cdate},#{start},#{limit}
	public List loadHotWithTime(QueryModel queryModel);

	public List<TimerModel> loadTagHotImage(QueryModel queryModel);

	public List<TimerModel> loadTagNewImage(QueryModel queryModel);

	public void createHot(List<TimerModel> list);
}
