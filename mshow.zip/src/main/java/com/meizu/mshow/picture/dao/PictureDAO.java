package com.meizu.mshow.picture.dao;

import java.util.HashMap;
import java.util.List;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.form.TImgBreakpoint;
import com.meizu.mshow.domain.model.PictureModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;
import com.meizu.mshow.domain.model.SearchModel;
import com.meizu.mshow.domain.model.UnLikeModel;
import com.meizu.mshow.domain.pojo.TImgComment;
import com.meizu.mshow.domain.pojo.TImgComplain;
import com.meizu.mshow.domain.pojo.TImgLike;
import com.meizu.mshow.domain.pojo.TImgPicture;
import com.meizu.mshow.domain.pojo.TImgTag;
import com.meizu.mshow.domain.pojo.TImgViewlog;

public interface PictureDAO {

	public TImgPicture loadPictureViaImgId(Long imgId);

	public List<TImgPicture> loadPictureViaImgIds(List<Long> imgIds);

	public void createPictureModel(PictureModel model);

	public List<TImgComment> loadCommentList(QueryModel model);

	/**
	 * 
	 * searchPicture<br/>
	 * 方法描述：按图片搜索 <br/>
	 * 
	 * @param keyword
	 * @return
	 * @throws RuntimeException
	 *             SearchModel
	 * @exception
	 * @since 1.0.0
	 */
	public SearchModel searchPicture(QueryModel keyword);

	/**
	 * searchT1ag<br/>
	 * 方法描述：按标签搜索 <br/>
	 * 
	 * @param keyword
	 * @return SearchModel
	 * @exception
	 * @since 1.0.0
	 */

	public SearchModel searchTag(QueryModel keyword);

	public void createLike(TImgLike like);

	public void createComment(TImgComment comment);

	/**
	 * loadPictureByUserId<br/>
	 * 方法描述：我发的图片 <br/>
	 * 
	 * @param model
	 * @return List<TImgPicture>
	 * @exception
	 * @since 1.0.0
	 */

	public List<PicturePlazaModel> loadPictureByUserId(QueryModel model);

	/**
	 * <b>创建人：</b>张军强<br/>
	 * getUserLikePicture<br/>
	 * <b>方法描述：我喜欢的图片</b> <br/>
	 * 
	 * @param model
	 * @return List<Map>
	 * @exception
	 * @since 1.0.0
	 */

	public List<TImgTag> loadTagList(QueryModel model);

	public void deletePictureViaImgId(Long imgId);

	public TImgComplain loadComplainViaImgIdAndUserId(Long imgId, Long userId);

	public void createComplain(TImgComplain complain);

	/**
	 * <b>创建人：</b>张军强<br/>
	 * getPicCommentByUerId<br/>
	 * <b>方法描述：我的最新评论</b> <br/>
	 * 
	 * @param model
	 * @return List<Map>
	 * @exception
	 * @since 1.0.0
	 */

	public List<TImgLike> loadLikeListViaImgId(QueryModel queryModel);

	public List<TImgTag> loadTagsViaImgId(QueryModel queryModel);

	// 添加浏览日志
	public void createViewLog(TImgViewlog log);

	// 批量创建浏览日志
	public void createBatchViewLog(List<TImgViewlog> logs);

	// 批量创建赞
	public void createBatchLike(List<TImgLike> likes);

	// 批量创建评论
	public void createBatchComment(List<TImgComment> comments);

	// 为图片贴标签
	public void createTagForImage(TImgTag tag);

	// 取一批图片Comment
	public List<TImgComment> loadCommentListViaImgIds(QueryModel model);

	// 取一批图片Comment
	public List<TImgLike> loadLikeListViaImgIds(QueryModel model);

	// 取一批图片Comment
	public List<TImgTag> loadTagsViaImgIds(QueryModel model);

	// this is private api for cache
	public List<TImgTag> loadHotTagsViaTagIds(List<Long> tagIds);

	/**
	 * <b>创建人：</b>张军强<br/>
	 * createBreakpoint<br/>
	 * <b>方法描述：</b> <br/>
	 * 
	 * @param breakpoint
	 *            void
	 * @exception
	 * @since 1.0.0
	 */

	public void createBreakpoint(TImgBreakpoint breakpoint);

	/**
	 * <b>创建人：</b>张军强<br/>
	 * loadPhotoForMap<br/>
	 * <b>方法描述：</b> <br/>
	 * 
	 * @param query
	 *            void
	 * @exception
	 * @since 1.0.0
	 */

	public List<HashMap> loadPhotoForMap(QueryModel query);

	/**
	 * <b>创建人：</b>张军强<br/>
	 * loadPhotoForMapHot<br/>
	 * <b>方法描述：</b> <br/>
	 * 
	 * @param query
	 * @return List<HashMap>
	 * @exception
	 * @since 1.0.0
	 */

	public List<HashMap> loadPhotoForMapHot(QueryModel query);

	public List<PicturePlazaModel> loadLikePictureByUserId(QueryModel model);

	// cache声明方法
	public TImgTag loadTagViaTagName(String tagName);

	public TImgLike loadLikeViaImgIdAndUserId(long imgId, long userId);

	public void deleteLikeViaImgIdAndUserId(Long imgId, long userId);

	public void deleteBatchLike(List<UnLikeModel> likeList);

	public TImgComment loadCommentViaCommentId(Long commentId);

	public void deleteComment(TImgComment comment);

	public void deleteBatchComment(List<TImgComment> deLikieList);

}