package com.meizu.mshow.picture.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.cache.Pair;
import com.meizu.mshow.common.cache.RedisUtil;
import com.meizu.mshow.common.util.BeanUtils;
import com.meizu.mshow.common.util.CacheKeyUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.common.util.ServiceLocator;
import com.meizu.mshow.domain.model.PictureInCacheModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;
import com.meizu.mshow.domain.pojo.TImgComment;
import com.meizu.mshow.domain.pojo.TImgLike;
import com.meizu.mshow.domain.pojo.TImgPicture;
import com.meizu.mshow.domain.pojo.TImgTag;
import com.meizu.mshow.picture.dao.PictureDAO;

@Service("cacheService")
public class CacheRedisServiceImpl implements CacheService {

	private static final Logger logger = Logger.getLogger(RedisUtil.class);

	@Autowired
	@Qualifier("pictureDAO")
	private PictureDAO pictureDAO;

	@Override
	public List<PicturePlazaModel> loadHot(QueryModel queryModel) {
		List<PicturePlazaModel> retList = null;
		try {
			String[] p = new String[2];
			p[0] = "#";
			p[1] = CacheKeyUtil.P_PICTURE + "*";
			RedisUtil ru = new RedisUtil();
			List<String> list = ru.sort(CacheKeyUtil.getPlazaHotKey(), p, queryModel.getStart(), queryModel.getLimit());
			retList = new ArrayList<PicturePlazaModel>();
			int i = 0;
			Long tmpId = -1L;
			List<Long> tmpImgIds = new ArrayList<Long>();
			for (Iterator<String> iter = list.iterator(); iter.hasNext(); i++) {
				String json = iter.next();
				if (i % p.length == 0) {
					tmpId = Long.parseLong(json);
					continue;
				}
				if (json != null && !json.equals("")) {
					PicturePlazaModel plazaModel = new PicturePlazaModel();
					PictureInCacheModel cacheModel = JSONObject.parseObject(json, PictureInCacheModel.class);
					if (cacheModel.getComments() != null && cacheModel.getComments().size() > 0) {
						int endPoint = cacheModel.getComments().size() > BusinessConstants.PAGE_PLAZA_LIMIT ? BusinessConstants.PAGE_PLAZA_LIMIT : cacheModel.getComments().size();
						List<TImgComment> comments = new ArrayList<TImgComment>(cacheModel.getComments().subList(0, endPoint));
						plazaModel.setComments(comments);
					}
					TImgPicture picture = cacheModel.getPicture();
					BeanUtils.copyProperties(picture, plazaModel);
					retList.add(plazaModel);
				} else {
					tmpImgIds.add(tmpId);
					retList.add(null);
				}
			}
			if (tmpImgIds.size() > 0) {
				List<TImgPicture> plist = this.pictureDAO.loadPictureViaImgIds(tmpImgIds);
				List<PicturePlazaModel> mlist = new ArrayList<PicturePlazaModel>();
				for (Iterator<TImgPicture> iter = plist.iterator(); iter.hasNext();) {
					TImgPicture picture = iter.next();
					PicturePlazaModel plazaModel = new PicturePlazaModel();
					BeanUtils.copyProperties(picture, plazaModel);
					mlist.add(plazaModel);
				}
				this.loadCommentList(mlist);
				i = 0;
				int j = 0;
				while (i < retList.size() && j < mlist.size()) {
					if (retList.get(i) == null) {
						retList.set(i, mlist.get(j));
						j++;
					}
					i++;
				}
			}
		} catch (Exception e) {
			logger.warn(e.getMessage(), e);
		}
		return retList;
	}

	private void loadCommentList(List<PicturePlazaModel> list) {
		List<Long> tmpImgIds = new ArrayList<Long>();
		for (Iterator<PicturePlazaModel> iter = list.iterator(); iter.hasNext();) {
			tmpImgIds.add(iter.next().getImgId());
		}
		QueryModel model = new QueryModel();
		model.getCondition(Map.class).put("imgIds", tmpImgIds);
		model.setLimit(BusinessConstants.PAGE_PLAZA_LIMIT);
		List<TImgComment> comments = this.pictureDAO.loadCommentListViaImgIds(model);
		HashMap<Long, List<TImgComment>> hcomments = new HashMap<Long, List<TImgComment>>();
		for (Iterator<TImgComment> iter = comments.iterator(); iter.hasNext();) {
			TImgComment comment = iter.next();
			List<TImgComment> lcomments = hcomments.get(comment.getImgId());
			if (lcomments == null) {
				lcomments = new ArrayList<TImgComment>();
				hcomments.put(comment.getImgId(), lcomments);
			}
			if (lcomments.size() < BusinessConstants.PAGE_PLAZA_LIMIT)
				lcomments.add(comment);

		}
		for (Iterator<PicturePlazaModel> iter = list.iterator(); iter.hasNext();) {
			PicturePlazaModel picture = iter.next();
			picture.setComments(hcomments.get(picture.getImgId()));
		}
	}

	@Override
	public List<PicturePlazaModel> loadNew(QueryModel queryModel) {
		List<PicturePlazaModel> retList = null;
		try {
			String[] p = new String[2];
			p[0] = "#";
			p[1] = CacheKeyUtil.P_PICTURE + "*";
			RedisUtil ru = new RedisUtil();
			List<String> list = ru.sort(CacheKeyUtil.getPlazaNewKey(), p, queryModel.getStart(), queryModel.getLimit());
			retList = new ArrayList<PicturePlazaModel>();
			Long tmpId = -1L;
			int i = 0;
			List<Long> tmpImgIds = new ArrayList<Long>();
			for (Iterator<String> iter = list.iterator(); iter.hasNext();) {
				String json = iter.next();
				if (i % p.length == 0) {
					tmpId = Long.parseLong(json);
					continue;
				}
				if (json != null && !json.equals("")) {
					PicturePlazaModel plazaModel = new PicturePlazaModel();
					PictureInCacheModel cacheModel = JSONObject.parseObject(json, PictureInCacheModel.class);
					if (cacheModel.getComments() != null && cacheModel.getComments().size() > 0) {
						int endPoint = cacheModel.getComments().size() > BusinessConstants.PAGE_PLAZA_LIMIT ? BusinessConstants.PAGE_PLAZA_LIMIT : cacheModel.getComments().size();
						List<TImgComment> comments = new ArrayList<TImgComment>(cacheModel.getComments().subList(0, endPoint));
						plazaModel.setComments(comments);
					}
					TImgPicture picture = cacheModel.getPicture();
					BeanUtils.copyProperties(picture, plazaModel);
					retList.add(plazaModel);
				} else {
					tmpImgIds.add(tmpId);
					retList.add(null);
				}
			}
			if (tmpImgIds.size() > 0) {
				List<TImgPicture> plist = this.pictureDAO.loadPictureViaImgIds(tmpImgIds);
				List<PicturePlazaModel> mlist = new ArrayList<PicturePlazaModel>();
				for (Iterator<TImgPicture> iter = plist.iterator(); iter.hasNext();) {
					TImgPicture picture = iter.next();
					PicturePlazaModel plazaModel = new PicturePlazaModel();
					BeanUtils.copyProperties(picture, plazaModel);
					mlist.add(plazaModel);
				}
				this.loadCommentList(mlist);
				i = 0;
				int j = 0;
				while (i < retList.size() && j < mlist.size()) {
					if (retList.get(i) == null) {
						retList.set(i, mlist.get(j));
						j++;
					}
					i++;
				}
			}
		} catch (Exception e) {
			logger.warn(e.getMessage(), e);
		}
		return retList;
	}

	public TImgPicture loadPictureViaImgId(Long imgId) {
		RedisUtil ru = new RedisUtil();
		String json = ru.getString(CacheKeyUtil.getPictureKey(imgId));
		if (json != null && !"".equals(json)) {
			TImgPicture picture = JSON.parseObject(json, TImgPicture.class);
			return picture;
		} else
			return null;
	}

	@Override
	public List<TImgComment> loadCommentList(QueryModel queryModel) {
		List<TImgComment> retList = null;
		if (queryModel.getStart() > BusinessConstants.PAGE_DEFAULT_CACHE_LIMIT) {
			return null;
		}
		try {
			Long imgId = (Long) queryModel.getCondition(Map.class).get("imgId");
			Object posId = queryModel.getCondition(Map.class).get("posId");
			RedisUtil ru = new RedisUtil();
			String json = ru.getString(CacheKeyUtil.getPictureKey(imgId));
			PictureInCacheModel cacheModel = JSONObject.parseObject(json, PictureInCacheModel.class);
			if (cacheModel != null && cacheModel.getComments() != null && cacheModel.getComments().size() > 0) {
				if (json != null && !json.equals("")) {
					if (posId == null) {
						if (cacheModel.getComments() != null && cacheModel.getComments().size() > queryModel.getStart() + queryModel.getLimit()) {
							retList = new ArrayList<TImgComment>(cacheModel.getComments().subList(queryModel.getStart(), queryModel.getStart() + queryModel.getLimit()));
						} else
							return null;
					} else {
						Long fid = Long.parseLong(posId.toString());
						int offsetIndex = 1;
						for (Iterator<TImgComment> iter = cacheModel.getComments().iterator(); iter.hasNext(); offsetIndex++) {
							TImgComment comment = iter.next();
							// 定位到当前ID的位置，如果没有则返回空
							if (comment.getCommentId() <= fid) {
								// 在当前fid的位置往前翻
								if (queryModel.getPageForward().equalsIgnoreCase(QueryModel.ORDER_BY_ASC)) {
									if (cacheModel.getComments() != null) {
										// 往前推不应当小于0
										int startIndex = 0 <= (offsetIndex - queryModel.getLimit()) ? (offsetIndex - queryModel.getLimit()) : 0;
										// 往后推不应当大于size()
										int endIndex = (startIndex + queryModel.getLimit()) < cacheModel.getComments().size() ? (startIndex + queryModel.getLimit()) : cacheModel.getComments().size();
										retList = new ArrayList<TImgComment>(cacheModel.getComments().subList(startIndex, endIndex));
									} else
										return null;
								} else {
									if (cacheModel.getComments() != null) {
										if (cacheModel.getComments().size() > (offsetIndex + queryModel.getStart() + queryModel.getLimit()))
											retList = new ArrayList<TImgComment>(cacheModel.getComments().subList(offsetIndex + queryModel.getStart(), offsetIndex + queryModel.getStart() + queryModel.getLimit()));
										else
											retList = new ArrayList<TImgComment>(cacheModel.getComments().subList(offsetIndex + queryModel.getStart(), cacheModel.getComments().size()));
									} else
										return null;
								}
								break;
							}
						}

					}
				}
			}
		} catch (Exception e) {
			logger.warn(e.getMessage(), e);
		}
		return retList;
	}

	@Override
	public List<TImgLike> loadLikeViaImgId(QueryModel queryModel) {
		List<TImgLike> retList = null;
		if (queryModel.getStart() > BusinessConstants.PAGE_DEFAULT_CACHE_LIMIT) {
			return retList;
		}
		try {
			Long imgId = (Long) queryModel.getCondition(Map.class).get("imgId");
			RedisUtil ru = new RedisUtil();
			String json = ru.getString(CacheKeyUtil.getPictureKey(imgId));
			if (json != null && !json.equals("")) {
				PictureInCacheModel cacheModel = JSONObject.parseObject(json, PictureInCacheModel.class);
				if (cacheModel.getLikes() != null && cacheModel.getLikes().size() > queryModel.getStart()) {
					int endPoint = cacheModel.getLikes().size() > (queryModel.getStart() + queryModel.getLimit()) ? (queryModel.getStart() + queryModel.getLimit()) : cacheModel.getLikes().size();
					retList = new ArrayList<TImgLike>(cacheModel.getLikes().subList(queryModel.getStart(), endPoint));
				}
			}
		} catch (Exception e) {
			logger.warn(e.getMessage(), e);
		}
		return retList;
	}

	@Override
	public void createPictureInCacheModel(Long imgId) {
		PictureInCacheModel pictureInCacheModel = this.loadPictureInCacheModelViaImgId(imgId);
		if (pictureInCacheModel != null)
			return;
		TImgPicture picture = this.pictureDAO.loadPictureViaImgId(imgId);
		QueryModel model = new QueryModel();
		model.getCondition(Map.class).put("imgId", imgId);
		model.setLimit(BusinessConstants.PAGE_PLAZA_LIMIT);
		List<TImgComment> comments = this.pictureDAO.loadCommentList(model);
		List<TImgLike> likes = this.pictureDAO.loadLikeListViaImgId(model);
		List<TImgTag> tags = this.pictureDAO.loadTagsViaImgId(model);
		PictureInCacheModel cacheModel = new PictureInCacheModel();
		cacheModel.setComments(comments);
		cacheModel.setLikes(likes);
		cacheModel.setPicture(picture);
		cacheModel.setTags(tags);
		String json = JSONObject.toJSONString(cacheModel);
		RedisUtil ru = new RedisUtil();
		ru.setString(CacheKeyUtil.getPictureKey(imgId), json, BusinessConstants.CACHE_CATEGORY_DEFAULT_EXPIRES_SECOND);
	}

	@Override
	public void deletePictureInCacheModel(Long imgId) {
		RedisUtil ru = new RedisUtil();
		ru.expire(CacheKeyUtil.getPictureKey(imgId), 0);
	}

	@Override
	public void createBatchPictureInCacheModel(List<Long> imgIds) {
		List<Long> tmpImgIds = this.loadNullPictureInCacheModelKey(imgIds);
		if (tmpImgIds != null && tmpImgIds.size() > 0) {
			List<TImgPicture> pictures = this.pictureDAO.loadPictureViaImgIds(tmpImgIds);
			QueryModel model = new QueryModel();
			model.getCondition(Map.class).put("imgIds", tmpImgIds);
			model.setLimit(BusinessConstants.PAGE_DEFAULT_CACHE_LIMIT);
			List<TImgComment> comments = this.pictureDAO.loadCommentListViaImgIds(model);
			List<TImgLike> likes = this.pictureDAO.loadLikeListViaImgIds(model);
			List<TImgTag> tags = this.pictureDAO.loadTagsViaImgIds(model);

			HashMap<Long, List<TImgComment>> hcomments = new HashMap<Long, List<TImgComment>>();
			HashMap<Long, List<TImgLike>> hlikes = new HashMap<Long, List<TImgLike>>();
			HashMap<Long, List<TImgTag>> htags = new HashMap<Long, List<TImgTag>>();

			for (Iterator<TImgComment> iter = comments.iterator(); iter.hasNext();) {
				TImgComment comment = iter.next();
				List<TImgComment> lcomments = hcomments.get(comment.getImgId());
				if (lcomments == null) {
					lcomments = new ArrayList<TImgComment>();
					hcomments.put(comment.getImgId(), lcomments);
				}
				lcomments.add(comment);

			}
			for (Iterator<TImgLike> iter = likes.iterator(); iter.hasNext();) {
				TImgLike like = iter.next();
				List<TImgLike> llikes = hlikes.get(like.getImgId());
				if (llikes == null) {
					llikes = new ArrayList<TImgLike>();
					hlikes.put(like.getImgId(), llikes);
				}
				llikes.add(like);

			}
			for (Iterator<TImgTag> iter = tags.iterator(); iter.hasNext();) {
				TImgTag tag = iter.next();
				List<TImgTag> ltags = htags.get(tag.getImgId());
				if (ltags == null) {
					ltags = new ArrayList<TImgTag>();
					htags.put(tag.getImgId(), ltags);
				}
				ltags.add(tag);
			}
			List<Pair<String, String>> pairs = new ArrayList<Pair<String, String>>();
			int i = 0;
			for (Iterator<TImgPicture> iter = pictures.iterator(); iter.hasNext(); i++) {
				TImgPicture picture = iter.next();
				PictureInCacheModel cacheModel = new PictureInCacheModel();
				cacheModel.setComments(hcomments.get(picture.getImgId()));
				cacheModel.setLikes(hlikes.get(picture.getImgId()));
				cacheModel.setTags(htags.get(picture.getImgId()));
				cacheModel.setPicture(picture);
				String json = JSONObject.toJSONString(cacheModel);
				Pair<String, String> p = new Pair<String, String>(CacheKeyUtil.getPictureKey(picture.getImgId()), json);
				pairs.add(p);

			}
			RedisUtil ru = new RedisUtil();
			ru.batchSetString(pairs, BusinessConstants.CACHE_CATEGORY_DEFAULT_EXPIRES_SECOND);
		}
	}

	private List<PictureInCacheModel> loadBatchPictureInCacheModel(List<Long> imgIds) {
		List<String> listKey = new ArrayList<String>();
		for (Iterator<Long> iter = imgIds.iterator(); iter.hasNext();) {
			Long imgId = iter.next();
			listKey.add(CacheKeyUtil.getPictureKey(imgId));
		}
		RedisUtil ru = new RedisUtil();
		List<String> list = ru.batchGetString(listKey);
		List<PictureInCacheModel> listModel = null;
		if (list != null && list.size() > 0) {
			listModel = new ArrayList<PictureInCacheModel>();
			for (Iterator<String> iter = list.iterator(); iter.hasNext();) {
				String json = iter.next();
				if (json != null && !json.equals("")) {
					PictureInCacheModel m = JSONObject.parseObject(json, PictureInCacheModel.class);
					listModel.add(m);
				}
			}
		}
		return listModel;
	}

	private List<Long> loadNullPictureInCacheModelKey(List<Long> imgIds) {
		List<Long> tmpImgIds = new ArrayList<Long>();
		tmpImgIds.addAll(imgIds);
		List<String> listKey = new ArrayList<String>();
		for (Iterator<Long> iter = imgIds.iterator(); iter.hasNext();) {
			Long imgId = iter.next();
			listKey.add(CacheKeyUtil.getPictureKey(imgId));
		}
		RedisUtil ru = new RedisUtil();
		List<String> list = ru.batchGetString(listKey);
		List<Long> listModel = null;
		if (list != null && list.size() > 0) {
			listModel = new ArrayList<Long>();
			for (Iterator<String> iter = list.iterator(); iter.hasNext();) {
				String json = iter.next();
				if (json != null && !json.equals("")) {
					PictureInCacheModel m = JSONObject.parseObject(json, PictureInCacheModel.class);
					listModel.add(m.getPicture().getImgId());
				}
			}
		}
		tmpImgIds.removeAll(listModel);
		return tmpImgIds;
	}

	@Override
	public void deleteBatchPictureInCacheModel(List<Long> imgIds) {
		List<PictureInCacheModel> list = this.loadBatchPictureInCacheModel(imgIds);
		if (list == null || list.size() == 0)
			return;
		JedisPool writePool = null;
		Jedis jedis = null;
		String imgIdKeys[] = new String[list.size()];
		try {
			writePool = ServiceLocator.getCacheRouter().getWriteJedisPool();
			jedis = writePool.getResource();
			int i = 0;
			for (Iterator<PictureInCacheModel> iter = list.iterator(); iter.hasNext(); i++) {
				PictureInCacheModel pictureInCacheModel = iter.next();
				imgIdKeys[i] = CacheKeyUtil.getPictureKey(pictureInCacheModel.getPicture().getImgId());
			}
			jedis.del(imgIdKeys);
			writePool.returnResource(jedis);
		} catch (Exception e) {
			try {
				if (jedis != null)
					writePool.returnBrokenResource(jedis);
				logger.warn(e.getMessage(), e);
			} catch (Exception ex) {
				logger.error(ex.getMessage(), ex);
			}
		}
	}

	@Override
	public PictureInCacheModel loadPictureInCacheModelViaImgId(Long imgId) {
		RedisUtil ru = new RedisUtil();
		String json = ru.getString(CacheKeyUtil.getPictureKey(imgId));
		if (json != null && !json.equals("")) {
			PictureInCacheModel model = JSONObject.parseObject(json, PictureInCacheModel.class);
			return model;
		} else {
			return null;
		}
	}

	private Set<String> loadHotTagList() {
		RedisUtil ru = new RedisUtil();
		return ru.smembers(CacheKeyUtil.getHotTagKey());
	}

	@Override
	public List<TImgTag> loadTagsViaImgId(QueryModel queryModel) {
		List<TImgTag> retList = null;
		if (queryModel.getStart() > BusinessConstants.PAGE_DEFAULT_CACHE_LIMIT) {
			return retList;
		}
		try {
			Long imgId = (Long) queryModel.getCondition(Map.class).get("imgId");
			RedisUtil ru = new RedisUtil();
			String json = ru.getString(CacheKeyUtil.getPictureKey(imgId));
			if (json != null && !json.equals("")) {
				PictureInCacheModel cacheModel = JSONObject.parseObject(json, PictureInCacheModel.class);
				if (cacheModel.getTags() != null && cacheModel.getTags().size() > queryModel.getStart()) {
					int endPoint = cacheModel.getTags().size() > (queryModel.getStart() + queryModel.getLimit()) ? (queryModel.getStart() + queryModel.getLimit()) : cacheModel.getTags().size();
					retList = new ArrayList<TImgTag>(cacheModel.getTags().subList(queryModel.getStart(), endPoint));
				}
			}
		} catch (Exception e) {
			retList = null;
			logger.warn(e.getMessage(), e);
		}
		return retList;
	}

	@Override
	public void createHot(List<Long> imgIds) {
		// clear hot set
		RedisUtil ru = new RedisUtil();
		ru.expire(CacheKeyUtil.getPlazaHotKey(), 0);
		HashMap<Double, String> map = new HashMap<Double, String>();
		int i = 0;
		for (Iterator<Long> iter = imgIds.iterator(); iter.hasNext(); i++) {
			Long imgId = iter.next();
			map.put(i * 1.0, imgId + "");
		}
		ru.zadd(CacheKeyUtil.getPlazaHotKey(), map, BusinessConstants.CACHE_CATEGORY_DEFAULT_EXPIRES_SECOND);
		this.createBatchPictureInCacheModel(imgIds);

	}

	@Override
	public void createNew(List<Long> imgIds) {
		RedisUtil ru = new RedisUtil();
		ru.expire(CacheKeyUtil.getPlazaHotKey(), 0);
		HashMap<Double, String> map = new HashMap<Double, String>();
		int i = 0;
		for (Iterator<Long> iter = imgIds.iterator(); iter.hasNext(); i++) {
			Long imgId = iter.next();
			map.put(i * 1.0, imgId + "");
		}
		ru.zadd(CacheKeyUtil.getPlazaNewKey(), map, BusinessConstants.CACHE_CATEGORY_DEFAULT_EXPIRES_SECOND);
		this.createBatchPictureInCacheModel(imgIds);

	}

	@Override
	public void createHotTag(List<Long> tagIds) {
		// load all tagId;
		List<Long> imgIds = new ArrayList<Long>();
		List<TImgTag> list = this.pictureDAO.loadHotTagsViaTagIds(tagIds);
		HashMap<Double, String> map = new HashMap<Double, String>();
		List<Pair<String, String>> pairs = new ArrayList<Pair<String, String>>();
		int i = 0;
		for (Iterator<TImgTag> iter = list.iterator(); iter.hasNext();) {
			TImgTag tag = iter.next();
			map.put(i * 1.0, tag.getTagId() + "");
			String json = JSONObject.toJSONString(tag);
			Pair<String, String> p = new Pair<String, String>(CacheKeyUtil.getPictureKey(tag.getTagId()), json);
			pairs.add(p);
		}
		RedisUtil ru = new RedisUtil();
		ru.zadd(CacheKeyUtil.getHotTagKey(), map, BusinessConstants.CACHE_CATEGORY_DEFAULT_EXPIRES_SECOND);
		ru.batchSetString(pairs, BusinessConstants.CACHE_CATEGORY_DEFAULT_EXPIRES_SECOND);
	}

	@Override
	public void createHotTagViaTagId(Long tagId, List<Long> imgIds) {
		// clear hot set
		RedisUtil ru = new RedisUtil();
		ru.expire(CacheKeyUtil.getTagSetKey(tagId), 0);
		HashMap<Double, String> map = new HashMap<Double, String>();
		int i = 0;
		for (Iterator<Long> iter = imgIds.iterator(); iter.hasNext(); i++) {
			Long imgId = iter.next();
			map.put(i * 1.0, imgId + "");
		}

		ru.zadd(CacheKeyUtil.getTagSetKey(tagId), map, BusinessConstants.CACHE_CATEGORY_DEFAULT_EXPIRES_SECOND);
		this.createBatchPictureInCacheModel(imgIds);

	}

	@Override
	public List<PicturePlazaModel> loadPicturePlazaModelViaTag(QueryModel queryModel) {
		List<PicturePlazaModel> retList = null;
		try {
			String[] p = new String[2];
			p[0] = "#";
			p[1] = CacheKeyUtil.P_PLAZAHOT;
			Long tagId = (Long) queryModel.getCondition(Map.class).get("tagId");
			RedisUtil ru = new RedisUtil();
			List<String> list = ru.sort(CacheKeyUtil.getTagSetKey(tagId), p, queryModel.getStart(), queryModel.getLimit());
			retList = new ArrayList<PicturePlazaModel>();
			int i = 0;
			Long tmpId = -1L;
			List<Long> tmpImgIds = new ArrayList<Long>();
			for (Iterator<String> iter = list.iterator(); iter.hasNext(); i++) {
				String json = iter.next();
				if (i % p.length == 0) {
					tmpId = Long.parseLong(json);
					continue;
				}
				if (json != null && !json.equals("")) {
					PicturePlazaModel plazaModel = new PicturePlazaModel();
					PictureInCacheModel cacheModel = JSONObject.parseObject(json, PictureInCacheModel.class);
					if (cacheModel.getComments() != null && cacheModel.getComments().size() > 0) {
						int endPoint = cacheModel.getComments().size() > BusinessConstants.PAGE_PLAZA_LIMIT ? BusinessConstants.PAGE_PLAZA_LIMIT : cacheModel.getComments().size();
						List<TImgComment> comments = new ArrayList<TImgComment>(cacheModel.getComments().subList(0, endPoint));
						plazaModel.setComments(comments);
					}
					TImgPicture picture = cacheModel.getPicture();
					BeanUtils.copyProperties(picture, plazaModel);
					retList.add(plazaModel);
				} else {
					tmpImgIds.add(tmpId);
					retList.add(null);
				}
			}
			if (tmpImgIds.size() > 0) {
				List<TImgPicture> plist = this.pictureDAO.loadPictureViaImgIds(tmpImgIds);
				List<PicturePlazaModel> mlist = new ArrayList<PicturePlazaModel>();
				for (Iterator<TImgPicture> iter = plist.iterator(); iter.hasNext();) {
					TImgPicture picture = iter.next();
					PicturePlazaModel plazaModel = new PicturePlazaModel();
					BeanUtils.copyProperties(picture, plazaModel);
					mlist.add(plazaModel);
				}
				this.loadCommentList(mlist);
				i = 0;
				int j = 0;
				while (i < retList.size() && j < mlist.size()) {
					if (retList.get(i) == null) {
						retList.set(i, mlist.get(j));
						j++;
					}
					i++;
				}
			}
		} catch (Exception e) {
			logger.warn(e.getMessage(), e);
		}
		return retList;
	}
}
