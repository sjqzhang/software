package com.meizu.mshow.picture.web;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.base.BaseController;
import com.meizu.mshow.common.base.BaseResultModel;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.ip.CityInfo;
import com.meizu.mshow.common.ip.IPApi;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;
import com.meizu.mshow.domain.pojo.TBsArea;
import com.meizu.mshow.domain.pojo.TImgComment;
import com.meizu.mshow.domain.pojo.TImgLike;
import com.meizu.mshow.picture.business.ActivityService;
import com.meizu.mshow.picture.business.PicturePlazaService;
import com.meizu.mshow.picture.business.PictureService;
import com.meizu.mshow.system.business.SystemService;

@Controller
@RequestMapping(value = "/browser")
public class PicturePlazaController extends BaseController {

	private static final Logger logger = Logger.getLogger(PicturePlazaController.class);
	@Autowired
	@Qualifier("picturePlazaService")
	PicturePlazaService plazaService;

	@Autowired
	@Qualifier("pictureService")
	private PictureService pictureService;

	@Autowired
	@Qualifier("activityService")
	private ActivityService activityService;

	@Autowired
	@Qualifier("systemService")
	private SystemService systemService;

	@RequestMapping(value = "/photo/showhot")
	public @ResponseBody
	BaseResultModel loadHot(HttpServletRequest request, HttpServletResponse response) {
		QueryModel queryModel = this.loadQueryModel(request);
		List<PicturePlazaModel> list = this.plazaService.loadHot(queryModel);
		if (this.getUserId(request) > 0) {
			for (PicturePlazaModel model : list) {
				TImgLike like = this.pictureService.loadLikeViaImgIdAndUserId(model.getImgId(), this.getUserId(request));
				if (like != null && like.getStatus() == BusinessConstants.LIKE_STATUS_NORMAL)
					model.setLikeStatus(1);
			}
		}
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(list);
		return model;
	}

	@RequestMapping(value = "/photo/shownew")
	public @ResponseBody
	BaseResultModel loadNew(HttpServletRequest request, HttpServletResponse response) {
		QueryModel queryModel = this.loadQueryModel(request);
		String posId = request.getParameter("posId");
		if (request.getParameter("posId") != null && !posId.equals(""))
			queryModel.getCondition(Map.class).put("posId", posId);
		List<PicturePlazaModel> list = this.plazaService.loadNew(queryModel);
		if (this.getUserId(request) > 0) {
			for (PicturePlazaModel model : list) {
				TImgLike like = this.pictureService.loadLikeViaImgIdAndUserId(model.getImgId(), this.getUserId(request));
				if (like != null && like.getStatus() == BusinessConstants.LIKE_STATUS_NORMAL)
					model.setLikeStatus(1);
			}
		}
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(list);
		return model;
	}

	@RequestMapping(value = "/photo/showtag")
	public @ResponseBody
	BaseResultModel loadTagImage(@RequestParam("tagId") Long tagId, HttpServletRequest request, HttpServletResponse response) {
		QueryModel queryModel = this.loadQueryModel(request);
		queryModel.getCondition(Map.class).put("tagId", tagId);
		String posId = request.getParameter("posId");
		if (request.getParameter("posId") != null && !posId.equals(""))
			queryModel.getCondition(Map.class).put("posId", posId);
		List<PicturePlazaModel> list = this.plazaService.loadTagImage(queryModel);
		if (this.getUserId(request) > 0) {
			for (PicturePlazaModel model : list) {
				TImgLike like = this.pictureService.loadLikeViaImgIdAndUserId(model.getImgId(), this.getUserId(request));
				if (like != null && like.getStatus() == BusinessConstants.LIKE_STATUS_NORMAL)
					model.setLikeStatus(1);
			}
		}
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(list);
		return model;
	}

	@RequestMapping(value = "/photo/showactivity")
	public @ResponseBody
	BaseResultModel loadPictureViaAcitivity(@RequestParam("activityId") Long activityId, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		QueryModel queryModel = this.loadQueryModel(request);
		BaseResultModel model = new BaseResultModel();
		queryModel.getCondition(Map.class).put("activityId", activityId);
		String posId = request.getParameter("posId");
		if (request.getParameter("posId") != null && !posId.equals(""))
			queryModel.getCondition(Map.class).put("posId", posId);
		List<PicturePlazaModel> list = this.activityService.loadPictureViaAcitivity(queryModel);
		for (PicturePlazaModel plazaModel : list) {
			QueryModel tempQueryModel = new QueryModel();
			tempQueryModel.setLimit(3);
			tempQueryModel.getCondition(Map.class).put("imgId", plazaModel.getImgId());
			List<TImgComment> comments = this.pictureService.loadCommentList(tempQueryModel);
			plazaModel.setComments(comments);
			if (this.getUserId(request) > 0) {
				TImgLike like = this.pictureService.loadLikeViaImgIdAndUserId(plazaModel.getImgId(), this.getUserId(request));
				if (like != null && like.getStatus() == BusinessConstants.LIKE_STATUS_NORMAL)
					plazaModel.setLikeStatus(1);
			}
		}
		model.setReturnValue(list);
		return model;
	}

	@RequestMapping(value = "/photo/showcity")
	public @ResponseBody
	BaseResultModel loadImgViaCity(HttpServletRequest request, HttpServletResponse response) {
		String province = request.getParameter("province");
		String city = request.getParameter("city");
		BaseResultModel model = new BaseResultModel();
		QueryModel queryModel = this.loadQueryModel(request);
		String posId = request.getParameter("posId");
		if (request.getParameter("posId") != null && !posId.equals(""))
			queryModel.getCondition(Map.class).put("posId", posId);
		boolean flag = false;
		// 有传城市按传的取，没有传按当前ip取，ip没有对应城市的
		if ((city != null && !city.equals("")) || (province != null && !province.equals(""))) {
			queryModel.getCondition(Map.class).put("province", province);
			queryModel.getCondition(Map.class).put("city", city);
			flag = true;
		} else {
			CityInfo cityInfo = IPApi.getCityInfoByIp(this.getRemoteIp(request));
			TBsArea area = this.systemService.loadTBsAreaViaCityName(cityInfo.getCity());
			if (cityInfo.getCity() != null && !cityInfo.getCity().equals("")) {
				queryModel.getCondition(Map.class).put("city", area.getName());
				flag = true;
			} else if (cityInfo.getProvince() != null && !cityInfo.getProvince().equals("")) {
				flag = true;
				queryModel.getCondition(Map.class).put("province", area.getName());
			}
		}
		if (flag) {
			List<PicturePlazaModel> list = this.plazaService.loadImgViaCity(queryModel);
			if (this.getUserId(request) > 0) {
				for (PicturePlazaModel pm : list) {
					TImgLike like = this.pictureService.loadLikeViaImgIdAndUserId(pm.getImgId(), this.getUserId(request));
					if (like != null && like.getStatus() == BusinessConstants.LIKE_STATUS_NORMAL)
						pm.setLikeStatus(1);
				}
			}
			model.setReturnValue(list);
		}
		return model;
	}

}
