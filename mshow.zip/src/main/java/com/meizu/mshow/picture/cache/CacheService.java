package com.meizu.mshow.picture.cache;

import java.util.List;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.MessageModel;
import com.meizu.mshow.domain.model.PictureInCacheModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;
import com.meizu.mshow.domain.pojo.TImgComment;
import com.meizu.mshow.domain.pojo.TImgLike;
import com.meizu.mshow.domain.pojo.TImgTag;

public interface CacheService {

	// 创建单个图片
	public void createPictureInCacheModel(Long imgId);

	// 创建批量图片
	public void createBatchPictureInCacheModel(List<Long> pictureIds);

	// 删除单个图片
	public void deletePictureInCacheModel(Long imgId);

	// 删除批量图片
	public void deleteBatchPictureInCacheModel(List<Long> imgIds);

	// 单个图片
	public PictureInCacheModel loadPictureInCacheModelViaImgId(Long imgId);

	// 创建hot缓存
	public void createHot(List<Long> imgIds);

	// 创建new缓存
	public void createNew(List<Long> imgIds);

	// 创建hotTag缓存
	public void createHotTag(List<Long> tagIds);

	// 创建单个Tag缓存
	public void createHotTagViaTagId(Long tagId, List<Long> imgIds);

	// 加载缓存热图
	public abstract List<PicturePlazaModel> loadHot(QueryModel queryModel);

	// 加载缓存新图
	public abstract List<PicturePlazaModel> loadNew(QueryModel queryModel);

	// 分页取图片的评论
	public List<TImgComment> loadCommentList(QueryModel model);

	// 加载喜欢该图片的用户
	public List<TImgLike> loadLikeViaImgId(QueryModel queryModel);

	// 加载该图片的TAG
	public List<TImgTag> loadTagsViaImgId(QueryModel queryModel);

	// 按TAG取图片
	public List<PicturePlazaModel> loadPicturePlazaModelViaTag(QueryModel queryModel);

}