package com.meizu.mshow.picture.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.base.BaseDao;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.TimerModel;
import com.meizu.mshow.domain.pojo.TImgPrt;

@Repository("timerDAO")
public class TimerDAOImpl extends BaseDao implements TimerDAO {
	private Logger logger = Logger.getLogger(TimerDAOImpl.class);

	@Override
	public List<TimerModel> loadPrt(QueryModel queryModel) {
		List<TimerModel> list = this.getSqlSession().selectList("TimerModel.loadPrt", queryModel.getCondition());
		return list;
	}

	@Override
	public List<TimerModel> loadHotWithTime(QueryModel queryModel) {
		List<TimerModel> list = this.getSqlSession().selectList("TimerModel.loadHotWithTime", queryModel.getCondition());
		return list;
	}

	@Override
	public List<TimerModel> loadTagHotImage(QueryModel queryModel) {
		SqlSession sqlSession = this.getSqlSession();
		List<TimerModel> list = sqlSession.selectList("TimerModel.loadTagHotImage", queryModel.getCondition());
		return list;
	}

	@Override
	public List<TimerModel> loadTagNewImage(QueryModel queryModel) {
		SqlSession sqlSession = this.getSqlSession();
		List<TimerModel> list = sqlSession.selectList("TimerModel.loadTagNewImage", queryModel.getCondition());
		return list;
	}

	@Override
	public void createHot(List<TimerModel> list) {
		SqlSession sqlSession = this.getSqlSession();
		if (list != null && list.size() > 0) {
			List<TImgPrt> plist = new ArrayList<TImgPrt>();
			for (Iterator<TimerModel> iter = list.iterator(); iter.hasNext();) {
				TimerModel model = iter.next();
				TImgPrt prt = new TImgPrt();
				prt.setImgId(model.getImgId());
				prt.setCategory(BusinessConstants.PRT_CATEGORY_HOT);
				prt.setLevel(BusinessConstants.PRT_LEVEL_TIMMER);
				prt.setStatus(BusinessConstants.PRT_STATUS_ACTIVE);
				plist.add(prt);
			}
			HashMap paramMap = new HashMap();
			paramMap.put("list", plist);
			sqlSession.delete("TImgPrt.deletePRT");
			sqlSession.insert("TImgPrt.insertBatchPRT", paramMap);
		}

	}
}
