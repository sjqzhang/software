package com.meizu.mshow.picture.business;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.cache.DBCache;
import com.meizu.mshow.common.cache.DBCacheOperation;
import com.meizu.mshow.common.util.CacheKeyUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;
import com.meizu.mshow.domain.pojo.TImgComment;
import com.meizu.mshow.picture.cache.CacheService;
import com.meizu.mshow.picture.dao.PictureDAO;
import com.meizu.mshow.picture.dao.PicturePlazaDAO;

@Service("picturePlazaService")
public class PicturePlazaServiceImpl implements PicturePlazaService {

	Logger logger = Logger.getLogger(PicturePlazaServiceImpl.class);
	@Autowired
	private PicturePlazaDAO picturePlazaDAO;

	@Autowired
	private CacheService cacheService;

	@Autowired
	@Qualifier("pictureDAO")
	private PictureDAO pictureDAO;

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_PLAZAHOT, key = "#p[0].condition", ttl = BusinessConstants.CACHE_CATEGORY_SHORT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public List<PicturePlazaModel> loadHot(QueryModel queryModel) {
		if (queryModel.getStart() > BusinessConstants.PAGE_DEFAULT_CACHE_LIMIT)
			return new ArrayList();
		List<PicturePlazaModel> retList = this.cacheService.loadHot(queryModel);
		if (retList == null || retList.size() == 0) {
			Map map = queryModel.getCondition(Map.class);
			map.put("commentWeight", BusinessConstants.SCORE_COMMENT_WEIGHT);
			map.put("likeWeight", BusinessConstants.SCORE_LIKE_WEIGHT);
			map.put("vewWeight", BusinessConstants.SCORE_VIEW_WEIGHT);
			retList = this.picturePlazaDAO.loadHot(queryModel);
			this.loadCommentList(retList);
		}
		return retList;
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_PLAZANEW, key = "#p[0].condition", ttl = BusinessConstants.CACHE_CATEGORY_SHORT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public List<PicturePlazaModel> loadNew(QueryModel queryModel) {
		List<PicturePlazaModel> retList = this.cacheService.loadNew(queryModel);
		if (retList == null || retList.size() == 0) {
			Map map = queryModel.getCondition(Map.class);
			map.put("commentWeight", BusinessConstants.SCORE_COMMENT_WEIGHT);
			map.put("likeWeight", BusinessConstants.SCORE_LIKE_WEIGHT);
			map.put("vewWeight", BusinessConstants.SCORE_VIEW_WEIGHT);
			retList = this.picturePlazaDAO.loadNew(queryModel);
			this.loadCommentList(retList);
		}
		return retList;
	}

	private void loadCommentList(List<PicturePlazaModel> list) {
		if (list != null & list.size() > 0) {
			List<Long> tmpImgIds = new ArrayList<Long>();
			for (Iterator<PicturePlazaModel> iter = list.iterator(); iter.hasNext();) {
				tmpImgIds.add(iter.next().getImgId());
			}
			QueryModel model = new QueryModel();
			model.getCondition(Map.class).put("imgIds", tmpImgIds);
			model.setLimit(BusinessConstants.PAGE_PLAZA_LIMIT);
			List<TImgComment> comments = this.pictureDAO.loadCommentListViaImgIds(model);
			HashMap<Long, List<TImgComment>> hcomments = new HashMap<Long, List<TImgComment>>();
			for (Iterator<TImgComment> iter = comments.iterator(); iter.hasNext();) {
				TImgComment comment = iter.next();
				List<TImgComment> lcomments = hcomments.get(comment.getImgId());
				if (lcomments == null) {
					lcomments = new ArrayList<TImgComment>();
					hcomments.put(comment.getImgId(), lcomments);
				}
				if (lcomments.size() < BusinessConstants.PAGE_PLAZA_LIMIT)
					lcomments.add(comment);

			}
			for (Iterator<PicturePlazaModel> iter = list.iterator(); iter.hasNext();) {
				PicturePlazaModel picture = iter.next();
				picture.setComments(hcomments.get(picture.getImgId()));
			}
		}
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_TAG_IMG, key = "#p[0].condition", ttl = BusinessConstants.CACHE_CATEGORY_SHORT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public List<PicturePlazaModel> loadTagImage(QueryModel queryModel) {
		List<PicturePlazaModel> retList = this.cacheService.loadPicturePlazaModelViaTag(queryModel);
		if (retList == null || retList.size() == 0) {
			retList = this.picturePlazaDAO.loadTagImage(queryModel);
			if (retList != null && retList.size() > 0)
				this.loadCommentList(retList);
		}
		return retList;
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_CITY, key = "#p[0].condition", ttl = BusinessConstants.CACHE_CATEGORY_SHORT_EXPIRES_SECOND, op = DBCacheOperation.SELECT)
	public List<PicturePlazaModel> loadImgViaCity(QueryModel queryModel) {
		List<PicturePlazaModel> retList = this.picturePlazaDAO.loadImgViaCity(queryModel);
		return retList;
	}

}