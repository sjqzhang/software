package com.meizu.mshow.picture.business;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.model.PicturePlazaModel;
import com.meizu.mshow.domain.pojo.TImgActivity;
import com.meizu.mshow.picture.dao.ActivityDAO;
import com.meizu.mshow.picture.dao.PictureDAO;

@Service("activityService")
public class ActivityServiceImpl implements ActivityService {

	Logger logger = Logger.getLogger(ActivityServiceImpl.class);
	@Autowired
	@Qualifier("activityDAO")
	private ActivityDAO activityDAO;

	@Autowired
	@Qualifier("pictureDAO")
	private PictureDAO pictureDAO;

	@Override
	public TImgActivity loadActivityViaActivityId(Long activityId) {
		return this.activityDAO.loadActivityViaActivityId(activityId);
	}

	@Override
	public List<TImgActivity> loadActivityList(QueryModel model) {
		return this.activityDAO.loadActivityList(model);
	}

	@Override
	public List<PicturePlazaModel> loadPictureViaAcitivity(QueryModel model) {
		List<PicturePlazaModel> list = this.activityDAO.loadPictureViaAcitivity(model);
		return list;
	}
}