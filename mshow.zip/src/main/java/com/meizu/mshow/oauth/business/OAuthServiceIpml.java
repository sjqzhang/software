package com.meizu.mshow.oauth.business;


public class OAuthServiceIpml {

}
