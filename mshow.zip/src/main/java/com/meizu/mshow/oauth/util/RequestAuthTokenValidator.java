package com.meizu.mshow.oauth.util;

import java.io.IOException;
import java.util.HashSet;

import javax.servlet.http.HttpServletRequest;

import net.oauth.OAuthAccessor;
import net.oauth.OAuthException;
import net.oauth.OAuthMessage;
import net.oauth.OAuthProblemException;
import net.oauth.server.OAuthServlet;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.alisoft.xplatform.asf.cache.memcached.MemCachedClientHelper;
import com.alisoft.xplatform.asf.cache.memcached.client.MemCachedClient;
import com.alisoft.xplatform.asf.cache.memcached.client.SockIOPool;
import com.meizu.mshow.common.ApplicationConfig;
import com.meizu.mshow.common.cache.ICache;
import com.meizu.mshow.common.security.SecurityUtil;
import com.meizu.mshow.domain.model.UserModel;
import com.meizu.mshow.domain.pojo.TSysUser;

/**
 * 
 * <b>类名称：</b>RequestAuthTokenValidator<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-30 下午5:08:27<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */
@Service(value = "requestAuthTokenValidator")
public class RequestAuthTokenValidator {
	private static final Logger logger = Logger.getLogger(RequestAuthTokenValidator.class);

	private static MemCachedClient cacheClient = new MemCachedClient();

	private static MemCachedClientHelper helper = new MemCachedClientHelper();

	private String application;

	private boolean debug = false;

	static {
		String[] servers = { ApplicationConfig.getInstance().getProperty("sys.memcache.url") };
		// 创建一个连接池
		SockIOPool pool = SockIOPool.getInstance();
		// 设置缓存服务器
		pool.setServers(servers);
		// 设置初始化连接数，最小连接数，最大连接数以及最大处理时间
		pool.setInitConn(50);
		pool.setMinConn(50);
		pool.setMaxConn(500);
		pool.setMaxIdle(1000 * 60 * 60);
		// 设置主线程睡眠时间，每3秒苏醒一次，维持连接池大小
		// maintSleep 千万不要设置成30，访问量一大就出问题，单位是毫秒，推荐30000毫秒。
		pool.setMaintSleep(3000);
		// 关闭套接字缓存
		pool.setNagle(false);
		// 连接建立后的超时时间
		pool.setSocketTO(3000);
		// 连接建立时的超时时间
		pool.setSocketConnectTO(0);
		// 初始化连接池
		pool.initialize();
	}

	/** 远程Cache 保存用户Session */
	private ICache oauthRemoteCache;

	public OAuthAccessor validateAccess(HttpServletRequest request) throws OAuthException, IOException {
		try {
			String url = request.getRequestURI();
			if (ignoreUrls != null && ignoreUrls.size() > 0) {
				// 目前仅适合应用DWR时的场景,例如URL是这种模式：/service/api/xxx.jsonp,
				// HashSet中保存的是xxx
				// 如果不需要OAuth认证则跳过检查。
				// String url = request.getRequestURI();
				int lastSlash = url.lastIndexOf('/');
				int lastDot = url.lastIndexOf('.');
				lastSlash++;
				if (lastSlash < lastDot) {
					url = url.substring(lastSlash, lastDot);
					if (ignoreUrls.contains(url)) {
						return null;
					}
				}
			}

			OAuthMessage requestMessage = OAuthServlet.getMessage(request, null);
			String oauth_token = requestMessage.getToken();
			if (oauth_token == null) {
				oauth_token = request.getParameter("token");
			}
			if (oauth_token == null) {
				raise401();
			}
			if (oauth_token.length() > 200) {
				OAuthExceptionHelper.raise401("获取授权失败,Token错误");
				return null;
			}

			OAuthAccessor accessor = null;

			helper.setCacheClient(cacheClient);

			accessor = (OAuthAccessor) cacheClient.get(oauth_token);
			// {firmware=null, authorized=true, phone_sn=null, app_version=null,
			// operator=null, user_name=appadmin, x_auth_mode=client_auth,
			// email=zhuliang@meizu.com, locationData=null, x_auth_app=UC,OM,
			// user_id=1462350, flyme=appadmin, salt=91705c}
			UserModel userModel = new UserModel();
			TSysUser user = new TSysUser();
			user.setUserId(Long.valueOf(accessor.getProperty("user_id").toString()));
			user.setUserName((accessor.getProperty("user_name").toString()));
			user.setAliasName(accessor.getProperty("user_name").toString());
			if (accessor.getProperty("flyme") != null)
				user.setUserName(accessor.getProperty("flyme").toString());
			user.setEmail(accessor.getProperty("email").toString());
			userModel.setUser(user);
			SecurityUtil.login(request, userModel);
			accessor.setProperty("sessionId", request.getSession().getId());

			return accessor;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			OAuthExceptionHelper.raise401("获取授权失败" + e.getMessage());
		}
		return null;
	}

	private void raise401() throws OAuthProblemException {
		// Context.destroy();
		OAuthExceptionHelper.raise401("获取授权失败");
	}

	public void setApplication(String application) {
		this.application = application;
	}

	/**
	 * 当前认证信息适用的应用，如APP, UC, OM等
	 * 
	 * @return
	 */
	public String getApplication() {
		return application;
	}

	private HashSet<String> ignoreUrls;

	public void setIgnoreUrl(String urls) {
		String[] split = urls.split("\\,");
		ignoreUrls = new HashSet<String>();
		for (int i = 0; i < split.length; i++) {
			ignoreUrls.add(split[i]);
		}
	}

	public void setDebug(boolean debug) {
		this.debug = debug;
	}

	/**
	 * 如果是调试阶段，则不需要验证。
	 * 
	 * @return
	 */
	public boolean isDebug() {
		return debug;
	}

	public ICache getOauthRemoteCache() {
		return oauthRemoteCache;
	}

	public void setOauthRemoteCache(ICache oauthRemoteCache) {
		this.oauthRemoteCache = oauthRemoteCache;
	}
}
