package com.meizu.mshow.oauth.business;


public interface OAuthService {
	public void login();
	
}
