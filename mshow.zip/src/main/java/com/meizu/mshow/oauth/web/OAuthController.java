package com.meizu.mshow.oauth.web;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.scribe.builder.ServiceBuilder;
import org.scribe.builder.api.SinaWeiboApi20;
import org.scribe.model.OAuthRequest;
import org.scribe.model.Response;
import org.scribe.model.Token;
import org.scribe.model.Verb;
import org.scribe.model.Verifier;
import org.scribe.oauth.OAuthService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.alibaba.fastjson.JSON;
import com.meizu.mshow.common.ApplicationConfig;
import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.SessionConstants;
import com.meizu.mshow.common.base.BaseController;
import com.meizu.mshow.common.security.SecurityUtil;
import com.meizu.mshow.common.util.Base64KeyManager;
import com.meizu.mshow.common.util.RSACoder;
import com.meizu.mshow.oauth.util.TencentWeiboApi2;

public class OAuthController extends BaseController {

	private static final Logger logger = Logger.getLogger(OAuthController.class);

	private static final Token EMPTY_TOKEN = null;

	@RequestMapping(value = "/oauth/tosinalogin")
	public String toSinaLogin(HttpServletRequest request, HttpServletResponse response) throws NoSuchAlgorithmException, KeyManagementException, IOException {
		String retValue = checkSession(request);
		if (retValue != null)
			return retValue;
		ApplicationConfig applicationConfig = ApplicationConfig.getInstance();
		String apiKey = applicationConfig.getProperty("sina.apikey");
		String apiSecret = applicationConfig.getProperty("sina.apisecret");
		OAuthService service = new ServiceBuilder().provider(SinaWeiboApi20.class).apiKey(apiKey).apiSecret(apiSecret).callback(this.getBasePath(request) + "/browser/oauth/sina").build();
		String authorizationUrl = service.getAuthorizationUrl(EMPTY_TOKEN);
		return "redirect:" + authorizationUrl;
	}

	@RequestMapping(value = "/oauth/sina")
	public String loginViaSina(HttpServletRequest request, HttpServletResponse response) throws NoSuchAlgorithmException, KeyManagementException, IOException {
		String retValue = checkSession(request);
		if (retValue != null)
			return retValue;
		trustAllCert();
		ApplicationConfig applicationConfig = ApplicationConfig.getInstance();
		String apiKey = applicationConfig.getProperty("sina.apikey");
		String apiSecret = applicationConfig.getProperty("sina.apisecret");
		OAuthService service = new ServiceBuilder().provider(SinaWeiboApi20.class).apiKey(apiKey).apiSecret(apiSecret).callback(applicationConfig.getProperty("sina.accesstoken.callback")).build();
		Verifier verifier = new Verifier(request.getParameter("code"));
		Token accessToken = service.getAccessToken(EMPTY_TOKEN, verifier);
		OAuthRequest orequest = new OAuthRequest(Verb.GET, BusinessConstants.SINA_PROTECTED_RESOURCE_URL);
		service.signRequest(accessToken, orequest);
		Response oresponse = orequest.send();
		HashMap map = JSON.parseObject(oresponse.getBody(), HashMap.class);
		String unitUserId = (Long) map.get("uid") + "";

		// loadUserViaUnitUserId
		// if the user is null , create a user with sina data
		if ((unitUserId) == null) {
			OAuthRequest orequest2 = new OAuthRequest(Verb.GET, BusinessConstants.SINA_PROTECTED_USER_URL);
			orequest2.addQuerystringParameter("uid", unitUserId);
			service.signRequest(accessToken, orequest2);
			Response oresponse2 = orequest2.send();
			System.out.println(oresponse2.getCode());
			System.out.println(oresponse2.getBody());
			// create user;
		}

		String userId = "";
		// init session here {}&& return
		this.initSession(request, new Object());
		return "redirect:/";
	}

	private String getRedirectUrl(HttpServletRequest request) {
		String useruri = request.getParameter("useruri");
		if (useruri == null || useruri.equals("")) {
			String refrenceUrl = request.getHeader("Referer");
			if (refrenceUrl != null && !refrenceUrl.equals("")) {
				useruri = refrenceUrl;
			} else {
				useruri = this.getBasePath(request);
			}
		}
		return useruri;
	}

	private String checkSession(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		// if the SESSION_CHECKED in session is not null just redirect
		// if( session != null && session.getAttribute(
		// SessionConstants.SESSION_CHECKED ) != null ) {
		// return "redirect:" + getRedirectUrl( request );
		// }
		Cookie[] cookies = request.getCookies();
		String jsessionid = null;
		for (int i = 0; cookies != null && i < cookies.length; i++) {
			if (cookies[i].getName().equalsIgnoreCase(SessionConstants.SEESION_COOKIEID)) {
				jsessionid = cookies[i].getValue();
				break;
			}
		}
		// if the user in cache not null just init with it && redirect
		if (jsessionid != null && !jsessionid.equals("")) {
			// get user from cache
			// init

		}
		return null;
	}

	@RequestMapping(value = "/oauth/toflymelogin")
	public String toFlymeLogin(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
		ApplicationConfig applicationConfig = ApplicationConfig.getInstance();
		String useruri = getRedirectUrl(request);
		StringBuffer loginUrl = new StringBuffer(applicationConfig.getProperty("flyme.authorize")).append("?appuri=").append(URLEncoder.encode(this.getBasePath(request) + "/browser/oauth/flyme", "UTF-8")).append("&useruri=")
				.append(URLEncoder.encode(useruri, "UTF-8")).append("&sid=").append(applicationConfig.getProperty("flyme.sid")).append("&service=").append(applicationConfig.getProperty("flyme.service"));
		if (logger.isDebugEnabled()) {
			logger.debug(loginUrl.toString());
		}
		return "redirect:" + loginUrl.toString();
	}

	@RequestMapping(value = "/oauth/flyme")
	public String loginViaFlyme(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String redirectUrl = request.getParameter("useruri");
		String token = request.getParameter("token");
		String useruri = request.getParameter("useruri");
		if (useruri == null || useruri.equals("")) {
			useruri = this.getBasePath(request);
		}
		if (token != null && !token.equals("")) {
			Base64KeyManager base64KeyManager = (Base64KeyManager) WebApplicationContextUtils.getWebApplicationContext(request.getSession().getServletContext()).getBean("Base64KeyManager");
			String strJsonUser = RSACoder.decryptWithRSA_AES(token, base64KeyManager.getPublicKey());
			// init here
			initSession(request, new Object());
			if (logger.isDebugEnabled()) {
				logger.debug(strJsonUser);
			}
		}
		return "redirect:" + useruri;
	}

	@RequestMapping(value = "/oauth/totecentlogin")
	public String toTecentLogin(HttpServletRequest request, HttpServletResponse response) throws NoSuchAlgorithmException, KeyManagementException, IOException {
		String retValue = checkSession(request);
		if (retValue != null)
			return retValue;
		ApplicationConfig applicationConfig = ApplicationConfig.getInstance();
		String apiKey = applicationConfig.getProperty("tencent.apikey");
		String apiSecret = applicationConfig.getProperty("tencent.apisecret");
		OAuthService service = new ServiceBuilder().provider(TencentWeiboApi2.class).apiKey(apiKey).apiSecret(apiSecret).callback(this.getBasePath(request) + "/browser/oauth/tencent").scope("get_info").build();
		String authorizationUrl = service.getAuthorizationUrl(EMPTY_TOKEN);
		return "redirect:" + authorizationUrl;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/oauth/tencent")
	public String loginViaTencent(HttpServletRequest request, HttpServletResponse response) throws NoSuchAlgorithmException, KeyManagementException, IOException {
		String retValue = checkSession(request);
		if (retValue != null)
			return retValue;
		trustAllCert();
		ApplicationConfig applicationConfig = ApplicationConfig.getInstance();
		String apiKey = applicationConfig.getProperty("tencent.apikey");
		String apiSecret = applicationConfig.getProperty("tencent.apisecret");
		OAuthService service = new ServiceBuilder().provider(TencentWeiboApi2.class).apiKey(apiKey).apiSecret(apiSecret).callback(applicationConfig.getProperty("tencent.accesstoken.callback")).build();
		Verifier verifier = new Verifier(request.getParameter("code"));
		Token accessToken = service.getAccessToken(EMPTY_TOKEN, verifier);
		OAuthRequest orequest = new OAuthRequest(Verb.GET, BusinessConstants.TENCENT_PROTECTED_RESOURCE_URL);
		service.signRequest(accessToken, orequest);
		Response oresponse = orequest.send();
		Pattern responseBodyPattern = Pattern.compile("\\{\\S{1,}[^\\]]");
		Matcher matcher = responseBodyPattern.matcher(oresponse.getBody());
		if (matcher.find()) {
			HashMap map = JSON.parseObject(matcher.group(0), HashMap.class);
			String unitUserId = map.get("openid") + "";
			OAuthRequest orequest2 = new OAuthRequest(Verb.GET, BusinessConstants.TENCENT_PROTECTED_USER_URL);
			orequest2.addQuerystringParameter("openid", unitUserId);
			orequest2.addQuerystringParameter("oauth_consumer_key", apiKey);
			orequest2.addQuerystringParameter("client_id", apiKey);
			service.signRequest(accessToken, orequest2);
			Response oresponse2 = orequest2.send();
			System.out.println(oresponse2.getCode());
			System.out.println(oresponse2.getBody());
			HashMap userOrigin = JSON.parseObject(oresponse2.getBody(), HashMap.class);
			System.out.println(userOrigin.get("data"));
			if (userOrigin.get("data") != null && !userOrigin.get("data").toString().equals("")) {
				HashMap userHashMap = JSON.parseObject(userOrigin.get("data").toString(), HashMap.class);
				System.out.println(userHashMap.get("openid"));
				System.out.println(userHashMap.get("name"));
				System.out.println(userHashMap.get("nick"));
			}
			// create user;
		}

		// loadUserViaUnitUserId
		// if the user is null , create a user with sina data

		String userId = "";
		// init session here {}&& return
		this.initSession(request, new Object());
		return "redirect:/";
	}

	@RequestMapping(value = "/oauth/logout")
	public String logout(HttpServletRequest request, HttpServletResponse response) throws NoSuchAlgorithmException, KeyManagementException, IOException {
		SecurityUtil.logout(request);
		return "redirect:/";
	}

	private void trustAllCert() throws NoSuchAlgorithmException, KeyManagementException {
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {

			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs, String authType) {
			}

			public void checkServerTrusted(X509Certificate[] certs, String authType) {
			}
		} };
		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		HostnameVerifier allHostsValid = new HostnameVerifier() {

			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		};
		HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	}

	private void initSession(HttpServletRequest request, Object user) {
		HttpSession session = request.getSession();
		session.setAttribute(SessionConstants.SESSION_USER_ID, "${userId}");
		session.setAttribute(SessionConstants.SESSION_USER_NAME, "${userName}");
		session.setAttribute(SessionConstants.SESSION_CHECKED, "SESSION_CHECKED");
		session.setAttribute(SessionConstants.SESSION_USER, user);
	}

	public static void main(String args[]) {
		String strTest = "asdf{asdf}";
		Pattern responseBodyPattern = Pattern.compile("\\{\\S{1,}");
		Matcher matcher = responseBodyPattern.matcher(strTest);
		if (matcher.find()) {
			System.out.println(matcher.group(0));
		} else {
			System.out.println(" nothing");
		}
	}
}