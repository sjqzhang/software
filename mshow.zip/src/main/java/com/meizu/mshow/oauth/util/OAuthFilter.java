package com.meizu.mshow.oauth.util;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.oauth.OAuthAccessor;
import net.oauth.OAuthException;

import com.meizu.mshow.common.SessionConstants;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.servlet.SystemContextListener;

/**
 * 
 * <b>类名称：</b>OAuthFilter<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-30 下午5:07:45<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */
public class OAuthFilter implements Filter {
	// private static final String SESSION_FILTER_APPLIED =
	// "__SESSION_FILTER_APPLIED__";

	protected RequestAuthTokenValidator provider = null;

	protected boolean DESTROY_ON_EXCEPTION = true;

	/**
	 * @see javax.servlet.Filter#destroy()
	 */
	@Override
	public void destroy() {

	}

	/**
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		doFilter((HttpServletRequest) request, (HttpServletResponse) response, chain);
	}

	private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
		// 屏蔽掉Session。
		// request.setAttribute(SESSION_FILTER_APPLIED, Boolean.TRUE);
		try {
			OAuthAccessor acc = provider.validateAccess(request);
			response.getWriter().write(SessionConstants.SEESION_COOKIEID + "=" + acc.getProperty("sessionId").toString());
			response.flushBuffer();
			return;
			// chain.doFilter(request, response);
		} catch (OAuthException e) {
			if (DESTROY_ON_EXCEPTION) {
				OAuthExceptionHelper.handleException(e, request, response, true);
			}
		} catch (ApplicationException wow) {
			OAuthExceptionHelper.handleBizException(wow, request, response);
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof ApplicationException) {
				OAuthExceptionHelper.handleBizException((ApplicationException) e.getCause(), request, response);
			} else {
				OAuthExceptionHelper.handleNormalException(e, request, response);
			}
		} finally {
			if (DESTROY_ON_EXCEPTION) {
				// Context.destroy();
			}
			// request.removeAttribute(SESSION_FILTER_APPLIED);
		}
	}

	/**
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	@Override
	public void init(FilterConfig config) throws ServletException {
		if (provider == null) {
			provider = (RequestAuthTokenValidator) SystemContextListener.getBeanByName("requestAuthTokenValidator");

		}
	}

}
