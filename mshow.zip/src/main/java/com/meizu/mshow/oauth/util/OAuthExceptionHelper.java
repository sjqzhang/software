/**
 * <b>项目名：</b>mshow<br/>
 * <b>文件名：</b>OAuthExceptionHelper.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>修改时间：</b>2013-1-9 下午4:48:38<br/>
 * <b>Copyright (c)</b> 2013魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.oauth.util;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.oauth.OAuthProblemException;
import net.oauth.http.HttpMessage;
import net.oauth.server.OAuthServlet;

import org.apache.log4j.Logger;
import org.springframework.web.util.HtmlUtils;

import com.meizu.mshow.common.exception.ApplicationException;

/**
 * <b>类名称：</b>OAuthExceptionHelper<br/>
 * <b>类描述：异常处理</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-9 下午4:48:38<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */
public class OAuthExceptionHelper {
	public static final Logger logger = Logger.getLogger(OAuthExceptionHelper.class);

	/**
	 * 处理认证异常，会修改response的http状态为适当的值，如401未授权或者403已禁止
	 * 
	 * @param e
	 * @param request
	 * @param response
	 * @param b
	 * @throws ServletException
	 * @throws IOException
	 */
	public static void handleException(Exception e, HttpServletRequest request, HttpServletResponse response, boolean b) throws IOException, ServletException {
		String realm = (request.isSecure()) ? "https://" : "http://";
		realm += request.getLocalName();
		OAuthServlet.handleException(response, e, realm, true);
	}

	/**
	 * 处理BizException错误
	 * 
	 * @param bz
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	public static void handleBizException(ApplicationException bz, HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		sendErrorMessage(bz.getMessage(), request, response);
	}

	/**
	 * @param response
	 * @param uri
	 * @param msg
	 * @throws IOException
	 * @throws UnsupportedEncodingException
	 */
	private static void sendErrorMessage(String msg, HttpServletRequest request, HttpServletResponse response) throws IOException, UnsupportedEncodingException {
		String uri = request.getRequestURI();
		OutputStream out = response.getOutputStream();
		StringBuffer sb = new StringBuffer();
		if (uri.toLowerCase().endsWith("json")) {
			sb.append("{\"request\":").append("\"" + uri + "\"").append(",\"error\":").append("\"" + msg + "\"").append("}");
			out.write(sb.toString().getBytes("UTF-8"));
		} else {
			sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><hash><request>").append(HtmlUtils.htmlEscape(uri)).append("</request><error>").append(HtmlUtils.htmlEscape(msg)).append("</error></hash>");
			out.write(sb.toString().getBytes("UTF-8"));
		}
	}

	/**
	 * 产生认证异常。
	 * 
	 * @param problem
	 * @param code
	 *            HTTP状态码。
	 * @throws OAuthProblemException
	 */
	public static void raiseAuthException(String problem, int code) throws OAuthProblemException {
		OAuthProblemException e = new OAuthProblemException(problem);
		e.setParameter(HttpMessage.STATUS_CODE, code);
		throw e;
	}

	/**
	 * 产生未授权异常，http状态码401
	 * 
	 * @param problem
	 * @throws OAuthProblemException
	 */
	public static void raise401(String problem) throws OAuthProblemException {
		raiseAuthException(problem, HttpServletResponse.SC_UNAUTHORIZED);
	}

	/**
	 * 产生未禁止异常， http状态码403
	 * 
	 * @param problem
	 * @throws OAuthProblemException
	 */
	public static void raise403(String problem) throws OAuthProblemException {
		raiseAuthException(problem, HttpServletResponse.SC_FORBIDDEN);
	}

	/**
	 * 处理服务器内部异常，HTTP状态置为500
	 * 
	 * @param e
	 * @param request
	 * @param response
	 * @throws IOException
	 * @throws UnsupportedEncodingException
	 */
	public static void handleNormalException(Exception e, HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException, IOException {
		response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		sendErrorMessage(System.currentTimeMillis() + ":" + e.getMessage(), request, response);
		logger.error(e.getMessage(), e);
	}
}
