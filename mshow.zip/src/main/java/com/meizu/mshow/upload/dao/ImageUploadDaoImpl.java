/**
 * 
 */
package com.meizu.mshow.upload.dao;

import org.springframework.stereotype.Repository;

import com.meizu.mshow.common.base.BaseDao;
import com.meizu.mshow.domain.form.TImgBreakpoint;

/**
 * @author anyuan
 * @version 1.0
 * @date 2013-5-28 上午11:17:42
 */
@Repository("imageUploadDao")
public class ImageUploadDaoImpl extends BaseDao implements ImageUploadDao {


	/* (non-Javadoc)
	 * @see com.meizu.mshow.upload.dao.ImageUploadDao#insert(com.meizu.mshow.domain.form.TImgBreakpoint)
	 */
	@Override
	public int insert(TImgBreakpoint breakpoint) {
		return this.getSqlSession().insert("TImgBreakpoint.insertBreakpoint", breakpoint);		
	}
}
