package com.meizu.mshow.upload.business;

import com.meizu.mshow.domain.form.TImgBreakpoint;

/**
 * @author	anyuan
 * @version	1.0
 * @date	2013-5-28   上午10:19:26
 */
public interface ImageUploadService {	
	
	/**
	 * 获取文件当前上传的位置
	 * @param fileId
	 * @param isPre
	 * @return
	 */
	String getUploadPos(String fileId,boolean isPre);
	
	/**
	 * 定位文件位置
	 * @param fileName
	 * @param nPos
	 */
	void seek(String fileName,long nPos);
	
	/**
	 * 将文件写到文件服务器
	 * @param b
	 * @param nPos
	 * @param nLen
	 * @return
	 */
	int writeFile(byte[] b, int nPos,int nLen);
	
	/**
	 * 保存文件信息到db
	 * @param breakpoint
	 */
	void save(TImgBreakpoint breakpoint, long nPos);
}
