/**
 * 
 */
package com.meizu.mshow.upload.business;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.meizu.mshow.common.cache.RedisUtil;
import com.meizu.mshow.domain.form.TImgBreakpoint;
import com.meizu.mshow.upload.dao.ImageUploadDao;

/**
 * 在redis中只记录文件上传的位置，上传的数据包直接保存到文件服务器上， 整个文件上传结束后，将文件信息写入DB，同时删除redis缓存
 * 
 * @author anyuan
 * @version 1.0
 * @date 2013-5-28 上午10:32:55
 */
@Service("imageUploadService")
public class ImageUploadServiceImpl implements ImageUploadService {

	private static final Logger log = Logger
			.getLogger(ImageUploadService.class);
	@Autowired
	@Qualifier("imageUploadDao")
	private ImageUploadDao imageUploadDao;
	private RandomAccessFile oSavedFile;

	@Override
	public String getUploadPos(String fileId, boolean isPre) {
		String pos = null;
		RedisUtil redis = new RedisUtil();
		if (isPre) {
			// 预上传
			if (fileId != null && fileId.length() > 0) {
				pos = redis.getString(fileId);
				if (pos == null || pos.length() == 0) {
					pos = UUID.randomUUID().toString();
					redis.setString(pos, "0");
				}
			} else {
				pos = UUID.randomUUID().toString();
				redis.setString(pos, "0");
			}
		} else {
			// 正式上传
			if (fileId != null && fileId.length() > 0) {
				pos = redis.getString(fileId);
			}
		}

		return pos;
	}

	@Override
	public void seek(String fileName, long nPos) {
		try {
			// 文件目录不存在，则先新建
			File f = new File(fileName);
			if (!f.getParentFile().exists()) {
				f.getParentFile().mkdirs();
			}

			oSavedFile = new RandomAccessFile(fileName, "rw");
			oSavedFile.seek(nPos);
		} catch (FileNotFoundException e) {
			log.error("ImageUploadServiceImpl.seek异常：", e);
		} catch (IOException e) {
			log.error("ImageUploadServiceImpl.seek异常：", e);
		}
	}

	@Override
	public int writeFile(byte[] b, int nPos, int nLen) {
		int n = -1;
		try {
			oSavedFile.write(b, nPos, nLen);
			n = nLen;
		} catch (FileNotFoundException e) {
			log.error("ImageUploadServiceImpl.writeFile异常：", e);
		} catch (IOException e) {
			log.error("ImageUploadServiceImpl.writeFile异常：", e);
		}

		return n;
	}

	@Override
	public void save(TImgBreakpoint breakpoint, long nPos) {
		if (oSavedFile != null) {
			try {
				oSavedFile.close();
				oSavedFile = null;
			} catch (IOException e) {
				log.error("关闭文件出错：" + e.getMessage());
			}
		}
		RedisUtil redis = new RedisUtil();
		if (nPos > 0) {
			redis.setString(breakpoint.getFingerprint(), String.valueOf(nPos));
		} else {
			imageUploadDao.insert(breakpoint);
			redis.delete(new String[] { breakpoint.getFingerprint() });
		}
	}
}
