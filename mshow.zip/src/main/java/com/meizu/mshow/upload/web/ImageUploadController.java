/**
 * 
 */
package com.meizu.mshow.upload.web;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.meizu.mshow.common.ApplicationConfig;
import com.meizu.mshow.common.BusinessConstants;
import com.meizu.mshow.common.base.BaseController;
import com.meizu.mshow.common.base.BaseResultModel;
import com.meizu.mshow.common.exception.ErrorCode;
import com.meizu.mshow.common.security.SecurityAnnotation;
import com.meizu.mshow.common.util.DateUtil;
import com.meizu.mshow.domain.form.TImgBreakpoint;
import com.meizu.mshow.upload.business.ImageUploadService;

/**
 * 文件断点续传
 * 
 * @author anyuan
 * @version 1.0
 * @date 2013-5-28 上午9:25:04
 */
@Controller
public class ImageUploadController extends BaseController {

	private static final Logger log = Logger
			.getLogger(ImageUploadController.class);

	@Autowired
	@Qualifier("imageUploadService")
	private ImageUploadService imageUploadService;

	private String uploadPath = ApplicationConfig.getInstance().getProperty(
			BusinessConstants.SYS_UPLOAD_DIR);

	/**
	 * 文件上传
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/browser/upload")
	@ResponseBody
	//@SecurityAnnotation
	public BaseResultModel upload(HttpServletRequest request,
			HttpServletResponse response) {
		BaseResultModel result = new BaseResultModel();
		try {
			String fileId = request.getParameter("fileId");
			String pos = imageUploadService.getUploadPos(fileId, false);
			if (pos != null && pos.length() > 0) {
				long nPos = Long.parseLong(request.getParameter("nPos"));
				long nLen = Long.parseLong(request.getParameter("nLen"));
				if (nPos < nLen) {
					long userId = this.getUserId(request);
					String fileName = request.getParameter("fileName");
					long cdate = Long.parseLong(request.getParameter("cdate"));
					String filePath = uploadPath + userId;
					log.debug(String.format("upload前:fileId=%s,nPos=%s",
							fileId, nPos));
					imageUploadService.seek(filePath + "/" + fileName, nPos);

					// 获取数据
					int nRead = 0;
					byte[] b = new byte[4096];
					InputStream in = request.getInputStream();
					while ((nRead = in.read(b)) > 0 && nPos < nLen) {
						imageUploadService.writeFile(b, 0, nRead);
						nPos += nRead;
					}

					TImgBreakpoint breakpoint = new TImgBreakpoint();
					breakpoint.setFingerprint(fileId);
					breakpoint.setCdate(cdate);
					breakpoint.setFileName(fileName);
					breakpoint.setTmpPath(filePath);
					breakpoint
							.setCreateTime(DateUtil.getNow().getTime() / 1000);
					breakpoint
							.setUpdateTime(DateUtil.getNow().getTime() / 1000);
					breakpoint.setUserId(userId);
					breakpoint.setFileSize(nPos);
					breakpoint.setStatus(0);

					if (nPos < nLen) {
						// 文件未上传结束，将当前位置保存到redis
						imageUploadService.save(breakpoint, nPos);
					} else {
						// 文件上传结束，将文件信息写入DB，并删除redis记录
						imageUploadService.save(breakpoint, 0);
					}
					log.debug(String.format("upload后:fileId=%s,nPos=%s",
							fileId, nPos));
				} else {
					result.setReturnCode(ErrorCode.UPLOAD_PARAMETER_ERROR);
					result.setReturnMessage("参数错误：文件位置大于总长度");
				}
			} else {
				result.setReturnCode(ErrorCode.UPLOAD_PARAMETER_ERROR);
				result.setReturnMessage("参数错误：文件指纹不存在");
			}

		} catch(IllegalArgumentException e){
			log.error("文件上传参数错误：", e);
			result.setReturnCode(ErrorCode.UPLOAD_PARAMETER_ERROR);
			result.setReturnMessage("参数错误：" + e.getMessage());
		}catch (IOException e) {
			log.error("文件上传出现异常：", e);
			result.setReturnCode(ErrorCode.UPLOAD_SERVER_ERROR);
			result.setReturnMessage("文件上传出现IO异常：" + e.getMessage());
		}

		return result;
	}

	/**
	 * 文件预上传
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/browser/preupload")
	@ResponseBody
	//@SecurityAnnotation
	public BaseResultModel preUpload(HttpServletRequest request,
			HttpServletResponse response) {

		String fileId = request.getParameter("fileId");
		String pos = imageUploadService.getUploadPos(fileId, true);
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(pos);

		return model;
	}
}
