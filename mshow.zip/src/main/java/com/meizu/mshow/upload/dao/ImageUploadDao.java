/**
 * 
 */
package com.meizu.mshow.upload.dao;

import com.meizu.mshow.domain.form.TImgBreakpoint;

/**
 * @author	anyuan
 * @version	1.0
 * @date	2013-5-28   上午10:39:08
 */
public interface ImageUploadDao {
	
	int insert(TImgBreakpoint breakpoint);
}
