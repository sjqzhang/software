/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.system.dao<br/>
 * <b>文件名：</b>UploadSettingDao.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2012-12-4-上午11:10:07<br/>
 * <b>Copyright (c)</b> 2012魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.system.dao;

import com.meizu.mshow.domain.pojo.UploadSetting;

/**
 * <b>类名称：</b>UploadSettingDao<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-4 上午11:10:07<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public interface UploadSettingDAO {

	/**
	 * getSettingByFileClass<br/>
	 * 方法描述：根据文件分类返回目录配置信息 <br/>
	 * 
	 * @param fileClass
	 * @return UploadSetting
	 * @exception
	 * @since 1.0.0
	 */

	public UploadSetting getSettingByFileClass(String fileClass);

	/**
	 * addSetting<br/>
	 * 方法描述：新增文件上传 <br/>
	 * 
	 * @param setting
	 *            void
	 * @exception
	 * @since 1.0.0
	 */

	public void createSetting(UploadSetting setting);

}
