/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.system.web<br/>
 * <b>文件名：</b>Systemcontroller.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2012-12-18-下午2:44:26<br/>
 * <b>Copyright (c)</b> 2012魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.system.web;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.meizu.mshow.common.base.BaseController;
import com.meizu.mshow.common.base.BaseResultModel;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.ip.CityInfo;
import com.meizu.mshow.common.ip.IPApi;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.common.util.StringUtil;
import com.meizu.mshow.domain.model.SearchModel;
import com.meizu.mshow.picture.business.PictureService;
import com.meizu.mshow.system.business.SystemService;
import com.meizu.mshow.user.business.UserService;

/**
 * <b>类名称：</b>Systemcontroller<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-18 下午2:44:26<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */
@Controller
@RequestMapping(value = "/browser")
public class Systemcontroller extends BaseController {

	@Autowired
	@Qualifier("userService")
	private UserService userService;
	@Autowired
	@Qualifier("pictureService")
	private PictureService pictureService;

	@Autowired
	@Qualifier("systemService")
	private SystemService systemService;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/search/user")
	public @ResponseBody
	BaseResultModel seachUser(@RequestParam("keyWord") String keyWord, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		QueryModel query = loadQueryModel(request);
		Map map = query.getCondition(Map.class);
		StringUtil.makeSphinxString(keyWord, map);
		SearchModel searchModel = this.userService.searchUser(query);
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(searchModel);
		return model;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/search/tag")
	public @ResponseBody
	BaseResultModel seachTag(@RequestParam("keyWord") String keyWord, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		QueryModel query = loadQueryModel(request);
		Map map = query.getCondition(Map.class);
		StringUtil.makeSphinxString(keyWord, map);
		SearchModel searchModel = this.pictureService.searchTag(query);
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(searchModel);
		return model;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/search/photo")
	public @ResponseBody
	BaseResultModel searchPicture(@RequestParam("keyWord") String keyWord, long start, int limit, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		QueryModel query = loadQueryModel(request);
		Map map = query.getCondition(Map.class);
		StringUtil.makeSphinxString(keyWord, map);
		SearchModel searchModel = this.pictureService.searchPicture(query);
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(searchModel);
		return model;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/system/getcity")
	public @ResponseBody
	BaseResultModel getCity(@RequestParam("pid") String pid, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		QueryModel query = loadQueryModel(request);
		Map map = query.getCondition(Map.class);
		map.put("pid", pid);
		List<Map> list = systemService.getCityById(query);
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(list);
		return model;
	}

	@RequestMapping(value = "/system/getcityinfo")
	public @ResponseBody
	BaseResultModel getCityInfo(HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		CityInfo city = IPApi.getCityInfoByIp(this.getRemoteIp(request));
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(city);
		return model;
	}

}
