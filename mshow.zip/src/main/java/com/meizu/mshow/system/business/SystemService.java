/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.system.dao<br/>
 * <b>文件名：</b>SystemDAO.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2013-1-5-上午10:08:08<br/>
 * <b>Copyright (c)</b> 2013魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.system.business;

import java.util.List;
import java.util.Map;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.pojo.TBsArea;
import com.meizu.mshow.domain.pojo.TSysUpdate;

/**
 * <b>类名称：</b>SystemDAO<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-5 上午10:08:08<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */

public interface SystemService {
	/**
	 * 
	 * <b>创建人：</b>张军强<br/>
	 * checkUpdate<br/>
	 * <b>方法描述：检查系统更新</b> <br/>
	 * 
	 * @param query
	 * @return TSysUpdate
	 * @exception
	 * @since 1.0.0
	 */
	public TSysUpdate checkUpdate(QueryModel query);

	/**
	 * 
	 * <b>创建人：</b>张军强<br/>
	 * loadByFingerprint<br/>
	 * <b>方法描述：按指纹取文件</b> <br/>
	 * 
	 * @param query
	 * @return Map<String,Object>
	 * @exception
	 * @since 1.0.0
	 */
	public Map<String, Object> loadByFingerprint(QueryModel query);

	@SuppressWarnings("rawtypes")
	public List<Map> getProvice();

	@SuppressWarnings("rawtypes")
	public List<Map> getCityById(QueryModel query);

	public TBsArea loadTBsAreaViaCityName(String cityName);
}
