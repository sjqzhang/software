/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.system.dao<br/>
 * <b>文件名：</b>UploadSettingDAOImpl.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2012-12-4-上午11:19:10<br/>
 * <b>Copyright (c)</b> 2012魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.system.dao;

import java.util.HashMap;

import org.springframework.stereotype.Repository;

import com.meizu.mshow.common.base.BaseDao;
import com.meizu.mshow.common.util.BeanUtils;
import com.meizu.mshow.domain.pojo.UploadSetting;

/**
 * <b>类名称：</b>UploadSettingDAOImpl<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-4 上午11:19:10<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */
@Repository("uploadSettingDAO")
public class UploadSettingDAOImpl extends BaseDao implements UploadSettingDAO {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.system.dao.UploadSettingDAO#getSettingByFileClass(java
	 * .lang.String)
	 */

	@Override
	public UploadSetting getSettingByFileClass(String fileClass) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("fileClass", fileClass);
		HashMap<String, Object> retMap = this.getSqlSession().selectOne(
				"UploadSetting.getSettingByFileClass", map);

		if (retMap != null) {
			UploadSetting us = new UploadSetting();
			us.setFilePath(retMap.get("filePath").toString());
			us.setFileCount(Integer.valueOf(retMap.get("fileCount").toString()));
			us.setFileMax(Integer.valueOf(retMap.get("fileMax").toString()));
			us.setFileDir(retMap.get("fileDir").toString());
			// us.setIsActive(retMap.get("isActive").toString() == "1" ? true
			// : false);
			us.setIsActive(1);
			return us;
		} else {
			return null;
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.system.dao.UploadSettingDAO#addSetting(com.meizu.mshow
	 * .domain.pojo.UploadSetting)
	 */

	@Override
	public void createSetting(UploadSetting setting) {

		HashMap<String, Object> map = new HashMap<String, Object>();
		setting.setFileDir(getNextMaxDir(setting.getFileClass(),
				setting.getFilePath()));
		BeanUtils.pojoToMap(setting, map);
		this.getSqlSession().insert("UploadSetting.addSetting", map);

	}

	private String getNextMaxDir(String fileClass, String filePath) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("fileClass", fileClass);
		map.put("filePath", filePath);
		Object obj = this.getSqlSession().selectOne("UploadSetting.getMaxDir",
				map);
		if (obj == null) {
			return String.format("%1$,08d", 1);
		} else {
			Integer id = 0;
			try {
				id = Integer.valueOf(obj.toString());
				id = id + 1;
			} catch (Exception e) {
				id = id + 1;
			}
			return String.format("%1$,08d", id);
		}
	}

}
