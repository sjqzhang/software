/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.system.web<br/>
 * <b>文件名：</b>Systemcontroller.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2012-12-18-下午2:44:26<br/>
 * <b>Copyright (c)</b> 2012魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.system.web;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.meizu.mshow.common.base.BaseController;
import com.meizu.mshow.common.base.BaseResultModel;
import com.meizu.mshow.common.cache.CacheCategory;
import com.meizu.mshow.common.cache.DBCache;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.common.util.StringUtil;
import com.meizu.mshow.domain.model.SearchModel;
import com.meizu.mshow.domain.pojo.TSysUpdate;
import com.meizu.mshow.picture.business.PictureService;
import com.meizu.mshow.system.business.SystemService;
import com.meizu.mshow.user.business.UserService;

/**
 * <b>类名称：</b>Systemcontroller<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-18 下午2:44:26<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */
@Controller
@RequestMapping(value = "/android")
public class SystemAndroidController extends BaseController {
	@SuppressWarnings("unused")
	private static final Logger logger = Logger.getLogger(SystemAndroidController.class);
	@Autowired
	@Qualifier("userService")
	private UserService userService;
	@Autowired
	@Qualifier("pictureService")
	private PictureService pictureService;

	@Autowired
	@Qualifier("systemService")
	private SystemService systemService;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/search/user")
	public @ResponseBody
	BaseResultModel seachUser(@RequestParam("keyWord") String keyWord, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		QueryModel query = loadQueryModel(request);
		Map map = query.getCondition(Map.class);
		StringUtil.makeSphinxString(keyWord, map);
		SearchModel searchModel = this.userService.searchUser(query);
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(searchModel);
		return model;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/search/tag")
	public @ResponseBody
	BaseResultModel seachTag(@RequestParam("keyWord") String keyWord, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		QueryModel query = loadQueryModel(request);
		Map map = query.getCondition(Map.class);
		StringUtil.makeSphinxString(keyWord, map);
		SearchModel searchModel = this.pictureService.searchTag(query);
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(searchModel);
		return model;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/search/photo")
	public @ResponseBody
	BaseResultModel searchPicture(@RequestParam("keyWord") String keyWord, long start, int limit, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		QueryModel query = loadQueryModel(request);
		Map map = query.getCondition(Map.class);
		StringUtil.makeSphinxString(keyWord, map);
		SearchModel searchModel = this.pictureService.searchPicture(query);
		BaseResultModel model = new BaseResultModel();
		model.setReturnValue(searchModel);
		return model;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/system/checkUpdate")
	@DBCache(keyPrefix = "sysupdate_", key = "{#p[0]}", ttl = 3600, category = CacheCategory.Web)
	public @ResponseBody
	BaseResultModel checkUpdate(@RequestParam("version") String version, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel resultModel = new BaseResultModel();
		QueryModel query = loadQueryModel(request);
		Map map = query.getCondition(Map.class);
		map.put("version", version);
		TSysUpdate sysUpdate = this.systemService.checkUpdate(query);
		if (sysUpdate != null) {
			sysUpdate.setSrcVersion(version);
		}
		resultModel.setReturnValue(sysUpdate);
		return resultModel;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/system/loadByFingerprint")
	@DBCache(keyPrefix = "sysupdate_", key = "{#p[0]}", ttl = 3600, category = CacheCategory.Web)
	public @ResponseBody
	BaseResultModel loadByFingerprint(@RequestParam("fingerprint") String fingerprint, HttpServletRequest request, HttpServletResponse response) throws ApplicationException, IOException {
		BaseResultModel resultModel = new BaseResultModel();
		QueryModel query = loadQueryModel(request);
		Map map = query.getCondition(Map.class);
		map.put("fingerprint", fingerprint);
		Map<String, Object> retval = this.systemService.loadByFingerprint(query);
		resultModel.setReturnValue(retval);
		return resultModel;

	}

}
