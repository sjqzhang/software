/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.system.business<br/>
 * <b>文件名：</b>SystemServiceImpl.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2013-1-5-上午10:57:50<br/>
 * <b>Copyright (c)</b> 2013魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.system.business;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.pojo.TBsArea;
import com.meizu.mshow.domain.pojo.TSysUpdate;
import com.meizu.mshow.system.dao.SystemDAO;

/**
 * <b>类名称：</b>SystemServiceImpl<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-5 上午10:57:50<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */
@Service("systemService")
public class SystemServiceImpl implements SystemService {

	@Autowired
	SystemDAO systemDAO;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.system.business.SystemService#checkUpdate(com.meizu.mshow
	 * .common.util.QueryModel)
	 */
	@Override
	public TSysUpdate checkUpdate(QueryModel query) {
		return this.systemDAO.checkUpdate(query);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.system.business.SystemService#loadByFingerprint(com.meizu
	 * .mshow.common.util.QueryModel)
	 */

	@Override
	public Map<String, Object> loadByFingerprint(QueryModel query) {
		return this.systemDAO.loadByFingerprint(query);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.meizu.mshow.system.business.SystemService#getProvice()
	 */

	@SuppressWarnings("rawtypes")
	@Override
	public List<Map> getProvice() {
		return this.systemDAO.getProvice();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.meizu.mshow.system.business.SystemService#getCityById(long)
	 */

	@SuppressWarnings("rawtypes")
	@Override
	public List<Map> getCityById(QueryModel query) {
		return this.systemDAO.getCityById(query);
	}

	private TBsArea loadCacheTBsAreaViaCityName(String cityName)  {
		TBsArea area = this.systemDAO.loadTBsAreaViaCityName(cityName);
		return area;
	}

	@Override
	public TBsArea loadTBsAreaViaCityName(String cityName)  {
		TBsArea area = this.loadCacheTBsAreaViaCityName(cityName);

		if (area != null) {
			long lng = (long) (area.getLng() * 100) * 10000 + Math.round(Math.random() * 8999 + 1000);
			long lat = (long) (area.getLat() * 100) * 10000 + Math.round(Math.random() * 8999 + 1000);
			area.setLat(lat / 1000000.0);
			area.setLng(lng / 1000000.0);
		}
		return area;
	}

}
