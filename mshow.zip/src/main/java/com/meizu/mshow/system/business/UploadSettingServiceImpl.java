/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.system.business<br/>
 * <b>文件名：</b>UploadSettingService.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2012-12-4-上午11:06:39<br/>
 * <b>Copyright (c)</b> 2012魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.system.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.meizu.mshow.domain.pojo.UploadSetting;
import com.meizu.mshow.system.dao.UploadSettingDAO;

/**
 * <b>类名称：</b>UploadSettingService<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2012-12-4 上午11:06:39<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */
@Service("uploadSettingService")
public class UploadSettingServiceImpl implements UploadSettingService {

	@Autowired
	private UploadSettingDAO uploadSettingDAO;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.meizu.mshow.system.business.UploadSettingServiceImpl#
	 * getSettingByFileClass(java.lang.String)
	 */

	@Override
	public UploadSetting getSettingByFileClass(String fileClass) {

		return getUploadSettingDAO().getSettingByFileClass(fileClass);

	}

	public UploadSettingDAO getUploadSettingDAO() {
		return uploadSettingDAO;
	}

	public void setUploadSettingDAO(UploadSettingDAO uploadSettingDAO) {
		this.uploadSettingDAO = uploadSettingDAO;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.system.business.UploadSettingService#addSetting(com.meizu
	 * .mshow.domain.pojo.UploadSetting)
	 */

	@Override
	public void createSetting(UploadSetting setting) {

		uploadSettingDAO.createSetting(setting);

	}

}
