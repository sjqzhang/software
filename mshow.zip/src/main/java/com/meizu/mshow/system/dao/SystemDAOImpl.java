/**
 * <b>项目名：</b>mshow<br/>
 * <b>包名：</b>com.meizu.mshow.system.dao<br/>
 * <b>文件名：</b>SystemDAOImpl.java<br/>
 * <b>版本信息：</b> @version 1.0.0<br/>
 * <b>日期：</b>2013-1-5-上午10:11:22<br/>
 * <b>Copyright (c)</b> 2013魅族公司-版权所有<br/>
 *
 */

package com.meizu.mshow.system.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.meizu.mshow.common.base.BaseDao;
import com.meizu.mshow.common.cache.DBCache;
import com.meizu.mshow.common.cache.DBCacheOperation;
import com.meizu.mshow.common.util.BeanUtils;
import com.meizu.mshow.common.util.CacheKeyUtil;
import com.meizu.mshow.common.util.QueryModel;
import com.meizu.mshow.domain.pojo.TBsArea;
import com.meizu.mshow.domain.pojo.TSysBadwords;
import com.meizu.mshow.domain.pojo.TSysUpdate;

/**
 * <b>类名称：</b>SystemDAOImpl<br/>
 * <b>类描述：</b>
 * 
 * <pre>
 </pre>
 * 
 * <br/>
 * <b>创建人：</b>张军强<br/>
 * <b>修改人：</b>张军强<br/>
 * <b>修改时间：</b>2013-1-5 上午10:11:22<br/>
 * <b>修改备注：</b><br/>
 * 
 * @version 1.0.0<br/>
 */
@Repository("systemDAO")
public class SystemDAOImpl extends BaseDao implements SystemDAO {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.system.dao.SystemDAO#checkUpdate(com.meizu.mshow.common
	 * .util.QueryModel)
	 */

	@Override
	public TSysUpdate checkUpdate(QueryModel query) {

		Object obj = this.getSqlSession().selectOne("TSysUpdate.getLastUpdate", query.getCondition());

		if (obj != null) {
			return BeanUtils.map2Bean((HashMap) obj, TSysUpdate.class);
		}

		obj = this.getSqlSession().selectOne("TSysUpdate.checkUpdate", query.getCondition());
		if (obj == null) {
			return null;
		} else {
			return BeanUtils.map2Bean((HashMap) obj, TSysUpdate.class);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.system.dao.SystemDAO#loadByFingerprint(com.meizu.mshow
	 * .common.util.QueryModel)
	 */

	@Override
	public Map<String, Object> loadByFingerprint(QueryModel query) {
		return this.getSqlSession().selectOne("TImgBreakpoint.loadByFingerprint", query.getCondition());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.meizu.mshow.system.dao.SystemDAO#getCityById(com.meizu.mshow.common
	 * .util.QueryModel)
	 */

	@Override
	public List<Map> getCityById(QueryModel query) {
		return this.getSqlSession().selectList("TSysUpdate.getCityById", query.getCondition());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.meizu.mshow.system.dao.SystemDAO#getProvice()
	 */

	@Override
	public List<Map> getProvice() {

		return this.getSqlSession().selectList("TSysUpdate.getProvice");
	}

	@Override
	@DBCache(keyPrefix = CacheKeyUtil.P_LOCATION, key = "#p[0]", ttl = 3000, op = DBCacheOperation.SELECT)
	public TBsArea loadTBsAreaViaCityName(String cityName) {
		Map map = new HashMap<String, String>();
		map.put("cityName", cityName);
		List list = this.getSqlSession().selectList("TBsArea.loadTBsAreaViaCityName", map);
		if (list != null && list.size() > 0) {
			return (TBsArea) list.get(0);
		} else {
			list = this.getSqlSession().selectList("TBsArea.loadTBsAreaViaSubCityName", map);
			if (list != null && list.size() > 0)
				return (TBsArea) list.get(0);
			else
				return null;
		}
	}

	@Override
	public List<TSysBadwords> loadAllBadwords() {
		return this.getSqlSession().selectList("TSysBadwords.loadAllBadwords");
	}
}
