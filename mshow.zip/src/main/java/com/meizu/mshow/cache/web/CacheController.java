package com.meizu.mshow.cache.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.meizu.mshow.common.ApplicationConfig;
import com.meizu.mshow.common.base.BaseController;
import com.meizu.mshow.common.base.BaseResultModel;
import com.meizu.mshow.common.cache.RedisUtil;
import com.meizu.mshow.common.exception.ApplicationException;
import com.meizu.mshow.common.exception.ErrorCode;
import com.meizu.mshow.common.util.BadWordsUtil;
import com.meizu.mshow.common.util.CacheKeyUtil;
import com.meizu.mshow.user.dao.UserDAOImpl;

@Controller
public class CacheController extends BaseController {
	Logger logger = Logger.getLogger(UserDAOImpl.class);

	@RequestMapping(value = "/cache/flush")
	public @ResponseBody
	BaseResultModel flushImg(HttpServletRequest request, HttpServletResponse response) {
		String ip = getRemoteIp(request);
		String action = request.getParameter("action");
		// security check
		String configIps[] = ApplicationConfig.getInstance().getProperty("console.ip").split(",");
		boolean validate = false;
		for (int i = 0; configIps != null && configIps.length > 0 && i < configIps.length; i++) {
			if (ip.equals(configIps[i])) {
				validate = true;
				break;
			}
		}
		if (!validate)
			throw new ApplicationException(ErrorCode.SECURITY_FAIL);
		if (action != null && action.equals("img")) {
			String[] imgIds = request.getParameterValues("imgId");
			logger.info(ip + imgIds.toString());
			if (imgIds != null && imgIds.length > 0) {
				for (int i = 0; i < imgIds.length; i++) {
					try {
						Long imgId = Long.parseLong(imgIds[i]);
						RedisUtil ru = new RedisUtil();
						ru.expire(CacheKeyUtil.getPictureKey(imgId), 0);
					} catch (Exception e) {
						logger.warn("imgid:" + imgIds[i] + "is not number!");
					}
				}
			}
		} else if (action != null && action.equals("badwords")) {
			BadWordsUtil.reloadBadWords();
		}
		return new BaseResultModel();
	}
}
