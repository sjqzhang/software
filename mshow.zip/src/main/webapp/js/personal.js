﻿CommonPage.prototype = {
	_loadData : function(){
		  var that = this;
		  var lastItem = $(".cont_photo a>img:last").attr("id");
		  var likeId = $(".cont_photo a>img:last").attr("attribute");
		  //var lastMsg = $(".msgitem_personal:last").attr("id");
		  var fillUrl = "";
		  that._isloading = true;
		  $("#loaderTip").show();
		  if(that._page == "self"){
			  var aURL = that._showType+'?start='+that._picPage*that._imgLimitNum+'&limit='+that._imgLimitNum;
			  switch(that._showType){
				/*case "showmsg":	
					if(lastMsg){
						fillUrl = baseURL + 'user/'+aURL+'pageForwar=desc&posId='+lastMsg;
					}else{
						fillUrl = baseURL + 'user/'+aURL;
					}
					break;*/
				case "selflike":
					if(lastItem){
						fillUrl = baseURL + 'photo/'+aURL+'&pageForwar=desc&posId='+likeId;
					}else{
						fillUrl = baseURL + 'photo/'+aURL;
					}
					break;
				case "selfpost":
					if(lastItem){
						fillUrl = baseURL + 'photo/'+aURL+'&pageForwar=desc&posId='+lastItem;
					}else{
						fillUrl = baseURL + 'photo/'+aURL;
					}
			  }
		  }else{
			  var bURL = 'photo/'+that._showType+'?userId='+that._userId+'&start='+that._picPage*that._imgLimitNum+'&limit='+that._imgLimitNum;
			  switch(that._showType){
				case "showpost":
					if(lastItem){
						fillUrl = baseURL + bURL+'&pageForwar=desc&posId='+lastItem;
					}else{
						fillUrl = baseURL + bURL;
					}
					break;
				case "showlike":
					if(lastItem){
						fillUrl = baseURL + bURL+'&pageForwar=desc&posId='+likeId;
					}else{
						fillUrl = baseURL + bURL;
					}
			  }
		  }
		  Web.fill(fillUrl,{'after':function(data){
			if(data != "" && data != null){
				/*if(that._showType == "showmsg"){
					$(".personaltab_mshow").css("margin","0px");
					$(".squarecont_mshow ul").css("margin-left","0px");
					msgFun(".squarecont_mshow ul",data);
					replyFun(".replybtn_msgitem",".msgitem_personal","comboxwrap_personal","_msg");
				}else{
					$(".personaltab_mshow").css("margin-bottom","30px");
					$(".squarecont_mshow ul").css("margin-left","-5px");
					that._photoFun(".squarecont_mshow ul",".item_photo img",350,960,20,data);
				}
				that._picPage = that._picPage+1;
				that._isloading = false;
				$("#loaderTip").hide();
				errorHeadFun($(".userhead_infophoto img"));
				errorHeadFun($(".userhead_msgitem img"));*/
				$(".personaltab_mshow").css("margin-bottom","30px");
				$(".squarecont_mshow ul").css("margin-left","-5px");
				that._photoFun(".squarecont_mshow ul",".item_photo img",350,960,20,data);
				that._picPage = that._picPage+1;
				that._isloading = false;
				$("#loaderTip").hide();
				errorHeadFun($(".userhead_infophoto img"));
			}else{
				$("#loaderTip").html("没有更多内容了");
			}
		  }});
	},
	_personalLabel : function(){
		var that = this;
		Web.fill(baseURL + 'user/pinedtags?userId='+that._userId+'&start=0&limit='+that._tagLimitNum,'',{'after':function(array){
			for ( var i = 0; i < array.length; i++) {
				if(array[i].tagName){
					defaultLabel(".label_personal ul",".item_label",5,25,array[i].tagName,array[i].tagId,510);
				}else{
					return false;	
				}
			}
		}});
	},
	_personalData : function(){
		var that = this;
		that._userId = Web.request('userId')
		Web.fill(baseURL + 'user/view?userId='+that._userId,'#userinfo_personal',{'before':function(data){
			$("#username_bread").text(data.user.aliasName);
			if(data.user.headIcon == null){
				data.user.headIcon = defaultHeadIcon;
			}
			return data['user'];																				  
		},'after':function(array){
			var signature = array.comment == null?"":array.comment;
			var cont = ['<div class="userhead_personal" id="userhead_personal"><img src="'+array.headIcon+'"/></div>',
           				'<div class="infocont_personal">',
                		'<h3 id="username_personal" title="'+array.aliasName+'">'+array.aliasName+'</h3>',
                		'<p>照片数：<span id="picnum_personal">'+array.imgCount+'</span>张</p>',
						'<p>'+signature+'</p>',
            			'</div>'];
			var endCont = cont.join("");
			$("#userinfo_personal").append(endCont);
			errorHeadFun($(".userhead_personal img"));
		}});
	},
	/*标签页切换*/
	_tabSwitch : function(tabItems,tabCur){
		var that = this;
		tabItems.click(function(){
			$(this).addClass(tabCur).siblings().removeClass(tabCur);
			var tabId = $(this).attr("id");
			that._showType = tabId;
			$(".squarecont_mshow ul").html("");
			that._picPage = 0;
			if(tabId == "showmsg"){
				that._isloading = true;
				$(".personaltab_mshow").css("margin","0px");
				$(".squarecont_mshow ul").css("margin-left","0px");
				$("#loaderTip").hide();
				$("#pager").show();
				$.ajax({
					type:"POST",
					url:baseURL + 'user/showmsg?limit=10',
					dataType:"json",
					async:false,
					complete:function(msg){
						var obj=eval("("+msg.responseText+")")["returnValue"];
						var totalCount = obj.recordCount;
						msgFun(".squarecont_mshow ul",obj.result)
						pageFun(0,10,totalCount);
						replyFun(".replybtn_msgitem",".msgitem_personal","comboxwrap_personal","_msg");
						showDeleteFun(".msgitem_personal",".deletebtn_msgitem","message/delete","messageId");
					}
				})
			}else{
				$(".personaltab_mshow").css("margin-bottom","30px");
				$(".squarecont_mshow ul").css("margin-left","-5px");
				$("#pager").hide();
				that._scrollData();
			}
		})
	},
	init : function(page,type) {
		var that = this;
		that._page = page;
		that._showType = type;
		//用户信息
		this._personalData();
		//个人标签
		this._personalLabel();
		var tabType = Web.request('type');
		this._tabSwitch($(".tabnav_personal li"),"current_tabpersonal");
		if(tabType == "2"){
			$("#msgTipsBox").remove();	
			$("#showmsg").click();
		}else{
			//个人照片
			this._scrollData();
		}
		popEmoji = new popEmojiBox();
		popEmoji.init();
	}
};
//加载消息
function loadMsgFun(curPageNum,pageNum,limit){
	var fillUrl = "";
	if(curPageNum == 0){
		fillUrl = baseURL + 'user/showmsg?start=0&limit='+limit;
	}else if(pageNum>curPageNum){//如果所选择的页数大于当前的页数
		if(pageNum-curPageNum == 1){//如果是相邻页数
			var lastId = $(".msgitem_personal:last").attr("id");
			fillUrl = baseURL + 'user/showmsg?start=0&limit='+limit+'&pageForward=desc&posId='+lastId;
		}else{
			fillUrl = baseURL + 'user/showmsg?start='+(pageNum-1)*limit+'&limit='+limit;	
		}
	}else if(pageNum<curPageNum){//如果所选择的页数小于当前的页数
		if(curPageNum-pageNum == 1){//如果是相邻页数
			var firstId = $(".msgitem_personal:first").attr("id");
			fillUrl = baseURL + 'user/showmsg?start=0&limit='+limit+'&pageForward=asc&posId='+firstId;
		}else{
			fillUrl = baseURL + 'user/showmsg?start='+(pageNum-1)*limit+'&limit='+limit;	
		}
	}
	$.ajax({
		type:"POST",
		url:fillUrl,
		dataType:"json",
		async:false,
		complete:function(msg){
			var obj=eval("("+msg.responseText+")")["returnValue"];
			var totalCount = obj.recordCount;
			msgFun(".squarecont_mshow ul",obj.result);
		}
	})
}
//消息分页
function pageFun(start,limit,totalCount){
	$.extend(window['G'],{'pagenumber':1,'pageSize':limit,'totalCount':totalCount});
	window['pager'] = $('#pager').pager({
		'pagenumber' : G.pagenumber,
		'pageSize'   : G.pageSize,
		'totalCount' : G.totalCount,
		'toPage'     : 'http://flyme.meizu.com/ui/elements.jsp?pagenumber='
		,'callBack': function(p){
			var curPageNum = $(".pageDiv .selected").text();
			window['pager'].reload({'pagenumber':p,'pageSize':limit,'totalCount':totalCount});
			loadMsgFun(curPageNum,p,limit);
		}
	});
} 
//消息处理方法
function msgFun(box,data){
	var content = "";
	for ( var i = 0; i < data.length; i++){
		if(data[i].headIcon == null){data[i].headIcon = defaultHeadIcon}
		data[i].cdate = fmtDate(data[i].cdate)
		data[i].remark=emote(data[i]['remark'],'/images/emotion/emoji_'); 
		var text = data[i].messageCategory == "1"?"喜欢了你的照片":emote(data[i].comment,'/images/emotion/emoji_');
		var replyMark = data[i].replyAliasName == null?"":"@"+data[i].replyAliasName;
		var replyBtn = "";
		if(data[i].messageCategory != "1"){
			replyBtn = "回复";
		}
		var cont = ['<li class="msgitem_personal" id="'+data[i].messageId+'"> ',
					'<table cellpadding="0" cellspacing="0" class="contwrap_msgitem">',
					'<tr>',
					'<td class="userhead_msgitem touserpage_infophoto">',
					'<a href="javascript:void(0);" onclick="return false;" attribute="'+data[i].userId+'"><img src="'+data[i].headIcon+'" /></a>',
					'</td> ', 
					'<td class="cont_msgitem"> ',
					'<div class="conthead_msgitem">',
					'<span class="username_msgitem touserpage_infophoto">',
					'<a href="javascript:void(0);" onclick="return false;" attribute="'+data[i].userId+'">'+data[i].aliasName+'</a>',
					'<em class="replymark_msgitem">'+replyMark+'</em>',
					'</span>',
					'<span class="timecont_msgitem">'+data[i].cdate+'</span>',
					'</div>',
					'<div class="content_msgitem">',
					'<table cellpadding="0" cellspacing="0" style="table-layout:fixed">',
					'<tr>',
					'<td class="comcont_msgitem"><p>'+text+'</p></td>',
					'<td class="btnbar_msgitem"><span class="deletebtn_msgitem">删除</span>&nbsp;<span class="replybtn_msgitem">'+replyBtn+'</span></td>',
					'</tr>',
					'</table>',
					'</div>',
					'</td>',
					'<td><div class="photo_msgitem"><a href="'+baseHead+'/web/picdetail.html?imgId=' + data[i].imgId + '"><img attribute="'+data[i].imgId+'" src="'+data[i].minImg+'" /><input type="hidden" value="'+data[i].minWidth+'#'+data[i].minHeight+'"></a></div></td>',
					'</tr>',
					'</table>',
					'<div class="cr">&nbsp;</div>',  
					'</li>']
		var endCont = cont.join("");
		content += endCont;
	}
	$(box).html(content);
	errorHeadFun($(".userhead_msgitem img"));
	shortImage(".photo_msgitem");
}
