﻿CommonPage.prototype = {
	_loadData : function(){
		  var that = this;
		  var lastItem = $(".cont_photo a>img:last").attr("id");
		  var fillUrl = "";
		  $("#loaderTip").show();
		  that._isloading = true;
		  if(lastItem){
			  fillUrl = baseURL + 'photo/'+that._page+'?start='+that._picPage*that._imgLimitNum+'&limit='+that._imgLimitNum+'&pageForwar=desc&posId='+lastItem;
		  }else{
			  fillUrl = baseURL + 'photo/'+that._page+'?start='+that._picPage*that._imgLimitNum+'&limit='+that._imgLimitNum;
		  }
		  Web.fill(fillUrl,{'after':function(data){
			if(data != ""){
				that._photoFun(".squarecont_mshow ul",".item_photo img",350,960,20,data);
				that._picPage = that._picPage+1;
				that._isloading = false;
				$("#loaderTip").hide();
				errorHeadFun($(".userhead_infophoto img"));
			}else{
				$("#loaderTip").html("没有更多内容了");
			}
		  }});
	},
	
	_hotLabel : function(){
		var that = this;
		Web.fill(baseURL + 'tag/recommand?start=0&limit='+that._tagLimitNum,'',{'after':function(array){
			for ( var i = 0; i < array.length; i++) {
				if(array[i].tagName){
					defaultLabel(".label_square ul",".item_label",4,15,array[i].tagName,array[i].tagId,300);
				}else{
					return false;	
				}
				
			}
		}});
	},
	init : function(page) {
		var that = this;
		that._page = page;
		//热门标签
		this._hotLabel();
		//广场热门照片
		this._scrollData();
	},
	_tagPage : function(page){
		//标签下照片
		var that = this;
		that._page = page;
		that._tagPageId = Web.request('tagId');
		that._tagScrollData();
	},
	_tagScrollData : function(){
		var that = this;
		that._isloading = false;
		that._tagLoadData();
		window.onscroll=function(){
			if(!that._isloading) {
				that._testScroll();
			}
		}
	},
	_tagLoadData : function(){
		var that = this;
		  var lastItem = $(".cont_photo a>img:last").attr("id");
		  var fillUrl = "";
		  that._isloading = true;
		  $("#loaderTip").show();
		  if(lastItem){
			  fillUrl = baseURL + 'photo/'+that._page+'?tagId='+that._tagPageId+'&start='+that._picPage*that._imgLimitNum+'&limit='+that._imgLimitNum+'&pageForward=desc&posId='+lastItem;
		  }else{
			  fillUrl = baseURL + 'photo/'+that._page+'?tagId='+that._tagPageId+'&start='+that._picPage*that._imgLimitNum+'&limit='+that._imgLimitNum;
		  }
		  Web.fill(fillUrl,{'after':function(data){
			if(data != ""){
				that._photoFun(".squarecont_mshow ul",".item_photo img",350,960,20,data);
				that._picPage = that._picPage+1;
				that._isloading = false;
				$("#loaderTip").hide();
			}else{
				$("#loaderTip").html("没有更多内容了");
			}
		  }});	
	}
};
//控制台 调用方法 var ary = [sTop,sHeiht,cHeight]; mzConsole(ary);
(function(w){
	w.mzConsole = (function(){
			$(window).scroll(function(){
				var t=  document.documentElement ? document.documentElement : document.body;
				var top =  Math.max(t.scrollTop,0)+100;
				$('#mzConsoleId').css('top',top);	 
			});

			$('<div id="mzConsoleId" style="background-color:#fff;position:absolute;top:0px;left:50px;width:300px;height:100px;border:solid 1px red;display:none;"></div>').appendTo($(document.body)).hide();
			
			return function(paramAry){
				if( !paramAry || !paramAry.length)
				return;
				$('#mzConsoleId').show().empty().html(paramAry.join("----"));
			};
							
     })();
})(window);

