﻿CommonPage.prototype = {
	_keyWord : Web.request('keyword'),
	_searchType : "",
	_labelTagId : "",
	_notFound : "",
	_loadData : function(){},
	_loadUserData : function(){
		var that = this;
		var fillUrl = "";
		var lastItem = $(".head_searchitem a:last").attr("id");
		$("#loaderTip").show();
		that._isloading = true;
		var aURL = 'search/user?keyWord='+that._keyWord+'&start='+that._picPage*that._imgLimitNum+'&limit='+that._imgLimitNum;
		if(lastItem){
			fillUrl = baseURL +aURL+'&pageForwar=desc&posId='+lastItem;
		}else{
			fillUrl = baseURL +aURL;
		}
		Web.fill(fillUrl,{'after':function(data){
			var _array = data.list;
			var conta = ['<div class="content_searchuser" id="contSearchUser">',
						 '<ul class="user_searchuser">',
						 '',
						 '<li class="cr"> </li></ul>',
						 '</div>'];
			var contb = "";
			if(_array.length != 0){
				for(i=0;i<_array.length;i++){
					_array[i].headIcon == null?defaultHeadIcon:_array[i].headIcon;
					var items = '<li class="item_searchuser"><div class="head_searchitem touserpage_infophoto"><a attribute='+_array[i].userId+' href="javascript:void(0);" onclick="return false;"><img src='+_array[i].headIcon+' /></a></div><h5 class="touserpage_infophoto"><a attribute='+_array[i].userId+' href="javascript:void(0);" onclick="return false;">'+_array[i].aliasName+'</a></h5><p>'+_array[i].imgCount +'张照片</p></li>';
					contb += items;
				}
				var endCont = conta.join("");
				if($("#contSearchUser").size() == 0){
					$(".squarecont_mshow").append(endCont);
				}
				$(".user_searchuser").append(contb);
				errorHeadFun($(".head_searchitem img"));
				that._picPage = that._picPage+1;
				that._isloading = false;
				$("#loaderTip").hide();
			}else{
				if($("#contSearchUser").size() == 0){
					$("#loaderTip").hide();
					$(".squarecont_mshow").append(that._notFound);
					return false;
				}
				$("#loaderTip").html("没有更多内容了");
			}
		}})
	},
	_loadLabelData : function(){
		var that = this;
		$.ajax({
			type:"POST",
			url:baseURL + "search/tag",
			dataType:"json",
			data:{ 
				keyWord:decodeURIComponent(this._keyWord),
				start:0,
				limit:10
				},
			complete:function(msg){
				var obj=eval("("+msg.responseText+")");
				if(obj.returnCode == "0"){
					var _array = obj.returnValue.list;
					var conta = ['<div class="content_searchlabel" id="contSearchLabel">',
								 '<ul class="label_searchlabel">',
								 '',
								 '</ul>',
								 '<ul class="photo_searchlabel">',
								 '',
								 '<li class="cr"> </li>',
								 '</ul>',
								 '</div>']; 
					if(_array.length != 0){
						for(i=0;i<_array.length;i++){
							_array[i].headIcon == null?defaultHeadIcon:_array[i].headIcon;
							var items = '<li id="'+_array[i].tagId+'">'+_array[i].tagName+'</li>';
							conta[2] += items;
						}
						that._labelTagId = _array[0].tagId;
						var endCont = conta.join("");
						$(".squarecont_mshow").append(endCont);
						$(".label_searchlabel li").click(function(){
							$(this).addClass("curlabelitem_searchlabel").siblings().removeClass("curlabelitem_searchlabel");
							$(".photo_searchlabel").html("<li class='cr'>&nbsp;</li>");
							that._labelTagId = $(this).attr("id");
							that._switchLabelData();
						})
						$(".label_searchlabel li:first").click();
					}else{
						if($("#contSearchLabel").size() == 0){
							$("#loaderTip").hide();
							$(".squarecont_mshow").append(that._notFound);
							return false;
						}
					}
				}else{
					jAlert(obj.returnMessage,'提示',function(p){});
				}
			}
		})
	},
	_loadPhotoData : function(){
		var that = this;
		var lastItem = $(".cont_photo a>img:last").attr("id");
	  	var fillUrl = "";
	  	$("#loaderTip").show();
	  	that._isloading = true;
		var fillUrl = baseURL + "search/photo?keyWord=" + this._keyWord + "&start="+that._picPage*that._imgLimitNum+"&limit="+that._imgLimitNum;
		Web.fill(fillUrl,{'after':function(data){
			var _array = data.list;
			var contb = ['<div class="content_searchphoto" id="contSearchPhoto">',
						 '<ul>',
						 '',
						 '<li class="cr"> </li></ul>',
						 '</div>'];
			var endCont = contb.join("");
			if(_array.length != 0){
				if($("#contSearchPhoto").size() == 0){
					$(".squarecont_mshow").append(endCont);
				}
				that._photoFun("#contSearchPhoto ul",".item_photo img",350,960,20,_array);
				that._picPage = that._picPage+1;
				that._isloading = false;
				$("#loaderTip").hide();
			}else{
				if($("#contSearchPhoto").size() == 0){
					$("#loaderTip").hide();
					$(".squarecont_mshow").append(that._notFound);
					return false;
				}
				$("#loaderTip").html("没有更多内容了");
			}
		}})
	},
	_switchLabelData : function(){//that._switchLabelData(".label_searchlabel li","curlabelitem_searchlabel");
		var that = this;
		var fillUrl = "";
		var lastItem = $(".cont_photo a>img:last").attr("id");
		$("#loaderTip").show();
		that._isloading = true;
		var aURL = 'photo/showtag?tagId='+that._labelTagId+'&start='+that._picPage*that._imgLimitNum+'&limit='+that._imgLimitNum;
		if(lastItem){
			fillUrl = baseURL +aURL+'&pageForwar=desc&posId='+lastItem;
		}else{
			fillUrl = baseURL +aURL;
		}
		Web.fill(fillUrl,{'after':function(data){
			if(data != "" && data != null){
				$(".squarecont_mshow ul").css("margin-left","-5px");
				that._photoFun(".photo_searchlabel",".item_photo img",350,960,20,data);
				that._picPage = that._picPage+1;
				that._isloading = false;
				$("#loaderTip").hide();
				errorHeadFun($(".userhead_infophoto img"));
			}else{
				$("#loaderTip").html("没有更多内容了");
			}
		}})
	},
	init : function(page) {
		var that = this;
		$("#username_bread").text(decodeURIComponent(Web.request('keyword')));
		$(".squarecont_mshow").html("");
		//$("#notFoundSearch").remove();
		this._searchType = Web.request('type');
		this._page = page;
		this._showType = page;
		this._notFound = '<div id="notFoundSearch" class="notfound_search"><p>抱歉，没有找到“'+decodeURIComponent(this._keyWord)+'”的相关结果。</p><p>建议：<br>请尽量输入常用词<br>请尽量使用简洁的关键词</p></div>';
		switch(this._searchType){
			case "0"://搜索标签
				that._loadLabelData();//加载标签
				that._loadData = that._switchLabelData;//加载标签下照片
				$("#searchType").removeClass().addClass("searchtype_search label_cursearchtype");//更改当前默认搜索类型
				$("#searchType").attr("attribute","0");
			break;
			case "1"://搜索用户
				that._loadData = that._loadUserData;
				$("#searchType").removeClass().addClass("searchtype_search aliasname_cursearchtype");
				$("#searchType").attr("attribute","1");
			break;
			case "2"://搜索照片
				that._loadData = that._loadPhotoData;
				$("#searchType").removeClass().addClass("searchtype_search photo_cursearchtype");
				$("#searchType").attr("attribute","2");
		}
		this._scrollData();
		//喜欢操作
		likeFun();
	}
}