if (true) {

	;
	var EC = (function($) {
		// 105.962044, 37.698271
		var barContainer = null, isGoogle = true, level = 5, barOp = null, infoContainer = null, titleContainer = null, tipContainer = null, bp = {
			'lat' : 37.698271,
			'lng' : 105.962044
		}, point = {
			'lat' : 37.698271,
			'lng' : 105.962044
		};

		(function() {
			if (!barContainer) {
				barContainer = $('#tpl_left_top').remove().html();
			}
			if (!barOp) {
				barOp = $('#tpl_right_top').remove().html();
			}
			if (!infoContainer) {
				infoContainer = $('#tpl_info_container').remove().html();
			}
			if (!tipContainer) {
				tipContainer = $('#tpl_top_middle').remove().html();
			}
		})();

		return {
			'zoomBarHtml' : barContainer,
			'opBarHtml' : barOp,
			'isGoogle' : isGoogle,
			'center' : point,
			'bp' : bp,
			'level' : level,
			'infoHtml' : infoContainer,
			'titleHtml' : titleContainer,
			'tipHtml' : tipContainer
		};
	})(jQuery);

	// 操作
	;
	var Op = (function() {

		function init_map() {

		}

		function refresh(id) {

		}

		function debug(data) {

		}

		function map_google() {

		}

		function map_baidu() {

		}

		function mapSwitch(id) {

		}

		function setCenter(center) {

		}

		function setLevel() {
			EC.level = EC.isGoogle ? map.getZoom() + 1 : map.getZoom();
		}

		function zoomin(id) {
			map.setZoom(map.getZoom() + 1);
			setLevel();
		}

		function zoomout(id) {
			map.setZoom(map.getZoom() - 1);
			setLevel();
		}

		function addmark() {

		}

		function AddEventListener(event, callback) {

		}
		function movend() {

		}

		function bindEvent() {

		}

		function operation(id) {

		}

		return {
			'operation' : operation,
			'zoomout' : zoomout,
			'zoomin' : zoomin,
			'mapSwitch' : mapSwitch,
			'refresh' : refresh,
			'setCenter' : setCenter,
			'bindEvent' : bindEvent,
			'addmark' : addmark,
			'map_google' : map_google,
			'map_baidu' : map_baidu,
			'init_map' : init_map
		};

	})();

	;
	var BDMap = (function() {

		// 定义一个控件类,即function
		function ZoomControl() {
			// 默认停靠位置和偏移量
			this.defaultAnchor = BMAP_ANCHOR_TOP_RIGHT;
			this.defaultOffset = new BMap.Size(10, 10);
		}

		// 通过JavaScript的prototype属性继承于BMap.Control
		ZoomControl.prototype = new BMap.Control();

		// 自定义控件必须实现自己的initialize方法,并且将控件的DOM元素返回
		// 在本方法中创建个div元素作为控件的容器,并将其添加到地图容器中
		ZoomControl.prototype.initialize = function(map) {
			var cc = EC.zoomBarHtml.replace(/{mapselect}/, 'mapselect');
			map.getContainer().appendChild($(cc)[0]);

			$('#map_baidu,#map_google').click(function() {
				EC.isGoogle = false;
				Op[$(this).attr('id')]($(this).attr('id'));
			});
			// 将DOM元素返回
			return $(EC.zoomBarHtml)[0];
		};

		function OpControl() {
			// 默认停靠位置和偏移量
			this.defaultAnchor = BMAP_ANCHOR_TOP_RIGHT;
			this.defaultOffset = new BMap.Size(10, 10);
		}

		// 通过JavaScript的prototype属性继承于BMap.Control
		OpControl.prototype = new BMap.Control();

		// 自定义控件必须实现自己的initialize方法,并且将控件的DOM元素返回
		// 在本方法中创建个div元素作为控件的容器,并将其添加到地图容器中
		OpControl.prototype.initialize = function(map) {
			// var
			// bb=EC.opBarHtml.replace(/{relocal}/,flyMap.relocal?'relocal':'unrelocal');
			// map.getContainer().appendChild($(bb)[0]);

			$('#refresh,#zoomin,#zoomout').click(function() {
				EC.isGoogle = false;
				Op[$(this).attr('id')]($(this).attr('id'));
				// flyMap.localPhone();
			});
			// 将DOM元素返回
			return $(EC.opBarHtml)[0];
		};

		function TipControl() {
			// 默认停靠位置和偏移量
			this.defaultAnchor = BMAP_ANCHOR_TOP_RIGHT;
			this.defaultOffset = new BMap.Size(10, 10);
		}

		// 通过JavaScript的prototype属性继承于BMap.Control
		TipControl.prototype = new BMap.Control();

		// 自定义控件必须实现自己的initialize方法,并且将控件的DOM元素返回
		// 在本方法中创建个div元素作为控件的容器,并将其添加到地图容器中
		TipControl.prototype.initialize = function(map) {
			map.getContainer().appendChild($(EC.tipHtml)[0]);
			// 将DOM元素返回
			return $(EC.tipHtml)[0];
		};
		
		
		
		function addInfo(point,html){
			if(infoWindow)
			map.removeOverlay(infoWindow);
			var infoWindow = new BMap.Label(html);
			infoWindow.setPosition(point);
			map.addOverlay(infoWindow);
			infoWindow.addEventListener('mouseout',function(e){
				map.removeOverlay(infoWindow);
			});
		}
		
		function addMark(longitude, latitude, html) {
			var point = new BMap.Point(longitude, latitude);
			var lb = new BMap.Label(html);
			lb.setPosition(point);
			var infoW='';
			 map.setCenter(point);
			lb.addEventListener('click',
					function(e) {
				var id= $(e.currentTarget.content).attr('id');
				infoBase=$(e.currentTarget.content).html();
				infoW=$(e.currentTarget.content).attr('info');
				var opts = {
						  width : 360,
						  height: 360     
						};
				var infoWindow = new BMap.InfoWindow(decodeURIComponent(infoW),opts);  // 创建信息窗口对象
				 map.openInfoWindow(infoWindow,point);
				
			});
			
			lb.setStyle({
				border : 'none',
				background : 'none'
			});
			if (latitude && longitude) {
				map.addOverlay(lb);
			}

		}
		function decode(point,cb){
			var decode=new BMap.Geocoder();
			decode.getLocation(point,function(data){
				cb(data);
			});
		}
		function init() {
			var map = new BMap.Map("dituContent");
			window.map = map;
			map.enableScrollWheelZoom();

			map.centerAndZoom(new BMap.Point(EC.bp.lng, EC.bp.lat), 5);
			map.setMinZoom(5);

			var myZoomCtrl = new ZoomControl();
			// 添加到地图当中

			map.addControl(myZoomCtrl);

			var opCtrl = new OpControl();
			// 添加到地图当中
			map.addControl(opCtrl);

			// var tipCtrl = new TipControl();

			// map.addControl(tipCtrl);

			// Op.bindEvent();
		}
		return {
			'init' : init,
			'addMark' : addMark,
			'decode':decode
		};
	})();

	BDMap.init();
	//BDMap.addMark(97.57287677113344, 32.375563370617005, 'abcbb');
	//BDMap.addMark(97.57287677113344, 31.375563370617005, 'abc');
	
	Web.add_tpl('#tpl_img');
	Web.add_tpl('#tpl_big_img');
	
	var CityInfo={};
	var maxImgId=0;
	var firstEnter=true;
	
	
	function decodearea(data) {
		BDMap.decode(data.point, function(data) {
			Newton.publish('decodearea', data);
		});
	}
	
	Newton.subscribe('decodearea', function(data) {
		var cinf = data.addressComponents;
		CityInfo=cinf;
		$('#provices li[txt='+cinf.province+']').trigger('click');
		/*
		if(!(undefined===console)){
			console.log(cinf);
		}
		*/
	});
	


	
	function loadPic(pro,city,id){
		 city=encodeURIComponent(city);
		 pro=encodeURIComponent(pro);
		Web.fill('/c/browser/photo/showcity?province='+pro+'&city='+city+'&posId=0&start=0&limit=20',
				'', {
					'before' : function(data) {
						if(data&&data.length>0) {
							for ( var i = 0; i < data.length; i++) {
								var row=data[i];
								if(!row['aliasName']) {row['aliasName']='';}
								if(row['lng']&&row['lat']){
								var info=Web.format( Web.get_tpl('#tpl_big_img'),row);
								row['inforW']=encodeURIComponent(info);
								var html= Web.format( Web.get_tpl('#tpl_img'),row);
								BDMap.addMark(row['lng'],row['lat'],html); 
								}
							}
							map.setZoom(11);
							if(firstEnter){
								BDMap.decode(map.getCenter(),decodearea);	
								firstEnter=false;
							}
							
						}
					},'after':function(data){
						if(data){
							map.setCenter(city);
							if(map.getZoom()<11){
								map.setZoom(11);
							}
						}
					}
				});
	}
	
	loadPic('','',0);
	
	
	



	map.addEventListener('dblclick',decodearea );
	
	
	
	Newton.subscribe('cityChange',function(cinf){
		loadPic(cinf.province, cinf.city, 0);
	});

	var provicePanel = $('#provinceMap').mzPanel({'content':$('#provices'),'width':396});/**调用面板组件**/
	var cityPanel = $('#cityMap').mzPanel({'content':$('#citys'),'width':396});/**调用面板组件**/

	
	Web.fill('/c/browser/system/getcity?pid=1','#provices',{'after':function(data){
		$('#provices li').click(function(){
			$('#provinceMap').attr('value',$(this).text());
			$('#cityMap').attr('value','城市');
			var pid=$(this).attr('id');
			Web.fill('/c/browser/system/getcity?pid='+pid,'#citys',{'after':function(data){
				$('#citys li').click(function(){
					$('#cityMap').attr('value',$(this).text());
					cityPanel.close();
					CityInfo.province=$('#provinceMap').val();
					CityInfo.city=$('#cityMap').val();
					Newton.publish('cityChange', CityInfo);
				});
				if(CityInfo&&CityInfo.city); {
				$('#citys li[txt='+CityInfo.city+']').trigger('click');
				}
				return data;
			}});
			provicePanel.close();
		});
		$('#provices li[id=11]').trigger('click');
		return data;
	}});  

	

}