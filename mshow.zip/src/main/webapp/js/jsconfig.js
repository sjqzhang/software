var basePath="http://tuji.meizu.cn/c";
var baseURL="http://tuji.meizu.cn/c/browser/";
var baseHead="http://tuji.meizu.cn"