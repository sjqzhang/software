﻿var position = null;
Position = function() {

};

Position.prototype = {
	init : function() {}
	
	
};

$(document).ready(function() {
	position = new Position();
	position.init();
});