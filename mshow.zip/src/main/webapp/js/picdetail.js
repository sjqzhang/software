﻿var picDetail = null;
PicDetail = function() {

};
var defaultHeadIcon = "../images/avatar_default.png";
var _userId = "";
var _userSelf_cur = false;
var _imageId = "";
PicDetail.prototype = {
	_userSelf : false,
	init : function(imageid) {
		var that = this;
		_imageId = imageid;
		//照片及相关信息
		Web.fill(baseURL + 'photo/view?imgId='+imageid+'','',{'after':function(data){
			_userId = data.userId;
			that._userDataFun();
			$('#img_src').attr({'src':data.sourceImg,'attribute':data.imgId});
			$('#img_src').next("input:hidden").attr({"width":data.sourceWidth,"height":data.sourceHeight});
			$(".picdesc_picdetail").append(emote(encodeFun(data.desc),'/images/emotion/emoji_'));
			var viewCount = data.viewCount == null?"0":data.viewCount;
			var likeCount = data.likeCount == null?"0":data.likeCount;
			var commentCount = data.commentCount == null?"0":data.commentCount;
			var loginbtn = _loginUserId == ""?"login_mz":"";
			var conta = ['<li class="browse_picheat"><a title="浏览数" onclick="return false;" href="javascript:void(0);"><em></em><span>' + viewCount + '</span></a></li>',
						 '<li class="like_picheat"><a title="喜欢数" onclick="return false;" href="javascript:void(0);"><em></em><span>' + likeCount + '</span></a></li>',
						 '<li class="com_picheat"><a title="评论数" class="'+loginbtn+'" id="comNum" onclick="return false;" href="javascript:void(0);"><em></em><span>' + commentCount + '</span></a></li>'];
			var contA = conta.join("");
			$("#picheat_picdetail").append(contA);
			var pro = data['province'] == null?"":data['province'],
			city = data['city'] == null?"":data['city'],
			streat = data['streat'] == null?"":data['streat'],
			fileSize = data.fileSize == ""?"无":(data.fileSize/1024).toFixed(3)+" KB",
			fileName = data.filterName == ""?"无":data.filterName,
			filePos = pro == ""&&city == ""&&streat == ""?"无":pro+city+streat;
			var contb = ['<li class="picsize_picinfo">照片大小&nbsp;:&nbsp;<span>'+fileSize+'</span></li>',
						 '<li class="filter_picinfo">滤镜风格&nbsp;:&nbsp;<span>'+FilterFun(fileName)+'</span></li>',
						 '<li class="origsize_picinfo">原图尺寸&nbsp;:&nbsp;<span>'+data.sourceWidth+" x "+data.sourceHeight+'</span></li>',
						 '<li class="uptime_picinfo">上传时间&nbsp;:&nbsp;<span>'+fmtDate2(data.cdate)+'</span></li>',
						 '<li class="address_picinfo">照片位置&nbsp;:&nbsp;<span>'+filePos+'</span></li>'];
			var contB = contb.join("");
			$("#picinfo_picdetail").append(contB);
			var totalCount = data.commentCount;
			commentFun(0,0,10,totalCount);
			pageFun(0,10,totalCount);
			that._curBrowseUserFun();
			that._labelFun();
			imageSlide($("#boxwrap_picdetail ul"),309,10,200,$("#boxwrap_picdetail .leftbtn_otherpic"),$("#boxwrap_picdetail .rightbtn_otherpic"));
		}});
		that._likedUserFun();
		that._likeBtnFun();
		showDeleteFun(".comitem_conmcont",".deletebtn_comitem","comments/delete","commentId");
		
	},
	_userDataFun : function(){
		//用户信息
		Web.fill(baseURL + 'user/view?userId='+_userId,'',{'before':function(data){//#userinfo_picdetail
			
			if(data.user.headIcon == null){
				data.user.headIcon = defaultHeadIcon;
			}
			return data['user'];
		},'after':function(array){
			$("#username_bread").text(array.aliasName).attr("attribute",array.userId);
			$("#username_bread").parent().addClass("touserpage_infophoto");
			var cont = ['<div class="userhead_userinfo touserpage_infophoto" id="userhead_userinfo"><a href="javascript:void(0);" onclick="return false;" attribute="'+array.userId+'"><img src="'+array.headIcon+'" /></a></div>',
						'<div class="infocont_userinfo touserpage_infophoto">',
                		'<a href="javascript:void(0);" onclick="return false;" attribute="'+array.userId+'" title="'+array.aliasName+'"><h3 id="username_userinfo">'+array.aliasName+'</h3></a>',
                   		'<p>照片数：<span id="picnum_userinfo">'+array.imgCount+'</span>张</p>',
                		'</div>'];
			var endCont = cont.join("");
			$("#userinfo_picdetail").append(endCont);
			errorHeadFun($(".userhead_userinfo img"));
		}});
	},
	_likedUserFun : function(){
		//喜欢的用户
		Web.fill(baseURL + 'photo/likeusers?imgId='+_imageId+'&start=0&limit=8','',{'after':function(data){
			if(data.length==0){
				$('.otheruser_picdetail').hide();
				return false;
			}else{
				var cont = "";
				for ( var i = 0; i < data.length; i++) {
					if(data[i].headIcon == null){data[i].headIcon = defaultHeadIcon;}
					var itemCont = '<li class="touserpage_infophoto"><a href="javascript:void(0);" onclick="return false;" attribute="'+data[i].userId+'"><img src="'+data[i].headIcon+'" title="'+data[i].aliasName+'" /></a></li>';
					cont += itemCont;
				}
				$("#content_otheruser").append(cont);
				errorHeadFun($(".content_otheruser img"));	
			}
		}});
	},
	_curBrowseUserFun : function(){
		//当前浏览页面用户
		$.ajax({
			url:baseURL + 'user/self',
			data:"",
			async:false,
			complete:function(msg){
				var obj=eval("("+msg.responseText+")");
				var data = obj.returnValue;
				if(obj.returnCode == "0"){
					if(data.user.headIcon == null){
						data.user.headIcon = defaultHeadIcon;
					}
					var selfUserId = data.user.userId,
					picUserId = _userId;
					if(selfUserId == picUserId){
						_userSelf_cur = true;
					}
					$("#user_icon").attr({"src":data.user.headIcon,"attribute":data.user.aliasName})
				}else{
					$(".combox_comment").hide();
				}
			}
		})
	},
	_labelFun : function(){
		//标签
		Web.fill(baseURL + 'photo/tags?imgId='+_imageId+'&start=0&limit=6','',{'after':function(array){
			var that = this;
			if(_userSelf_cur == false){//不是当前浏览用户的照片
				if(array.length == 0){
					$(".hottag_picdetail").hide();	
				}
			}else{
				if(array.length < 6){
					$(".btnbar_label").show();
				}
			}
			for ( var i = 0; i < array.length; i++) {
				if(array[i].tagName){
					defaultLabel(".hottag_picdetail ul",".item_label",4,15,array[i].tagName,array[i].tagId,300);
				}else{
					return false;	
				}
			}
		}});
	},
	_likeBtnFun : function(){
		//喜欢按钮
		Web.fill(baseURL + 'photo/liked?imgId='+_imageId,'',{'after':function(data){
			if(data != 0){
				$(".like_picheat").addClass("liked_picheat");
			}													  
		}})
	}
};
//评论
function commentFun(curPageNum,pageNum,limit,totalCount){
	var fillUrl = "";
	var imageid = _imageId;
	if(curPageNum == 0){
		fillUrl = baseURL + 'comments/list?imgId='+imageid+'&start=0&limit='+limit;
	}else if(pageNum>curPageNum){//如果所选择的页数大于当前的页数
		if(pageNum-curPageNum == 1){//如果是相邻页数
			var lastId = $(".comitem_conmcont:last").attr("id");
			fillUrl = baseURL + 'comments/list?imgId='+imageid+'&start=0&limit='+limit+'&pageForward=desc&posId='+lastId;
		}else{
			fillUrl = baseURL + 'comments/list?imgId='+imageid+'&start='+(pageNum-1)*limit+'&limit='+limit;
		}
	}else if(pageNum<curPageNum){//如果所选择的页数小于当前的页数
		if(curPageNum-pageNum == 1){//如果是相邻页数
			var firstId = $(".comitem_conmcont:first").attr("id");
			fillUrl = baseURL + 'comments/list?imgId='+imageid+'&start=0&limit='+limit+'&pageForward=asc&posId='+firstId;
		}else{
			fillUrl = baseURL + 'comments/list?imgId='+imageid+'&start='+(pageNum-1)*limit+'&limit='+limit;	
		}
	}
	Web.fill(fillUrl,'',{'after':function(data){
		var content = "";
		for ( var i = 0; i < data.length; i++) {
			data[i].cdate = fmtDate(data[i].cdate)
			if(data[i].headIcon == null){
				data[i].headIcon = defaultHeadIcon;
			}
			var commonCont = emote(encodeFun(data[i]['remark']),'/images/emotion/emoji_'); 
			var replyMark = data[i].replyAliasName == null?"":"@"+data[i].replyAliasName;
			var replyBtn = _loginUserId == ""?"":"回复";
			var deleteBtn = _loginUserId == data[i].userId?"删除":"";
			var cont = ['<li class="comitem_conmcont" id="'+data[i].commentId+'">',
						'<table cellpadding="0" cellspacing="0">',
						'<tr>',
						'<td class="userhead_comitem touserpage_infophoto">',
						'<a href="javascript:void(0);" onclick="return false;" attribute="'+data[i].userId+'"><img src="'+data[i].headIcon+'" /></a>',
						'</td>',
						'<td class="cont_comitem">',
						'<div class="conthead_comitem">',
						'<span class="username_comitem touserpage_infophoto">',
						'<a href="javascript:void(0);" onclick="return false;" attribute="'+data[i].userId+'">'+data[i].aliasName+'</a>',
						'<em class="replymark_comitem">'+replyMark+'</em>',
						'</span>',
						'<span class="timecont_comitem">'+data[i].cdate+'</span>',
						'</div>',
						'<div class="content_comitem">',
						'<table cellpadding="0" cellspacing="0">',
						'<tr>',
						'<td class="comcont_comitem"><p>'+commonCont+'</p></td>',
						'<td class="btnbar_comitem"><span class="deletebtn_comitem">'+deleteBtn+'</span><span class="replybtn_comitem">'+replyBtn+'</span></td>',
						'</tr>',
						'</table>',
						'</div>',
						'</td>',
						'</tr>',
						'</table>',
						'<div class="cr">&nbsp;</div>',
						'</li>']
			var endCont = cont.join("");
			content += endCont;
		}
		$("#comcont_comment").html(content);
		errorHeadFun($(".comment_picdetail img"));
		
	}});
}
//分页
function pageFun(start,limit,totalCount){
	$.extend(window['G'],{'pagenumber':1,'pageSize':limit,'totalCount':totalCount});
	window['pager'] = $('#pager').pager({
		'pagenumber' : G.pagenumber,
		'pageSize'   : G.pageSize,
		'totalCount' : G.totalCount,
		'toPage'     : 'http://flyme.meizu.com/ui/elements.jsp?pagenumber='
		,'callBack': function(p){
			var curPageNum = $(".pageDiv .selected").text();
			window['pager'].reload({'pagenumber':p,'pageSize':limit,'totalCount':totalCount});
			commentFun(curPageNum,p,limit,totalCount);
		}
	});
} 
$(document).ready(function() {
	picDetail = new PicDetail();
	picDetail.init(Web.request('imgId'));
	showLargePic();
	popEmoji = new popEmojiBox();
	popEmoji.init();
	G.radio  = jQuery('input[name=radioPlugIn2]').mzRadio({//使用方法2
		click : function(e){//radio选中后的点击事件    （可选） ;获取值有下面两种方法
			if(G.radio.val() == "6"){
				$("#otherReport").show();
			}else{
				$("#otherReport").hide();
			}
		},
		chkCls  : "radio_chk",    //单选按钮父级元素的选中后的class名称 （默认为：radio_chk）      （可选）
		unChkCls: "radio_unchk"//单选按钮父级元素的未选中的class名称 （默认为：radio_unchk）         （可选）
	});
	replyFun(".replybtn_comitem",".comitem_conmcont","comboxwrap_comment","_com");
	textAreaScaler(".comboxwrap_comment",".comarea_combox",140)
});
//图片滚动
function imageSlide(imgCont,slideL,blank,speed,lBtn,rBtn,picData){
	var index = 0;
	var imageDiv = imgCont;
	var slideLength = slideL;
	var isData = true;
	getData();
	lBtn.click(function(){
		var curPos = imageDiv.position();
		if(curPos.left == 0){
		}else if(Math.abs(curPos.left) < slideLength){
			imageDiv.animate({left:0 + "px"},speed);
		}else{
			imageDiv.animate({left:curPos.left + slideLength + "px"},speed);
		}		 
	});
	rBtn.click(function(){
		if(isData == true){	getData();}
		var curPos = imageDiv.position();
		var imgNum = imageDiv.find("li").size();
		var totalLength = (imageDiv.find("li").width() + blank)*imgNum;
		imageDiv.css("width",totalLength);
		if(totalLength-Math.abs(curPos.left)<slideLength*2){//当图片内容不够一组时，滚动距离为剩余距离
			imageDiv.animate({left:"-" + (totalLength-slideLength) + "px"},speed);	
		}else{//当图片内容够一组时，滚动距离为一组的距离
			imageDiv.animate({left:curPos.left - slideLength + "px"},speed);		
		}
		index++;
		
	});
	function getData(){
		var lastItem = $("#otherpic_picdetail img:last").attr("id");
		var fillUrl = "";
		if(lastItem){
			fillUrl = baseURL + 'photo/showpost?userId='+_userId+'&start=0&limit=3'+ '&pageForward=desc&posId='+lastItem;
		}else{
			fillUrl = baseURL + 'photo/showpost?userId='+_userId+'&start=0&limit=6';
		}
		$.ajax({
			url:fillUrl,
			data:"",
			complete:function(msg){
				var obj=eval("("+msg.responseText+")");
				var data=obj.returnValue;
				if(data != ""){
					for(var i=0;i<data.length;i++){
						var src = data[i];
						imageDiv.append("<li><a href='"+baseHead+"/web/picdetail.html?imgId=" + src.imgId + "&userId=" + src.userId + "'><img id='"+src.imgId+"' src='" + src.minImg + "'/><input type='hidden' value='"+data[i].minWidth+"#"+data[i].minHeight+"'></a></li>")
					}
					shortImage($("#otherpic_picdetail li"));
					index++;
					isData = true;
					//Android
					if(data.length > 3){
						if(browser.versions.android || browser.versions.iPhone || browser.versions.iPad){//火狐gecko 移动mobile 谷歌webKit
							$(".btn_otherpic").show();
						}else{
							picSlide($(".boxwrap_otherpic"),$(".btn_otherpic"));	
						}
					}
				}else{
					if(!lastItem){
						imgCont.parents(".otherpic_picdetail").hide();
					}
					isData = false;
					return false;
				}
			}
		})
	}
}
//图片切割
function cutImage(wrap){
	$(wrap).each(function(){
		var imgIn = $(this).find("img");
		var wrapW = $(this).width();
		var imgW = imgIn.width();
		if(imgW>wrapW){
			imgIn.css("margin-left",-(imgW-wrapW)/2 + "px");
		}
	})
}
//初始化标签
function defaultLabel(box,laybelItem,maxNum,maxLength,data,dataId,wrapWidth){
	var lastGroup = $(box + " .group_label:last");
	var lenCont = data.length;
	var numAll = lastGroup.find(laybelItem).size();
	var lenAll = 0;
	lastGroup.find(laybelItem).each(function(){
		lenAll += $(this).text().length;											
	})
	if(numAll+1>maxNum||lenAll+lenCont>maxLength||numAll==0){
		var groupNum = $(box).find("li").size();
		if(groupNum == 5){
			return false;
		}else{
			var nGroup = "<li class='group_label'><div class='item_label'><a href='"+baseHead+"/web/label.html?tagId="+dataId+"&tagName="+encodeURIComponent(data)+"'><span>" + data + "</span></a></div></li>";
			$(box).append(nGroup);
		}
	}else{
		lastGroup.find(laybelItem).css("width","");
		var nItem = "<div class='item_label'><a href='"+baseHead+"/web/label.html?tagId="+dataId+"&tagName="+encodeURIComponent(data)+"'><span>" + data + "</span></a></div>";
		lastGroup.append(nItem);
	}
	adapLayout(".group_label",".item_label",10,0,wrapWidth);
}
//分页
/*jquery.pager.flyme.js*/
/*var G ={
	scroll:null,
	radio:null,
	checkbox:null,
	testBtn:null,
	moreContent:null,
	checkBoxPlugIn3:null,
	checkBoxPlugIn4:null,
	dialog:null
};*/
//自适应布局
function adapLayout(group,items,blank,type,wMax){
	$(group).css("margin-bottom",blank+"px").find(items).css("margin-right",blank+"px")
	$(group).find(items + ":last").css("margin-right","0px");
	$(group).each(function(){
		var child = $(this).find(items);
		var num = child.length;
		var wGroup = wMax;
		var childArr = [];
		child.each(function(){
			childArr.push($(this).find("span"));			
		})
		var wAll = 0;
		for(var i=0;i<num;i++){
			if(type == 1){
				wAll += Number(childArr[i].find("img").attr("width"));
			}else{
				wAll += Number(childArr[i].width());
			}
		}
		child.each(function(){
			var w = $(this).find("span").width();
			if(type == 1){
				w = $(this).find("img").attr("width");
			}
			var endW = (w/wAll)*(wGroup-blank*(num-1));
			endW = endW.toFixed(3);//限制精确到小数点后三位
			$(this).css("width",endW+"px")
		})
	})
}
//添加标签
function addLabel(addBtn,laybelInput,box,laybelItem,maxNum,maxLength,defaultCont,inputMaxL){
	$(laybelInput).live("keyup keydown mouseup mousedown",function(){
		var cont = $(this).attr("value");
		if(cont && cont!=defaultCont){//内容不为空且不为默认文字
			var num = cont.length;
			if(num == 0||num > inputMaxL){
				$(addBtn).addClass("disablebtn").removeClass("bluebtn");
			}else{
				$(addBtn).addClass("bluebtn").removeClass("disablebtn");
			}
		}else{
			$(addBtn).addClass("disablebtn").removeClass("bluebtn");
		}
	}).live("blur",function(){
		var cont = $(this).val();
		var num = cont.length;
		if(num == 0||num > inputMaxL){$(addBtn).addClass("disablebtn").removeClass("bluebtn");}
	})
	$(addBtn).click(function(){
		if($(this).hasClass("disablebtn")){return false}
		var _input = $(this).siblings("#labelInput");
		var cont = $(laybelInput).attr("value");
		var encodeCont = encodeFun2(cont);
		var _noRepeat = true;
		$(".item_label a span").each(function(){
			var _val = $(this).text();
			if(cont == _val){_noRepeat = false;}
		})
		if(_noRepeat == false){
			jAlert("标签重复",'提示',function(p){});
			_input.removeClass("current_searchbox").val(defaultCont);
			return false;
		}
		var imgid = $("#img_src").attr("attribute");
		$.ajax({
			type:"POST",
			url:baseURL + "photo/pintag",
			dataType:"json",
			data:{
				imgId:imgid,
				tagName:cont
				},
			complete:function(msg){
				var obj=eval("("+msg.responseText+")");
				if(obj.returnCode == "0"){
					_input.removeClass("current_searchbox").val(defaultCont);
					labelFun();
					adapLayout(".group_label",".item_label",10,0,300);
					var labelNum = $(box).find(laybelItem).size();
					if(labelNum == 6){$(".btnbar_label").hide()}
				}else{
					jAlert(obj.returnMessage,'提示',function(p){});
				}
			}
		})
		function labelFun(){
			var lastGroup = $(box + " .group_label:last");
			var lenCont = cont.length;
			var numAll = lastGroup.find(laybelItem).size();
			var lenAll = 0;
			lastGroup.find(laybelItem).each(function(){
				lenAll += $(this).text().length;											
			})
			if(numAll+1>maxNum||lenAll+lenCont>maxLength||numAll==0){
				var nGroup = "<li class='group_label'><div class='item_label'><a><span>" + encodeCont + "</span></a></div></li>";
				$(box).append(nGroup);
			}else{
				lastGroup.find(laybelItem).css("width","");
				var nItem = "<div class='item_label'><a><span>" + encodeCont + "</span></a></div>";
				lastGroup.append(nItem);
			}
		}
	})
}

//输入框默认提示
function defaultPrompt(info,inputBox,classDef){
	inputBox.attr("value",info);
	inputBox.focus(function(){//输入框获得焦点时
		var valNew = $(this).attr("value");
		if(valNew == info){
			$(this).attr("value","").addClass(classDef);
		}			
	});
	inputBox.blur(function(){//输入框失去焦点时
		var valNew = $(this).attr("value");
		if(valNew == ""){
			$(this).attr("value",info).removeClass(classDef);	
		}
	})
}
//发表评论
function postComment(btn,textBox,comList){
	btn.click(function(){
		if($(this).hasClass("disablebtn")){return false}
		var imgId = $("#img_src").attr("attribute"),
		text = textBox.val();
		encodeText = encodeFun(text);
		if(text == ""){return false};
		var myDate = new Date(),
		postH = myDate.getHours(),
		postM = myDate.getMinutes();
		$.ajax({
			type:"POST",
			url:baseURL + "comments/create",
			dataType:"json",
			data:{
				imgId:imgId,
				comment:text
				},
			complete:function(msg){
				var obj=eval("("+msg.responseText+")");
				if(obj.returnCode == "0"){
					//向评论列表添加评论块
					var replyBtn = _loginUserId == ""?"":"回复";
					var name = $("#user_icon").attr("attribute"),
					img = $("#user_icon").attr("src"),
					listCont = ['<li class="comitem_conmcont">',
								'<table cellpadding="0" cellspacing="0">',
								'<tr>',
								'<td class="userhead_comitem touserpage_infophoto">',
								'<a href="javascript:void(0);" onclick="return false;" attribute="'+_loginUserId+'"><img src="'+img+'" /></a>',
								'</td>',
								'<td class="cont_comitem">',
								'<div class="conthead_comitem">',
								'<span class="username_comitem touserpage_infophoto">',
								'<a href="javascript:void(0);" onclick="return false;" attribute="'+_loginUserId+'">'+_loginUserName+'</a>',
								'<em class="replymark_comitem"></em>',
								'</span>',
								'<span class="timecont_comitem">' + postH + ":" + postM + '</span>',
								'</div>',
								'<div class="content_comitem">',
								'<table cellpadding="0" cellspacing="0">',
								'<tr>',
								'<td class="comcont_comitem"><p>'+encodeText+'</p></td>',
								'<td class="btnbar_comitem"><span class="deletebtn_comitem"></span><span class="replybtn_comitem">'+replyBtn+'</span></td>',
								'</tr>',
								'</table>',
								'</div>',
								'</td>',
								'</tr>',
								'</table>',
								'<div class="cr">&nbsp;</div>',
								'</li>']
					endCont = listCont.join("");
					comList.prepend(emote(endCont,'/images/emotion/emoji_'));
					textBox.val("").keyup();
					textBox.parent().find(".curnum_scaler").text(0);
					//更改该照片的总评论数
					var comNum = $("#comNum span").text();
					$("#comNum span").text(parseInt(comNum)+1);
				}else{
					jAlert(obj.returnMessage,'提示',function(p){});
				}
			}
		})
		
	})
}
//模拟select选框
function simuSelect(btn,box,boxItem){
	$(btn).hover(function(){
		$(this).addClass("hover_arrow");							
	},function(){
		$(this).removeClass("hover_arrow");
	});
	$(btn).click(function(){
		var userId = _userId;
		var curUserId = $("#mzCustName").attr("attribute");
		var w = $(btn).width();
		$(this).find(box).css({
			display:"block",
			width:w + 10 + "px"
		}).attr("tabindex",1).focus();
		if(userId != curUserId){
			$(".deletebtn_selectbox").addClass("disablebtn_selectbox");
		}else{
			$(".reportbtn_selectbox").addClass("disablebtn_selectbox");
		}
		$(".selectbox_simu li:visible:last").css({border:"none"});
		$(box).blur(function(){$(this).hide();});
	});
	//举报
	$(".reportbtn_selectbox span").click(function(){
		if(!$(this).parent().hasClass("disablebtn_selectbox")){
			var ifLogin = $("#mzCustName:visible").size();
			var userId = _userId
			var curUserId = $("#mzCustName").attr("attribute");
			if(ifLogin == "0"){
				var userUri = encodeURIComponent(window.location.href);
				window.location.href = baseHead+"/c/browser/oauth/toflymelogin?useruri="+userUri;
				return false;
			}else{
				jConfirm('确定要举报此照片？','举报',function(p){
					if(p == true){
						var imgId = $("#img_src").attr("attribute");
						$.ajax({
							type:"POST",
							url:baseURL + "system/complain",
							dataType:"json",
							data:{imgId:imgId},
							complete:function(msg){
								var obj=eval("("+msg.responseText+")");
								if(obj.returnCode == 0){
									jAlert('举报成功','提示',function(){});
								}else{
									jAlert(obj.returnMessage,'提示',function(p){});
								}
							}
						})
					}									
				});
			}
		}
	});
	//删除照片
	$(".deletebtn_selectbox span").click(function(){
		if(!$(this).parent().hasClass("disablebtn_selectbox")){
			var userId = _userId
			var curUserId = $("#mzCustName").attr("attribute");	
			jConfirm('将同时删除照片的所有评论及标签','删除照片',function(p){
				if(p == true){
					var imgId = $("#img_src").attr("attribute");
					$.ajax({
						type:"POST",
						url:baseURL + "photo/delete",
						dataType:"json",
						data:{imgId:imgId},
						complete:function(msg){
							var obj=eval("("+msg.responseText+")");
							if(obj.returnCode == 0){
								jAlert('删除成功','提示',function(p){
									window.location.href = baseHead+"/web/personal.html?userId="+_loginUserId+"&type=0";							
								});
							}else{
								jAlert(obj.returnMessage,'提示',function(p){});
							}
						}
					})
				}									
			});
		}									  
	})
}

function picSlide(box,btn){
	box.hover(function(){
		btn.show();
	},function(){
		btn.hide();
	})	
}
//查看大图
function showLargePic(){
	$("#img_src").click(function(){//tipPop2
		var picSrc = $(this).attr("src"),
		picW = $(this).next("input:hidden").attr("width"),
		picH = $(this).next("input:hidden").attr("height"),
		endW = picW>960?960:picW,
		endH = picH*endW/picW;
		G.dialog = $('#tipPop2').mzDialog({'width':endW,'height':endH,'closeBtn':false,'nohide':true});	
		G.dialog.open();
		$("#tipPop2").html("<img width='"+(endW-20)+"px' src='"+picSrc+"'/>")
	})
	$(".mzBlockLayer").live("click",function(){
		if(G.dialog){
			G.dialog.close();
		}								   
	})
	$(".showlarge").live("click",function(){
		if(G.dialog){
			G.dialog.close();
		}								  
	})
}
//滤镜类型
function FilterFun(str){
	var s = "";
	if(str.length == 0) return "";
	s = str.replace(/NoneFilter/g, "无效果");
	s = s.replace(/AutoColorLevelFilter/g, "自动调整");
	s = s.replace(/LomoFilter/g, "Lomo");
	s = s.replace(/ReminisenceFilter/g, "怀旧");
	s = s.replace(/BrightnessFilter/g, "晨色");
	s = s.replace(/GreenHouseFilter/g, "温室");
	s = s.replace(/BlackWhiteFilter/g, "黑白");
	s = s.replace(/TimeFilter/g, "昔日");
	s = s.replace(/PROFilter/g, "思念");
	s = s.replace(/VignetteFilter/g, "晕影");
	s = s.replace(/MoonlightFilter/g, "月色");
	s = s.replace(/ToyFilter/g, "玩具");
	s = s.replace(/MultiplyFilter/g, "正片");
	s = s.replace(/SunnyFilter/g, "晴朗");
	s = s.replace(/FillLightFilter/g, "补光");
	s = s.replace(/PrintFilter/g, "印刷");
	s = s.replace(/ShiftColorFilter/g, "移色");
	return s;
}













