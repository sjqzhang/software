//添加公用部分
addCommonPart = function(){
	this._mzHead = ['<div class="m_top">',
		'<div id="logo"><a href="http://www.meizu.com/"></a></div>',
		'<ul class="c_menu">',
			'<li><a href="http://www.meizu.com/products/mxfun.html" class="r_prd "><span class="hideLeft"></span></a></li>',
			
			'<li><a href="http://store.meizu.com/" class="r_store"><span class="hideLeft"></span></a></li>',
			
			'<li><a href="http://www.meizu.com/storelist" class="r_buy"><span class="hideLeft"></span></a></li>',
			'<li><a href="http://www.meizu.com/services" class="r_tech"><span class="hideLeft"></span></a></li>',
			
			'<li><a href="http://flyme.meizu.com/" class="r_flyme"><span class="hideLeft"></span></a></li>',
			
			'<li><a href="http://bbs.meizu.com/" class="r_bbs_selected"></a></li>',
		'</ul>',
		'<div id="mzCust">',
		'<span id="mzLoginArea1" style="display:none;">',
					'<a id="mzLogout" href="javascript:void(0);" onclick="return false">退出</a>',
					'<a id="mzCustName" title="账户管理" href="http://flyme.meizu.com/account/actmanage.jsp" class="longdot"></a>',
				'</span>',
				'<div class="atag" id="mzLoginArea2"><a id="mzRegister" class="register_mz" href="javascript:void(0);" onclick="return false">注册</a></div>',
				'<div  id="mzLoginArea3" style="width:5px;">/</div>',
				'<div class="atag" id="mzLoginArea4"><a id="mzLogin" class="login_mz" href="javascript:void(0);" onclick="return false">登录</a></div><div class="custHead"></div>',
        '</div>',
	'</div>'],
	this._mzFoot = ['<div id="globalContainer">',
		'<a href="http://www.meizu.cn/" class="checked">China</a>',
		'<a href="http://www.meizu.com.hk/" class="ClobalItem">Hong Kong</a>',
		'<a href="http://en.meizu.com/" class="ClobalItem" style="border-width:0px;">Global</a>',
	'</div>',
	'<div id="footer1">',
		'<a href="http://www.meizu.com/about.html">关于魅族</a>',
		' <img class="footline" style="" src="http://res.meizu.com/resources/common/images/default/space.gif"> ',
		'<a href="http://www.meizu.com/about.html">工作机会</a>',
		' <img class="footline" style="" src="http://res.meizu.com/resources/common/images/default/space.gif"> ',
		'<a href="http://www.meizu.com/contact.html" target="_blank">联系我们</a>',
		' <img class="footline" style="" src="http://res.meizu.com/resources/common/images/default/space.gif"> ',
		'<a href="http://www.meizu.com/contact.html" target="_blank" id="globalName">Meizu(China)</a>',
	'</div>',
	'<div id="footer2">',
		'<a href="http://www.meizu.com/copyright.html">Copyright ©2012 Meizu Co., Ltd. All rights reserved. </a>',
		'<a href="javascript:void(0)" onClick=window.open("http://static.meizu.com/resources/www/images/icp.jpg")>经营许可证编号：粤B2-20050367</a>',
	'</div>'],
	this._tabNav = ['<ul class="tabnav_mshow">',
            '<li id="newpage"><a href="'+baseHead+'/web/new.html">最新</a></li>',
            '<li class="separator">&nbsp;</li>',
			'<li id="hotpage"><a href="'+baseHead+'/web/home.html">最热</a></li>',
            '<li class="separator">&nbsp;</li>',
            '<li id="posipage"><a href="'+baseHead+'/web/position.html">地理位置</a></li>',
        '</ul>'],
	this._breadCrumbs = ['<ul class="breadcrumbs">',
        	'<li><a href="'+baseHead+'/web/new.html">图记</a><span class="arrow_bread">&nbsp;</span></li>',
            '<li><a href="javascript:void(0);" onclick="return false;" id="username_bread">&nbsp;</a><span class="arrow_bread">&nbsp;</span></li>',
            '<li class="curpage_bread"><a href="javascript:void(0);" onclick="return false;">照片</a></li>',
        '</ul>'],
	this._breadCrumbs2 = ['<ul class="breadcrumbs">',
				'<li><a href="'+baseHead+'/web/new.html">图记</a><span class="arrow_bread">&nbsp;</span></li>',
				'<li class="curpage_bread"><a href="javascript:void(0);" onclick="return false;" id="username_bread">&nbsp;</a></li>',
			'</ul>'],
	this._labelBread = ['<ul class="breadcrumbs">',
        	'<li><a href="'+baseHead+'/web/new.html">图记</a><span class="arrow_bread">&nbsp;</span></li>',
            '<li class="curpage_bread"><a href="javascript:void(0);" onclick="return false;" id="tagname_bread" class="tagname_tagpage"></a></li>',
        '</ul>'],
	this._searchCont = ['<div class="search_msheader">',
					  '<span id="searchTypeWrap" class="typewrap_search" title="搜索类型" attribute="0"><em id="searchType" class="searchtype_search label_cursearchtype" attribute="0">&nbsp;</em><em class="separator14">&nbsp;</em>',
					  '<ul class="typebox_searchtype">',
					  '<li class="typeitem_searchtype curtype_searchtype" attribute="0"><span class="typeicon_searchtype label_searchtype">&nbsp;</span><span>标签</span></li>',
					  '<li class="typeitem_searchtype" attribute="1"><span class="typeicon_searchtype aliasname_searchtype">&nbsp;</span><span>昵称</span></li>',
					  '<li class="typeitem_searchtype bordernone" attribute="2"><span class="typeicon_searchtype photo_searchtype">&nbsp;</span><span>照片</span></li>',
					  '</ul>',
					  '</span>',
					  '<input id="searchBox" type="text" maxlength="2560" value="" onkeyup="bindEnter(event)"/>',
					  '<span id="okBtnSearch" class="okbtn_search"></span>',
					  '<span class="cr">&nbsp;</span>',
					  '</div>'],
	this._betaVersion = ['<div class="beta_mshow"><span>图记 Beta</span></div>'],
	this._personalHead = ['<div class="personalhead_mshow">',
    	'<div class="userinfo_personal" id="userinfo_personal">',
            /*'<div class="userhead_personal" id="userhead_personal"><img src="" /></div>',
           '<div class="infocont_personal">',
                '<h3 id="username_personal">&nbsp;</h3>',
                '<p>照片数：<span id="picnum_personal">&nbsp;</span>张</p>',
            '</div>',*/
        '</div>',
        '<div class="label_personal">',
            '<ul></ul>',
            '<div class="cr">&nbsp;</div>',
        '</div>',
        '<div class="cr"> </div>',
    '</div>'],
	this._personalTab = ['<div class="personaltab_mshow">',
    	'<ul class="tabnav_personal">',
        	'<li id="selfpost" class="current_tabpersonal"><a href="javascript:void(0);" onclick="return false;">图片</a></li>',
            '<li id="selflike"><a href="javascript:void(0);" onclick="return false;">喜欢</a></li>',
            '<li id="showmsg"><a href="javascript:void(0);" onclick="return false;">消息</a></li>',
			'<li class="cr"> </li>',
        '</ul>',
    '</div>'],
	this._othersTab = ['<div class="personaltab_mshow">',
    	'<ul class="tabnav_personal">',
        	'<li id="showpost" class="current_tabpersonal"><a href="javascript:void(0);" onclick="return false;">TA的照片</a></li>',
            '<li id="showlike"><a href="javascript:void(0);" onclick="return false;">TA喜欢的照片</a></li>',
        '</ul>',
    '</div>'],
	this._loaderTips = '<div class="loadertipbox"><div id="loaderTip" class="loadertip_mshow">载入更多内容</div></di',
	this._turnFun = function(){
		this._mzHead = this._mzHead.join("");
		this._mzFoot = this._mzFoot.join("");
		this._tabNav = this._tabNav.join("");
		this._breadCrumbs = this._breadCrumbs.join("");
		this._breadCrumbs2 = this._breadCrumbs2.join("");
		this._labelBread = this._labelBread.join("");
		this._searchCont = this._searchCont.join("");
		this._personalHead = this._personalHead.join("");
		this._personalTab = this._personalTab.join("");
		this._othersTab = this._othersTab.join("");
	},
	this.init = function(page){
		this._turnFun();
		$("#w_header").html(this._mzHead);
		$("#Footer").html(this._mzFoot);
		this._addSearchBox();
		this._addFun(page);
	},
	this._addSearchBox = function(){
		$("#mshowHead").append(this._betaVersion + this._searchCont);
	},
	this._addFun = function(page){
		var data = page;
		switch(data){
			case "hotpage":	
				$("#mshowHead").prepend(this._tabNav);
				$("#hotpage").addClass("current_tabnav");
				$("#mshowContainer").append(this._loaderTips);
				break;
			case "newpage":
				$("#mshowHead").prepend(this._tabNav);
				$("#newpage").addClass("current_tabnav");
				$("#mshowContainer").append(this._loaderTips);
				break;
			case "detailpage":
				$("#mshowHead").prepend(this._breadCrumbs);
				break;
			case "posipage":
				$("#mshowHead").prepend(this._tabNav);
				$("#posipage").addClass("current_tabnav");
				break;
			case "labelpage":
				$("#mshowHead").prepend(this._labelBread);
				$("#mshowContainer").append(this._loaderTips);
				break;
			case "personalpage":
				$("#mshowHead").prepend(this._breadCrumbs2);
				$("#mshowHead").after(this._personalHead + this._personalTab);
				$("#mshowContainer").append(this._loaderTips);
				break;
			case "otherspage":
				$("#mshowHead").prepend(this._breadCrumbs2);
				$("#mshowHead").after(this._personalHead + this._othersTab);
				$("#mshowContainer").append(this._loaderTips);
				break;
			case "errorpage":
				$("#mshowHead").prepend(this._breadCrumbs2);
				break;
			case "searchpage":
				$("#mshowHead").prepend(this._breadCrumbs2);
				$("#mshowContainer").append(this._loaderTips);
		}
	}
}