//页面初始化
$(function(){
	loginBtnFun();
	loginFunc();
	toUserPage();
	searchFun(256);
	backTop();
	msgNumFun();
	likeFun();
})
//公用方法
var searchBoxTip = "搜索标签、昵称、照片";
var _loginUserId = "";
var _loginUserName = "";
var defaultHeadIcon = "../images/avatar_default.png";
CommonPage = function() {
	this._page = "",//others,self
	this._isloading = false,
	this._picPage = 0,
	this._tagLimitNum = 10,
	this._imgLimitNum = 10,
	this._tagPageId = "",
	this._userId = "",
	this._showType = "",//showpost,showlike
	this._bc = 0,_dd = 0,_dc = 0,_ds = 0,_bsh = 0,_dsh = 0,_bs = 0,_bc = 0;
	this._scrollData = function(){
		var that = this;
		that._isloading = false;
		that._loadData();
		window.onscroll=function(){
			if(!that._isloading) {
				that._testScroll();
			}
		}
	};
	/*取窗口滚动条高度*/ 
	this._getScrollTop = function(){
		var that = this;
		var scrollTop=0;  
		if(that._dd&&that._ds){  
			scrollTop=that._ds;  
		}  
		else if(document.body){  
			scrollTop=that._bs;  
		}  
		return scrollTop; 	
	};
	/*取窗口可视范围的高度*/ 
	this._getClientHeight = function(){
		var that = this;
		var clientHeight=0;  
		if(that._bc&&that._dc){  
			var clientHeight = (that._bc<that._dc)?that._bc:that._dc;          
		}  
		else{  
			var clientHeight = (that._bc>that._dc)?that._bc:that._dc;      
		}  
		return clientHeight; 
	};
	/*取文档内容实际高度*/
	this._getScrollHeight = function(){
		var that = this;
		return Math.max(that._bsh,that._dsh); 	
	};
	this._testScroll = function(){
		var that = this;
		that._bc = document.body.clientHeight;
		that._dd = document.documentElement;
		that._dc = document.documentElement.clientHeight;
		that._ds = document.documentElement.scrollTop;
		that._bsh = document.body.scrollHeight;
		that._dsh = document.documentElement.scrollHeight;
		that._bs = document.body.scrollTop;
		that._bc = document.body.clientHeight;
		that._testFun();
	};
	this._testFun = function(){
		var that = this;
		var sTop = that._getScrollTop();
		var sHeiht = that._getScrollHeight();
		var cHeight= that._getClientHeight();
		if ((sTop+cHeight)/sHeiht>=0.95){ 
			if(that._tagPageId != ""){
				that._tagLoadData();
			}else{
				that._loadData();//到达底部
			}
		} 
	};
	this._photoFun = function(box,photo,photoH,wAll,blank,data){
		var that = this;
		var cont = "";
		var index = 1;
		var wi = 0;
		var items = "";
		var groupList = false;
		var imgData = data;
		for(i in imgData){
			if(imgData[i].headIcon == null){imgData[i].headIcon = defaultHeadIcon}
			var likeStatus = imgData[i].likeStatus == 1?"like_infophoto liked_infophoto":"like_infophoto";
			var midH = imgData[i].middleHeight;
			var midW = imgData[i].middleWidth;
			var hwprop = midH/midW;
			var _endH,_endW;
			if(hwprop>4/3){
				_endH = photoH;
				_endW = 3*photoH/4;
			}else if(hwprop<3/4){
				_endH = photoH;
				_endW = 4*photoH/3;	
			}else{
				_endH = photoH;
				_endW = midW*photoH/midH;
			}
			var wrapProp = _endH/_endW;
			if(hwprop>wrapProp){
				_imgW = _endW;
				_imgH = _endW*hwprop;
			}else{
				_imgH = _endH;
				_imgW = _endH/hwprop;
			}
			var lastGroup = $(".group_photo:last");
			var lastGroupItem = lastGroup.find(".cont_photo");
			index = lastGroupItem.length;
			index = index==0?0:(index-1);
			var wImgAll = wAll-index*blank;
			imgData[i].desc=emote(encodeFun(imgData[i].desc),'/images/emotion/emoji_');
			var conta = ['<div class="item_photo">',
						 '<div class="cont_photo" style="height:'+_endH+'px;width:'+_endW+'px">',
						 '<a target="_blank" href="'+baseHead+'/web/picdetail.html?imgId=' + imgData[i].imgId + '"><img id=' + imgData[i].imgId + ' src="' + imgData[i].middleImg + '" attribute="'+imgData[i].likeId+'" style="height:'+_imgH+'px;width:'+_imgW+'px" /></a>',
						 '<a target="_blank" class="desc_photo" style="width:'+_endW+'px" href="'+baseHead+'/web/picdetail.html?imgId=' + imgData[i].imgId + '"><p>' + imgData[i].desc + '</p></a>',
						 '</div>',
						 '<div class="info_photo" style="width:'+_endW+'px">',
						 '<div class="userhead_infophoto touserpage_infophoto"><a attribute='+imgData[i].userId+' href="javascript:void(0);"  onclick="return false;"><img src="' + imgData[i].headIcon + '"/></a></div>',
						 '<div class="username_infophoto touserpage_infophoto"><a attribute='+imgData[i].userId+' href="javascript:void(0);"  onclick="return false;" title="' + imgData[i].aliasName + '">' + imgData[i].aliasName + '</a></div>',
						 '<div class="'+likeStatus+'"><a href="javascript:void(0);" onclick="return false;"><em></em><span>' + imgData[i].likeCount + '</span></a></div>',
						 '<div class="com_infophoto"><a href="javascript:void(0);" onclick="return false;">' + imgData[i].commentCount + '</a></div>',
						 '</div>',
						 '</div>'];
			if(imgData[i].desc == null||imgData[i].desc == ""){
				conta[3] = '';
			}
			if(that._showType == "showpost"||that._showType == "selfpost"){
				conta[6] = '';
				conta[7] = '';
				conta[8] = '<div class="com_infophoto" style="float:left;margin-left:15px;"><a href="javascript:void(0);" onclick="return false;">' + imgData[i].commentCount + '</a></div>';
				conta[9] = '<div class="'+likeStatus+'" style="float:left"><a href="javascript:void(0);" onclick="return false;"><em></em><span>' + imgData[i].likeCount + '</span></a></div>';
				conta[10] = '<div style="float:right;margin-right: 15px;margin-top: 20px;"><a style="display:inline-block;line-height:25px;height:25px;">'+fmtDate(imgData[i].cdate)+'</a></div></div>';
			}else if(that._showType == "searchpage"){
				conta[5] = conta[6] = conta[7] = conta[8] = conta[9] = conta[10] = '';
				//conta[0] = '<div class="item_photo" style="height:350px;">';
			}
			var contb = conta.join("");
			items = contb;
			var lastGroupW = 0;
			var lastG = [];
			lastGroupItem.each(function(){lastG.push($(this))})
			for(j=0;j<lastG.length;j++){
				lastGroupW+=Number(lastG[j].width());
			}
			if(lastGroupItem.length == 0||lastGroupW>wImgAll-5){
				groupList = true;
			}else{
				groupList = false;
			}
			if(groupList == true){
				cont = "<li class='group_photo'>" + items + "</li>";
				$(box).append(cont);
			}else{
				lastGroup.append(items);
			}
		}
		adapLayout2(".group_photo",".item_photo",20,15,1,960);
		//为兼容IE6，需准确设置图片显示区域的宽度
		/*$(".cont_photo").each(function(){
			var w = $(this).parent().width();
			$(this).css("width",w);							  
		})*/
		mouseHover(".cont_photo",".desc_photo");
		$(".com_infophoto").click(function(){
			var ifLogin = $("#mzCustName:visible").size();
			var imgId = $(this).parents(".item_photo").find(".cont_photo img").attr("id");
			var hrefUrl = baseHead + "/web/picdetail.html?imgId=" + imgId;
			if(ifLogin == "0"){//用户未登录
				var userUri = encodeURIComponent(window.location.href);
				window.location.href = baseHead+"/c/browser/oauth/toflymelogin?useruri="+userUri;
				return false;
			}else{
				window.location.href = hrefUrl;
			}							   
		})
	}
};
//输入框默认提示
function defaultPrompt(info,inputBox,classDef){
	inputBox.attr("value",info);
	inputBox.focus(function(){//输入框获得焦点时
		var valNew = $(this).attr("value");
		if(valNew == info){
			$(this).attr("value","").addClass(classDef);
		}			
	});
	inputBox.blur(function(){//输入框失去焦点时
		var valNew = $(this).attr("value");
		if(valNew == ""){
			$(this).attr("value",info).removeClass(classDef);	
		}
	})
}
/*标签页切换*/
/*function tabSwitch(tabItems,contItems,tabCur,contCur){
	tabItems.click(function(){
		var index = $(this).index();
		var cont = contItems.get(index);
		$(this).addClass(tabCur).siblings().removeClass(tabCur);
		$(cont).addClass(contCur).siblings().removeClass(contCur);
	})
}*/
//返回顶部
function backTop(){
	var backTopTxt = "";
	var backTopEle = $('<div class="backToTop"></div>');
	backTopEle.appendTo($("body")).text(backTopTxt).attr("title",backTopTxt)
	.click(function(){$("html, body").animate({ scrollTop: 0 }, 120);});
	function backTopFun(){
		var st = $(document).scrollTop();
		var winh = $(window).height();
		(st > 200)? backTopEle.show(): backTopEle.hide();
		//IE6下的定位
		if (!window.XMLHttpRequest){
            backTopEle.css("top", st + winh - 166);    
        }
	}
	$(window).bind("scroll", backTopFun);


}
//用户头像加载错误
function errorHeadFun(img){
	img.each(function(){
		var that = $(this);
		that.error(function(){
			that.attr("src",defaultHeadIcon);					   
		})				  
	})
}

//登录
function loginBtnFun(){
	var userUri = encodeURIComponent(window.location.href);
	$(".login_mz").live("click",function(){	
		window.location.href = baseHead+"/c/browser/oauth/toflymelogin?useruri="+userUri;
	})
	$(".register_mz").live("click",function(){
		window.location.href = "https://member.meizu.com/register.jsp";							
	})
	$("#mzLogout").live("click",function(){
		$.ajax({
			type:"POST",
			url:baseHead + "/c/android/oauth/logout",
			dataType:"json",
			data:{},
			complete:function(msg){
				window.location.reload();
			}
		})							  
	})
}
function loginFunc(){
	$.ajax({
		type:"POST",
		url:baseURL + 'user/self',
		data:"",
		async: false,
		complete:function(msg){
			var obj=eval("("+msg.responseText+")");
			var data = obj.returnValue;
			if(obj.returnCode == "0"){
				_loginUserId = data.user.userId;
				_loginUserName = data.user.aliasName;
				$("#mzLoginArea2").hide();
				$("#mzLoginArea3").hide();
				$("#mzLoginArea4").hide();
				$("#mzLoginArea1").show().find("#mzCustName").text(data.user.aliasName).attr("attribute",data.user.userId);;
				errorHeadFun($(".userhead_combox img"));
			}else{
				$("#mzLoginArea2").show();
				$("#mzLoginArea3").show();
				$("#mzLoginArea4").show();
				$("#mzLoginArea1").hide();
			}
		}
	})
}
//鼠标经过，显示/隐藏内容
function mouseHover(items,cont){
	$(items).hover(function(){
		$(this).find(cont).show();			  
	},function(){
		$(this).find(cont).hide();
	})
}
//鼠标经过，显示/隐藏删除按钮
function showDeleteFun(items,btn,url,contIdName){
	$(items).live('mouseover mouseout',function(event){
		if(_loginUserId == ""){return false}
		if(event.type == 'mouseover'){
			$(this).find(btn).show();
		}else{
			$(this).find(btn).hide();	
		}											
	})
	$(btn).live("click",function(){
		if(_loginUserId == ""){return false}
		var thisP = $(this).parents(items);
		var contId = thisP.attr("id");
		$.ajax({
			type:"POST",
			url:baseURL + url + '?' + contIdName + '=' + contId,
			dataType:"json",
			complete:function(msg){
				var obj=eval("("+msg.responseText+")");
				if(obj.returnCode == 0){
					jAlert('删除成功','提示',function(p){
						thisP.remove();
						var itemNum = $(items).size();
						if(itemNum == 0){
							$("#pager a.selected").prev().click();
						}
					});
					if($("#comNum")){//若为删除评论，则同时更改页面中的评论数
						var _num = $("#comNum span").text();
						var _curNum = Number(_num - 1);
						$("#comNum span").text(_curNum);
					}
					
				}else{
					jAlert(obj.returnMessage,'提示',function(p){});
				}
			}
		})
	})
}
//判断浏览器类型（pc/mobile）
var browser={    
	versions:function(){            
		var u = navigator.userAgent, app = navigator.appVersion;            
		return {                
			trident: u.indexOf('Trident') > -1, //IE内核                
			presto: u.indexOf('Presto') > -1, //opera内核                
			webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核                
			gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核                
			mobile: !!u.match(/AppleWebKit.*Mobile.*/)||!!u.match(/AppleWebKit/), //是否为移动终端                
			ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端                
			android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或者uc浏览器                
			iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1, //是否为iPhone或者QQHD浏览器                
			iPad: u.indexOf('iPad') > -1, //是否iPad                
			webApp: u.indexOf('Safari') == -1 //是否web应该程序，没有头部与底部            
		};
	}()
} 
//格式化评论日期
function fmtDate(cdate){
	var cd=new Date();
	var d=new Date(cdate*1000) ;
	var c=cd.getTime()/1000;
	if((c-cdate)<60){		
		return Math.floor((c-cdate))+"秒前";
	}else if((c-cdate)<(60*60)){
		return Math.floor((c-cdate)/60)+"分钟前";
	}else if((c-cdate)<(60*60*24)){
		return Math.floor((c-cdate)/(60*60))+"小时前";
	}else if((c-cdate)<(60*60*24*365)){
		return (d.getMonth()+1)+"月"+d.getDate()+"日";
	}else{
		return d.getFullYear()+"年"+(d.getMonth()+1)+"月"+d.getDate()+"日";
	}
}
function fmtDate2(cdate){
	var d=new Date(cdate*1000) ;
	return d.getFullYear()+"年 "+(d.getMonth()+1)+"月 "+d.getDate()+"日";
}
//去往个人/他人主页
function toUserPage(){
	$(".touserpage_infophoto a").live("click",function(){
		var userId = $(this).attr("attribute");
		if(userId == _loginUserId){
			window.location.href = baseHead+"/web/personal.html?userId="+_loginUserId+"&type=0";	
		}else{
			window.location.href = baseHead+"/web/others.html?userId="+userId+"&type=0";
		}
	})	
}
//自适应布局
function adapLayout2(group,items,blankX,blankY,type,wMax){
	$(group).find(items).css({"margin-bottom":blankY+"px","margin-right":blankX+"px"});
	$(group).find(items + ":last").css("margin-right","0px");
	$(group).each(function(){
		if(!$(this).hasClass("adapLayouted")){
			var thisItems = $(this).find(items);
			var num = thisItems.length;
			var _groupW = 0;
			var _group = [];
			thisItems.each(function(){_group.push($(this).find(".cont_photo").width())})
			for(j=0;j<_group.length;j++){
				_groupW+=Number(_group[j]);
			}
			var _wGroup = wMax-blankX*(num-1);
			var _prop =_wGroup/_groupW;
			if(_groupW>=_wGroup){
				thisItems.each(function(){
					var thisImg = $(this).find(".cont_photo a>img"),
					wrapW = $(this).find(".cont_photo").width(),
					wrapH = $(this).find(".cont_photo").height(),
					imgW = thisImg.width(),
					imgH = thisImg.height(),
					wrapProp = wrapW/wrapH,
					imgProp = imgW/imgH;
					$(this).find(".cont_photo").css({width:wrapW*_prop,height:wrapH*_prop});
					$(this).find(".desc_photo").css({width:wrapW*_prop,height:wrapH*_prop});
					$(this).find(".info_photo").css({width:wrapW*_prop});
					thisImg.attr("style","");
					if(imgProp>wrapProp){
						imgH = wrapH*_prop;
						imgW = wrapH*_prop*imgProp;
						thisImg.css("height",imgH);
					}else{
						imgH = wrapW*_prop/imgProp;
						imgW = wrapW*_prop;
						thisImg.css("width",imgW);
					}
					if(imgW>wrapW*_prop){thisImg.css("margin-left",-(imgW-wrapW*_prop)/2 + "px");}
					if(imgH>wrapH*_prop){thisImg.css("margin-top",-(imgH-wrapH*_prop)/2 + "px");}
				})
				$(this).addClass("adapLayouted");
			}
		}
	})
}


function adapLayout(group,items,blankX,blankY,type,wMax){
	//$(group).css("margin-bottom",blank+"px").find(items).css("margin-right",blank+"px")
	$(group).find(items).css({"margin-bottom":blankY+"px","margin-right":blankX+"px"});
	$(group).find(items + ":last").css("margin-right","0px");
	$(group).each(function(){
		var child = $(this).find(items);
		var num = child.length;
		var wGroup = wMax;
		var childArr = [];
		child.each(function(){
			childArr.push($(this).find("span"));	
		})
		var wAll = 0;
		for(var i=0;i<num;i++){
			if(type == 1){
				wAll += Number(childArr[i].find("img").attr("width"));
			}else{
				wAll += Number(childArr[i].width());
			}
		}
		child.each(function(){
			var w = $(this).find("span").width();
			if(type == 1){
				w = $(this).find("img").attr("width");
			}
			var wgroup = wGroup-blankX*(num-1);
			var endW = (w/wAll)*wgroup; 
			if(wAll>=wgroup||type==0){
				endW = endW.toFixed(3);//限制精确到小数点后三位
				$(this).css("width",endW+"px")
			}
		})
	})
}
//图片切割
function cutImage(wrap){
	$(wrap).each(function(){
		var imgIn = $(this).find("a>img"),
		wrapW = Number($(this).width()),
		wrapH = Number($(this).height()),
		imgW = Number(imgIn.width()),
		imgH = Number(imgIn.height());
		if(imgW>wrapW){imgIn.css("margin-left",-(imgW-wrapW)/2 + "px");}
		if(imgH>wrapH){imgIn.css("margin-top",-(imgH-wrapH)/2 + "px");}
	})
}
//初始化热门标签
function defaultLabel(box,laybelItem,maxNum,maxLength,data,dataId,wrapWidth){
	var lastGroup = $(box + " .group_label:last");
	var lenCont = data.length;
	var numAll = lastGroup.find(laybelItem).size();
	var lenAll = 0;
	$(box).parent().css("width",wrapWidth);
	lastGroup.find(laybelItem).each(function(){
		lenAll += $(this).text().length;											
	})
	if(numAll+1>maxNum||lenAll+lenCont>maxLength||numAll==0){
		var groupNum = $(box).find("li").size();
		if(groupNum == 5){
			return false;
		}else{
			var liWidth = Number(wrapWidth+10);
			var nGroup = "<li class='group_label' style='width:" + liWidth + "px'><div class='item_label'><a href='"+baseHead+"/web/label.html?tagId="+dataId+"&tagName="+encodeURIComponent(data)+"'><span>" + data + "</span></a></div></li>";
			$(box).append(nGroup);
		}
	}else{
		lastGroup.find(laybelItem).css("width","");
		var nItem = "<div class='item_label'><a href='"+baseHead+"/web/label.html?tagId="+dataId+"&tagName="+encodeURIComponent(data)+"'><span>" + data + "</span></a></div>";
		lastGroup.append(nItem);
	}
	adapLayout(".group_label",".item_label",10,10,0,wrapWidth);
}
/*jquery.pager.flyme.js*/
var G ={
	scroll:null,
	radio:null,
	checkbox:null,
	testBtn:null,
	moreContent:null,
	checkBoxPlugIn3:null,
	checkBoxPlugIn4:null,
	dialog:null
};
//喜欢
function likeFun(){
	$(".like_infophoto").live("click",function(){
		var that = $(this);
		var imgId = that.parents(".item_photo").find(".cont_photo a>img").attr("id");
		turnLikeStatus(that,"liked_infophoto",imgId);
	})
	$(".like_picheat").live("click",function(){
		var that = $(this);
		var imgId = $("#img_src").attr("attribute");
		turnLikeStatus(that,"liked_picheat",imgId);
	})
}
function turnLikeStatus(that,likedClass,imgId){
	var ifLogin = $("#mzCustName:visible").size();
	if(ifLogin == "0"){
		var userUri = encodeURIComponent(window.location.href);
		window.location.href = baseHead+"/c/browser/oauth/toflymelogin?useruri="+userUri;
		return false;
	}
	if(!that.hasClass(likedClass)){
		$.ajax({
			type:"POST",
			url:baseURL + "photo/increaselikes",
			dataType:"json",
			data:{ 
				imgId:imgId
				},
			complete:function(msg){
				var obj=eval("("+msg.responseText+")");
				if(obj.returnCode == "0"){
					var cont = that.find("a span").text();
					that.addClass(likedClass);
					that.find("a span").text(parseInt(cont)+1);
				}else{
					jAlert(obj.returnMessage,'提示',function(p){});
				}
			}
		})	
	}else{
		$.ajax({
			type:"POST",
			url:baseURL + "photo/deletelike",
			dataType:"json",
			data:{ 
				imgId:imgId
				},
			complete:function(msg){
				var obj=eval("("+msg.responseText+")");
				if(obj.returnCode == "0"){
					var cont = that.find("a span").text();
					that.removeClass(likedClass);
					that.find("a span").text(parseInt(cont)-1);
				}else{
					jAlert(obj.returnMessage,'提示',function(p){});
				}
			}
		})
	}
}
//搜索框
function searchFun(maxLength){
	$("#searchBox").live("keyup keydown mouseup mousedown blur",function(){
		var cont = $(this).val();
		var num = cont.length;	
		if(num > maxLength){
			$(this).val(cont.slice(0,maxLength+1));
		}
	})
	$("#okBtnSearch").live("click",function(){
		var defaultVal = searchBoxTip;
		var curVal = $("#searchBox").val().replace(/^\s+|\s+$/g,"");
		var searchType = $("#searchType").attr("attribute");
		if(curVal != defaultVal && curVal.length != 0){
			window.location.href = "http://tuji.meizu.cn/web/search.html?keyword="+encodeURIComponent(curVal)+"&type="+searchType;	
		}
	})
}
//搜索框绑定回车事件
function bindEnter(event){
	var button = document.getElementById("okBtnSearch");                
	if(event.keyCode == 13){                        
		button.click();                       
		event.returnValue = false;                    
	}  
}
//切换搜索条件
searchTypeFun();
function searchTypeFun(){
	$("#searchType").live("click",function(e){
		$(".typebox_searchtype").show();
		e.stopPropagation();
	});
	$(".typeitem_searchtype").live("click",function(){
		var type = $(this).attr("attribute");
		$(this).addClass("curtype_searchtype").siblings().removeClass("curtype_searchtype");
		switch(type){
			case "0":
				$("#searchType").removeClass().addClass("searchtype_search label_cursearchtype");
				$("#searchType").attr("attribute","0");
				break;
			case "1":
				$("#searchType").removeClass().addClass("searchtype_search aliasname_cursearchtype");
				$("#searchType").attr("attribute","1");
				break;
			case "2":
				$("#searchType").removeClass().addClass("searchtype_search photo_cursearchtype");
				$("#searchType").attr("attribute","2");
		}
		$(".typebox_searchtype").hide();
	});
	$("#searchTypeWrap").live("mouseleave",function(){
		var box = $(".typebox_searchtype:visible");
		$(document).click(function(){box.hide();})
	})
}
//缩略图切割
function shortImage(wrap){
	$(wrap).each(function(){
		var imgIn = $(this).find("img");
		var inputInVal = $(this).find("input:hidden").val().split("#");
		var wrapW = $(this).width();
		var wrapH = $(this).height();
		var imgW = inputInVal[0];
		var imgH = inputInVal[1];
		var propH = wrapH/imgH;
		var propW = wrapW/imgW;
		if(imgW/imgH>1){
			var margin = -(imgW*propH-wrapW)/2 + "px";
			imgIn.css({height:wrapH,margin:"0 0 0 "+ margin});
		}else{
			var margin = -(imgH*propW-wrapH)/2 + "px";
			imgIn.css({width:wrapW,margin:margin+" 0 0 0"});
		}
	})
}
//转译特殊字符
function encodeFun(str){
var s = "";
if(str == null || str.length == 0) return "";
s = str.replace(/&/g, "&amp;");
s = s.replace(/</g, "&lt;");
s = s.replace(/>/g, "&gt;");
s = s.replace(/^\s+|\s+$/g,"");//过滤前后空格
s = s.replace(/ /g, "&nbsp;");
s = s.replace(/\'/g, "&apos;");
s = s.replace(/\"/g, "&quot;");
s = s.replace(/\n/g, "<br />");
s = s.replace(/[\r\n]/g, "<br />");
return s;
}
function encodeFun2(str){
var s = "";
if(str == null || str.length == 0) return "";
s = str.replace(/&/g, "&amp;");
s = s.replace(/</g, "&lt;");
s = s.replace(/>/g, "&gt;");
s = s.replace(/^\s+|\s+$/g,"");//过滤前后空格
s = s.replace(/ /g, "");
s = s.replace(/　+/g, "");
s = s.replace(/\s+/g,''); 
s = s.replace(/\'/g, "&apos;");
s = s.replace(/\"/g, "&quot;");
s = s.replace(/\n/g, "");
s = s.replace(/[\r\n]/g, "");
return s;
}
//消息提示块
function msgNumFun(){
	showbox = function(){
		$.ajax({
			type:"POST",
			url:baseURL + "user/msgcount",
			dataType:"json",
			complete:function(msg){
				var obj=eval("("+msg.responseText+")");
				var cont = "<div id='msgTipsBox' class='msgtipsbox_mshow'><p><span id='msgNumCont'>"+obj.returnValue+"</span>条新消息，<a id='showMsgBtn' href='" + baseHead + "/web/personal.html?userId=" + _loginUserId + "&type=2'>查看</a></p><div id='closeMsgBtn' class='closebtn_msgtipsbox'>&nbsp;</div></div>";
				if(obj.returnCode == 0 && obj.returnValue != 0){
					$("#msgTipsBox").size() == 0?$("#mshowHead").append(cont):$("#msgNumCont").text(obj.returnValue);
					$("#closeMsgBtn").click(function(){
						$("#msgTipsBox").remove();	
						clearInterval(int);								
					})
				}else{
					clearInterval(int);
				}
			}
		})
	}
	showbox();
	int = setInterval("showbox()",30000);
}
//文本框计数器
function textAreaScaler(boxWrap,areaWrap,totalNum){
	$(areaWrap).each(function(){
		$(this).append("<div class='scalerbox_scaler'><span class='curnum_scaler'>0</span>/<span class='totalnum_scaler'>"+totalNum+"</span></div>");	
		var textArea = $(this).find("textarea");
		textArea.live("keyup keydown mouseup mousedown",function(){//keydown mousedown focusin focusout
			var cont = $(this).val();
			var num = cont.length;
			$(".curnum_scaler").text(num);
			if(num == 0||num > totalNum){
				$(this).parents(boxWrap).find(".bluebtn").addClass("disablebtn").removeClass("bluebtn");
			}else{
				$(this).parents(boxWrap).find(".disablebtn").addClass("bluebtn").removeClass("disablebtn");
			}
		}).live("blur",function(){
			var cont = $(this).val();
			var num = cont.length;
			if(num == 0||num > totalNum){$(this).parents(boxWrap).find(".bluebtn").addClass("disablebtn").removeClass("bluebtn");}
		})
	})
}
//回复
function replyFun(btn,contItem,boxClass,type){
	$(btn).live("click",function(){
		var replyBox = $(this).parents(contItem).find(".combox_reply");
		var replyBoxNum = replyBox.size();
		if(replyBoxNum == 0){
			var cont = ['<div class="combox_reply comboxwrap_comment '+boxClass+'">',
						'<ul>',
						'<li class="userhead_combox" ></li>',
						'<li class="comarea_combox"><textarea class="comarea_reply" maxLength="140"></textarea></li>',
						'</ul>',
						'<div class="btnbar_combox">',
						'<div class="btn_combox"><a class="disablebtn postbtn_combox postbtn_reply">评论</a></div>',
						'<div class="btn_combox smileywrap_combox"><span class="smileybtn_combox"><em>&nbsp;</em></span>',
						'<div class="emojibox_emoji">',
						'</div>',
						'</div>',
						'</div>',
						'<div class="cr">&nbsp;</div>',
						'</div>']	
			var endCont = cont.join("");
			$(this).parents(contItem).append(endCont);
			textAreaScaler(".comboxwrap_comment",".comarea_combox",140);
		}else{
			replyBox.remove();	
		}
	})
	$(".postbtn_reply").live("click",function(){
		if($(this).hasClass("disablebtn")){return false}
		var comItem = $(this).parents(contItem);
		var replyBox = $(this).parents(".combox_reply");
		if(type == "_com"){
			var imgId = $("#img_src").attr("attribute");
		}else if(type == "_msg"){
			var imgId = $(this).parents(contItem).find(".photo_msgitem img").attr("attribute");
		}
		var replyUserId = comItem.find(".touserpage_infophoto a").attr("attribute");
		var replyUserName = comItem.find(".touserpage_infophoto a").text();
		var text = replyBox.find(".comarea_reply").val();
		encodeText = encodeFun(text);
		if(text == ""){return false};
		$.ajax({
			type:"POST",
			url:baseURL + "comments/create",
			dataType:"json",
			data:{
				imgId:imgId,
				replyUserId:replyUserId,
				comment:text
				},
			complete:function(msg){
				var obj=eval("("+msg.responseText+")");
				if(obj.returnCode == "0"){
					//向评论列表添加评论块
					var listCont = '<div class="replycont_reply"><p><span class="replyname_reply">@'+replyUserName+'&nbsp;&nbsp;</span>'+encodeText+'</p></div>';
					//更改该照片的总评论数
					var comNum = $("#comNum span").text();
					$("#comNum span").text(parseInt(comNum)+1);
					comItem.append(emote(listCont,'/images/emotion/emoji_'));
					replyBox.remove();
				}else{
					jAlert(obj.returnMessage,'提示',function(p){});
				}
			}
		})
	})
} 
//emoji表情
var popEmojiBox = function(){};
popEmojiBox.prototype = {
	_emojiBox : "",
	_textBox : "",
	_textMaxL : 140,
	_smileyBtn : function(){
		var that = this;
		$(".smileybtn_combox").live("click",function(e){
			that._emojiBox = $(this).parent().find(".emojibox_emoji");
			that._textBox = $(this).parents(".comboxwrap_comment").find(".comarea_combox textarea");
			that._emotionBox();
			$(this).addClass("smileybtned_combox");
			var offset = $(this).offset();
			var t = offset.top;
			var l = offset.left;
			that._emojiBox.css({
				display:"block",
				top:t + 51,
				left:l - 384
			});
			e.stopPropagation();
		})
	},
	_hoverFun : function(){
		var that = this;
		$(".emojibox_emoji").live("click",function(e){e.stopPropagation();});
		$(".smileywrap_combox").live("mouseleave",function(){
			if(that._emojiBox == ""){return false;}
			$(document).click(function(){
				that._emojiBox.hide();
				$(this).find(".smileybtn_combox").removeClass("smileybtned_combox");
			})											 
		})
	},
	_emotionBox : function(){
		var that = this;
		var emojiSrc = "../images/emotion/";
		var emojiData = [{"category":[{"code":"0xe335","img":"emoji_1f60a.png"},{"code":"0xe330","img":"emoji_1f603.png"},
									  {"code":"0xe323","img":"emoji_1f61e.png"},{"code":"0xe320","img":"emoji_1f620.png"},
									  {"code":"0xe329","img":"emoji_1f61c.png"},{"code":"0xe327","img":"emoji_1f60d.png"},
									  {"code":"0xe341","img":"emoji_1f631.png"},{"code":"0xe344","img":"emoji_1f613.png"},
									  {"code":"0xe345","img":"emoji_1f625.png"},{"code":"0xe343","img":"emoji_1f60f.png"},
									  {"code":"0xe340","img":"emoji_1f614.png"},{"code":"0xe333","img":"emoji_1f601.png"},
									  {"code":"0xe347","img":"emoji_1f609.png"},{"code":"0xe33c","img":"emoji_1f623.png"},
									  {"code":"0xe33f","img":"emoji_1f616.png"},{"code":"0xe342","img":"emoji_1f62a.png"},
									  {"code":"0xe32a","img":"emoji_1f61d.png"},{"code":"0xe33e","img":"emoji_1f60c.png"},
									  {"code":"0xe33b","img":"emoji_1f628.png"},{"code":"0xe32e","img":"emoji_1f637.png"},
									  {"code":"0xe32f","img":"emoji_1f633.png"},{"code":"0xe326","img":"emoji_1f612.png"},
									  {"code":"0xe32d","img":"emoji_1f61a.png"},{"code":"0xe32c","img":"emoji_1f618.png"}]},
						 
						 {"category":[{"code":"0xe325","img":"emoji_1f630.png"},{"code":"0xe322","img":"emoji_1f632.png"},
									  {"code":"0xe33a","img":"emoji_1f62d.png"},{"code":"0xe334","img":"emoji_1f602.png"},
									  {"code":"0xe339","img":"emoji_1f622.png"},{"code":"0xe336","img":"emoji_263a.png"},
									  {"code":"0xe338","img":"emoji_1f604.png"},{"code":"0xe33d","img":"emoji_1f621.png"},
									  {"code":"0xe1b2","img":"emoji_1f47f.png"},{"code":"0xeb59","img":"emoji_1f4a4.png"},
									  {"code":"0xe7d9","img":"emoji_1f3c3.png"},{"code":"0xe7f0","img":"emoji_1f6b6.png"},
									  {"code":"0xe1a0","img":"emoji_1f46b.png"},{"code":"0xe827","img":"emoji_1f48f.png"},
									  {"code":"0xe829","img":"emoji_1f491.png"},{"code":"0xe1b4","img":"emoji_1f481.png"},
									  {"code":"0xe352","img":"emoji_1f646.png"},{"code":"0xe351","img":"emoji_1f645.png"},
									  {"code":"0xe197","img":"emoji_1f486.png"},{"code":"0xe198","img":"emoji_1f487.png"},
									  {"code":"0xe353","img":"emoji_1f647.png"},{"code":"0xe1af","img":"emoji_1f47c.png"},
									  {"code":"0xe1b6","img":"emoji_1f483.png"},{"code":"0xe196","img":"emoji_1f485.png"}]},
						 
						 {"category":[{"code":"0xe4d3","img":"emoji_1f454.png"},{"code":"0xe4cf","img":"emoji_1f455.png"},
									  {"code":"0xe53b","img":"emoji_1f4bc.png"},{"code":"0xe4cc","img":"emoji_1f45e.png"},
									  {"code":"0xe50f","img":"emoji_1f380.png"},{"code":"0xe4da","img":"emoji_1f459.png"},
									  {"code":"0xeb99","img":"emoji_1f446.png"},{"code":"0xeb9a","img":"emoji_1f447.png"},
									  {"code":"0xeb9b","img":"emoji_1f448.png"},{"code":"0xeb9c","img":"emoji_1f449.png"},
									  {"code":"0xeb96","img":"emoji_1f44a.png"},{"code":"0xeb97","img":"emoji_1f44d.png"},
									  {"code":"0xeb98","img":"emoji_261d.png"},{"code":"0xeb93","img":"emoji_270a.png"},
									  {"code":"0xeb94","img":"emoji_270c.png"},{"code":"0xeb95","img":"emoji_270b.png"},

									  {"code":"0xeb5e","img":"emoji_1f4aa.png"},{"code":"0xe190","img":"emoji_1f440.png"},
									  {"code":"0xe35b","img":"emoji_1f64f.png"},{"code":"0xeb9d","img":"emoji_1f44b.png"},
									  {"code":"0xeb9e","img":"emoji_1f44f.png"},{"code":"0xeb9f","img":"emoji_1f44c.png"},
									  {"code":"0xeba0","img":"emoji_1f44e.png"},{"code":"0xeba1","img":"emoji_1f450.png"}]},
									  
						 {"category":[{"code":"0xe1b8","img":"emoji_1f431.png"},{"code":"0xe1c0","img":"emoji_1f42f.png"},
									  {"code":"0xe1c1","img":"emoji_1f43b.png"},{"code":"0xe1b7","img":"emoji_1f436.png"},
									  {"code":"0xe1c2","img":"emoji_1f42d.png"},{"code":"0xe1c3","img":"emoji_1f433.png"},
									  {"code":"0xe1bc","img":"emoji_1f427.png"},{"code":"0xe1c4","img":"emoji_1f435.png"},
									  {"code":"0xe1c5","img":"emoji_1f419.png"},{"code":"0xe1bf","img":"emoji_1f437.png"},
									  {"code":"0xe1b0","img":"emoji_1f47d.png"},{"code":"0xe1c7","img":"emoji_1f42c.png"},
									  {"code":"0xe1c8","img":"emoji_1f426.png"},{"code":"0xe1ba","img":"emoji_1f424.png"},
									  {"code":"0xe1ca","img":"emoji_1f439.png"},{"code":"0xe1cc","img":"emoji_1f418.png"},
									  {"code":"0xe1cd","img":"emoji_1f428.png"},{"code":"0xe1ce","img":"emoji_1f412.png"},
									  {"code":"0xe1cf","img":"emoji_1f411.png"},{"code":"0xe1d0","img":"emoji_1f43a.png"},
									  {"code":"0xe1d1","img":"emoji_1f42e.png"},{"code":"0xe1d2","img":"emoji_1f430.png"},
									  {"code":"0xe1d4","img":"emoji_1f414.png"},{"code":"0xe1d5","img":"emoji_1f417.png"}]},
						
						 {"category":[{"code":"0xe1bd","img":"emoji_1f41f.png"},{"code":"0xe1be","img":"emoji_1f434.png"},
									  {"code":"0xe1cb","img":"emoji_1f41b.png"},{"code":"0xe1d3","img":"emoji_1f40d.png"},
									  {"code":"0xe1d6","img":"emoji_1f42b.png"},{"code":"0xe1d7","img":"emoji_1f438.png"},
									  {"code":"0xe003","img":"emoji_26c4.png"},{"code":"0xe001","img":"emoji_2601.png"},
									  {"code":"0xe042","img":"emoji_1f342.png"},{"code":"0xe043","img":"emoji_1f343.png"},
									  {"code":"0xe007","img":"emoji_1f302.png"},{"code":"0xe000","img":"emoji_2600.png"},
									  {"code":"0xe002","img":"emoji_2614.png"},{"code":"0xe014","img":"emoji_1f319.png"},
									  {"code":"0xe004","img":"emoji_26a1.png"},{"code":"0xeb69","img":"emoji_1f31f.png"},
									  {"code":"0xeb60","img":"emoji_2728.png"},{"code":"0xe4f6","img":"emoji_1f525.png"},
									  {"code":"0xe982","img":"emoji_1f378.png"},{"code":"0xe981","img":"emoji_2615.png"},
									  {"code":"0xe962","img":"emoji_1f370.png"},{"code":"0xe983","img":"emoji_1f37a.png"},
									  {"code":"0xe987","img":"emoji_1f37b.png"},{"code":"0xe963","img":"emoji_1f35c.png"}]},
									  
						 {"category":[{"code":"0xe964","img":"emoji_1f35e.png"},{"code":"0xe966","img":"emoji_1f366.png"},
									  {"code":"0xe967","img":"emoji_1f35f.png"},{"code":"0xe50a","img":"emoji_1f48a.png"},
									  {"code":"0xe960","img":"emoji_1f354.png"},{"code":"0xe970","img":"emoji_1f372.png"},
									  {"code":"0xe4ef","img":"emoji_1f4f7.png"},{"code":"0xe7d2","img":"emoji_26f3.png"},
									  {"code":"0xe7d3","img":"emoji_1f3be.png"},{"code":"0xe7d1","img":"emoji_26be.png"},
									  {"code":"0xe7d4","img":"emoji_26bd.png"},{"code":"0xe7d6","img":"emoji_1f3c0.png"},
									  {"code":"0xe7dd","img":"emoji_1f3c0.png"},{"code":"0xe80e","img":"emoji_1f3b1.png"},
									  {"code":"0xe7de","img":"emoji_1f3ca.png"},{"code":"0xe4ed","img":"emoji_1f1e8_1f1f3.png"},
									  {"code":"0xe7e4","img":"emoji_1f697.png"},{"code":"0xe7ea","img":"emoji_26f5.png"},
									  {"code":"0xe7e9","img":"emoji_2708.png"},{"code":"0xe7e6","img":"emoji_1f68c.png"},
									  {"code":"0xe7e2","img":"emoji_1f684.png"},{"code":"0xe7f3","img":"emoji_1f691.png"},
									  {"code":"0xe7ef","img":"emoji_1f695.png"},{"code":"0xe81c","img":"emoji_1f4fa.png"}]},

						 {"category":[{"code":"0xe4b8","img":"emoji_1f3e9.png"},{"code":"0xe552","img":"emoji_1f4d1.png"},
									  {"code":"0xe546","img":"emoji_1f4d6.png"},{"code":"0xe52d","img":"emoji_1f4eb.png"},
									  {"code":"0xe523","img":"emoji_260e.png"},{"code":"0xeb56","img":"emoji_1f4a1.png"},
									  {"code":"0xeb56","img":"emoji_1f4a3.png"},{"code":"0xeb1e","img":"emoji_1f6ac.png"},
									  {"code":"0xe7eb","img":"emoji_1f6b2.png"},{"code":"0xe507","img":"emoji_1f6bd.png"},
									  {"code":"0xe505","img":"emoji_1f6c0.png"},{"code":"0xe509","img":"emoji_1f489.png"},
									  {"code":"0xe4f5","img":"emoji_1f52b.png"},{"code":"0xe193","img":"emoji_1f444.png"},
									  {"code":"0xe4e3","img":"emoji_1f4b5.png"},{"code":"0xe4df","img":"emoji_1f4b9.png"},
									  {"code":"0xeb2b","img":"emoji_3299.png"},{"code":"0xeb23","img":"emoji_26a0.png"},
									  {"code":"0xeb25","img":"emoji_1f51e.png"},{"code":"0xeb45","img":"emoji_274c.png"},
									  {"code":"0xeb44","img":"emoji_2b55.png"},{"code":"0xeb57","img":"emoji_1f4a2.png"},
									  {"code":"0xeb09","img":"emoji_2753.png"},{"code":"0xeb0b","img":"emoji_2755.png"}]},
									  
						 {"category":[{"code":"0xe4f4","img":"emoji_1f4a9.png"},{"code":"0xeb5d","img":"emoji_1f4a8.png"},
									  {"code":"0xeb5b","img":"emoji_1f4a6.png"},{"code":"0xe510","img":"emoji_1f381.png"},
									  {"code":"0xe517","img":"emoji_1f389.png"},{"code":"0xe825","img":"emoji_1f48d.png"},
									  {"code":"0xe825","img":"emoji_2764.png"},{"code":"0xeb0e","img":"emoji_1f494.png"},
									  {"code":"0xe041","img":"emoji_1f339.png"},{"code":"0xeb12","img":"emoji_1f498.png"},
									  {"code":"0xeb19","img":"emoji_1f49f.png"},{"code":"0xe980","img":"emoji_1f374.png"},
									  {"code":"0xe513","img":"emoji_1f385.png"},{"code":"0xe512","img":"emoji_1f384.png"},
									  {"code":"0xe51f","img":"emoji_1f383.png"},{"code":"0xe1b3","img":"emoji_1f480.png"},
									  {"code":"0xe813","img":"emoji_1f3b5.png"},{"code":"0xe800","img":"emoji_1f3a4.png"},
									  {"code":"0xe801","img":"emoji_1f3a5.png"},{"code":"0xe808","img":"emoji_1f3ac.png"},
									  {"code":"0xe804","img":"emoji_1f3a8.png"},{"code":"0xe52f","img":"emoji_1f4e2.png"},
									  {"code":"0xe516","img":"emoji_1f388.png"},{"code":"0xe04e","img":"emoji_1f340.png"}]}];

		var cont = numFun(emojiData,cont);
		function numFun(data,content){
			var dataNum = data.length;
			var emotionCont = "<ul class='boxcont_emoji'>";
			var cateCont = "<p class='boxtab_emoji'>";
			for(var i=0;i<dataNum;i++){
				var itemNum = data[i].category.length;
				var currentEmot = i==0?"curcont_emoji":"";
				var currentCate = i==0?"curtab_emoji":"";
				emotionCont += "<li class='"+currentEmot+"' attribute="+i+"><table><tr>";
				cateCont += "<span class='"+currentCate+" tab_emoji' attribute="+i+">&nbsp;&nbsp;&nbsp;&nbsp;</span>";
				for(var j=0;j<itemNum;j++){;
					emotionCont += "<td><img id="+data[i].category[j].code+" src="+emojiSrc+data[i].category[j].img+"></td>";
					if(j>0&&Number(j+1)%8==0){emotionCont += '</tr><tr>'};
				}
				emotionCont += "</tr></table></li>";
			}
			emotionCont += "</ul>";
			cateCont += "</ul>";
			content = emotionCont + cateCont;
			return content;
		}
		that._emojiBox.html(cont);
	},
	_tabFun : function(){
		$(".tab_emoji").live("click",function(){
			var num = $(this).attr("attribute");
			$(this).addClass("curtab_emoji").siblings().removeClass("curtab_emoji");
			$(this).parents(".emojibox_emoji").find(".boxcont_emoji li:eq("+num+")").addClass("curcont_emoji").siblings().removeClass("curcont_emoji");
		})
	},
	_addEmotion : function(){
		var that = this;
		$(".curcont_emoji td img").live("click",function(){
			var val = $(this).attr("id");
			var num = that._textBox.val().length;
			if(num<that._textMaxL){
				that._textBox.insertAtCaret(String.fromCharCode(val));
				that._textBox.keyup();
			}
		})
	},
	_extend : function(){
		jQuery.fn.extend({
			insertAtCaret: function(textFeildValue){//在光标位置插入内容
				var textObj = $(this).get(0); 
				if(document.all && textObj.createTextRange && textObj.caretPos){ 
					var caretPos=textObj.caretPos; 
					caretPos.text = caretPos.text.charAt(caretPos.text.length-1) == '' ? 
					textFeildValue+'' : textFeildValue; 
				} else if(textObj.setSelectionRange){ 
					var rangeStart=textObj.selectionStart; 
					var rangeEnd=textObj.selectionEnd; 
					var tempStr1=textObj.value.substring(0,rangeStart); 
					var tempStr2=textObj.value.substring(rangeEnd); 
					textObj.value=tempStr1+textFeildValue+tempStr2; 
					textObj.focus(); 
					var len=textFeildValue.length; 
					textObj.setSelectionRange(rangeStart+len,rangeStart+len); 
					textObj.blur(); 
				}else{ 
					textObj.value+=textFeildValue; 
				} 
			} 
		});
	},
	init : function(){
		this._smileyBtn();
		this._hoverFun();
		this._tabFun();
		this._addEmotion();
		this._extend();
	}
}