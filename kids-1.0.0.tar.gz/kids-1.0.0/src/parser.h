#define TK_ID                              1
#define TK_SEMICOLON                       2
#define TK_LOG                             3
#define TK_LP                              4
#define TK_RP                              5
#define TK_LISTEN                          6
#define TK_STORE                           7
#define TK_BUFFER_TYPE                     8
