#ifndef LIBAE_H_
#define LIBAE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <fcntl.h>
#include "ae.h"
#include "anet.h"
#include "zmalloc.h"

#ifdef __cplusplus
}
#endif

#endif // LIBAE_H_
