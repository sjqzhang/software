//-*- c++ -*-
/*
 * author : KDr2
 */

#ifndef _REDIS_LEVELDB_H_INCLUDED
#define _REDIS_LEVELDB_H_INCLUDED

#define MAX_DBCOUNT 256
#define MAX_CONNECTIONS 1024
#define READ_BUFFER 81920
#define VERSION_STR "1.6"

#endif /* _REDIS_LEVELDB_H_INCLUDED */
